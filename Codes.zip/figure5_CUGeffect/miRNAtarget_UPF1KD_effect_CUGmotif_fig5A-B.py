

import sys, random, numpy, time, math, os
import annotationImporter as anno, utilityModule as util, UPF1module as Umodule
import AGO2_UPF1_miRNA_7A1_effect_module as mainModule
startT = time.time() 		#check elapse time
print "Start analysis: 00:00:00"

cellLine = sys.argv[1]		# HeLa_BIGlab_helicase, HeLa_BIGlab_UFP1KD, HeLa_Tani, HeLa_Zhen, mES
miRNA_top = sys.argv[2]	# top10, top30, top50
date = sys.argv[3]
distanceValue = int(sys.argv[4])
randomRep = int(sys.argv[5])
analyType = sys.argv[6]
removeMiRNA = list(sys.argv[7])  #"hsa-miR-30a-3p", "hsa-miR-24-3p", "hsa-miR-16-5p", "hsa-miR-27a-3p"

chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
nib = "/Data_Set/Genome/human/hg19/blat/"
geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
if cellLine == "HeLa_BIGlab_Dicer_UPF1KD":
	expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/UPF1KD/HeLa_BIGlab_DicerExp_UPF1KD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	CUGmotifFile = open("/home/jwawon/Project/UPF1/14.CUGmotif/CUGmotif.txt", "r")
	outputDir = "/home/jwawon/Project/UPF1/14.CUGmotif/Dicer_Exp/UPF1KD/" + date + "/"

if cellLine == "HeLa_BIGlab_DicerKD":
	expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/DicerKD/HeLa_BIGlab_DicerExp_DicerKD_UPF1KD_to_DicerKD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	CUGmotifFile = open("/home/jwawon/Project/UPF1/14.CUGmotif/CUGmotif.txt", "r")
	outputDir = "/home/jwawon/Project/UPF1/14.CUGmotif/Dicer_Exp/DicerKD/"+ date + "/"

if miRNA_top == "top10": 
	miRNA = open("/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top10.txt",'r')
	signi_miRNA = open("/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170305_new_miRNA/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top10_7mer_significant_0.005_miRNAlist_7m8.txt", 'r')
if miRNA_top == "top30": 
	miRNA = open("/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top30.txt",'r')
	signi_miRNA = open("/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170305_new_miRNA/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top30_7mer_significant_0.005_miRNAlist_7m8.txt", 'r')
if miRNA_top == "top50": 
	miRNA = open("/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top50.txt",'r')
	signi_miRNA = open("/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170305_new_miRNA/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_7mer_significant_0.005_miRNAlist_7m8.txt", 'r')
if miRNA_top == "bottom50": 
	miRNA = open("/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_random_bottom50.txt",'r')
	signi_miRNA = open("/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170305_new_miRNA/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_7mer_significant_0.005_miRNAlist_7m8.txt", 'r')



if not os.path.exists(outputDir): os.makedirs(outputDir)


def getLocus(chr, sense, tpUTRstart, siteType, miRNAindex):
	if siteType =="8mer": plusIndex = 7
	if siteType =="7m8" or siteType =="7A1": plusIndex = 6
	if siteType =="6mer": plusIndex = 5
	if siteType =="CUG": plusIndex = 2
	if sense == "+": miRNAlocus = Umodule.Locus(chr, tpUTRstart + miRNAindex , tpUTRstart + miRNAindex +plusIndex+1, sense)
	else: miRNAlocus = Umodule.Locus(chr, tpUTRstart - miRNAindex - plusIndex -1, tpUTRstart - miRNAindex, sense)
	return miRNAlocus

def get_signiMiRNAlist(signi_miRNA):
	signiMiRNAseed_dict = dict()
	signi_miRNAlist = signi_miRNA.readlines()
	for lines in signi_miRNAlist[1:]:
		line_list = lines.strip().split("\t")
		# print line_list
		group = line_list[0].split(" ")[-1].strip("()")
		if group == '7m8':
			seed_7m8 = line_list[2]
			miRNAname = line_list[1]
			signiMiRNAseed_dict[seed_7m8] = miRNAname
			seed_8mer = line_list[2] +"A"
			miRNAname = line_list[1]
			signiMiRNAseed_dict[seed_8mer] = miRNAname
		elif group == "7A1":
			seed_7A1 = line_list[2]
			miRNAname = line_list[1]
			signiMiRNAseed_dict[seed_7A1] = miRNAname
	return signiMiRNAseed_dict
signiMiRNAseed_dict = get_signiMiRNAlist(signi_miRNA)



############################ Data Setting ###################################
## make geneID list of inputed expressionFile file 


expressionFileOpen = open(expressionFile, 'r')
expressionFilelist = expressionFileOpen.readlines()
expressionFileOpen.close()


geneID_fpkm_dict = dict()
geneID_UMDgroup = dict()
for lines in expressionFilelist:
	line = lines.strip('\n').split('\t')
	geneID = line[0]
	fpkm = float(line[3])
	if fpkm >= 0.2: geneID_UMDgroup[geneID] = "UMD"
	else: geneID_UMDgroup[geneID] = "nonUMD"
	geneID_fpkm_dict[geneID] = fpkm


#/////////////////////////////////////////////////////////////////
## make hash tables of motif list

CUGmotifLine_list = CUGmotifFile.readlines()
CUGmotifFile.close()

if analyType == "CUGmotif":
	CUGmotif_dict = dict()
	for lines in CUGmotifLine_list:
		line_list = lines.strip().split("\t")
		CUGmotif_dict[line_list[1]] = line_list[0]
elif analyType == "CUG":
	CUGmotif_dict = {"CTG":"CUGmotif"}


#/////////////////////////////////////////////////////////////////
## make hash tables of miRNA list


miRNA_list = miRNA.readlines()
miRNA.close()

sevenD = dict()
seedD = dict()
seqToHitsTo8m = dict()
seqToHitsTo7m8 = dict()
seqToHitsTo7A1 = dict()
seqToHitsToSeed = dict()
miRNAseqDic = dict()


for miRNA_lines in miRNA_list:
	line = miRNA_lines.strip().split('\t')
	miRNAName = line[0]
	miRNAseq = line[2]
	miRNAseqDic[miRNAseq] = miRNAName
	if not miRNAName in removeMiRNA:
		sevenSeq = util.reverseComp(util.UtoT(miRNAseq[1:8]))
		seedSeq = util.reverseComp(util.UtoT(miRNAseq[1:7]))
		if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = miRNAName
		if not (seedD.has_key(seedSeq)): seedD[seedSeq] = miRNAName
		miRlength = len(miRNAseq)

seed_CUG_miRNAname = dict()
for seedKey in seedD.keys():
	seedseq = seedKey.upper()
	seqToHitsToSeed[seedseq] = seedD[seedKey]
	seqToHitsTo7A1[seedseq + 'A'] = seedD[seedKey]
for sevenKey in sevenD.keys():
	sevenseq = sevenKey.upper()
	CUG_index = sevenseq.find("CTG")
	if not CUG_index == -1: 
		seed_CUG_miRNAname[sevenD[sevenKey]] = sevenseq
	seqToHitsTo8m[sevenseq + 'A'] = sevenD[sevenKey]
	seqToHitsTo7m8[sevenseq] = sevenD[sevenKey]

for key in seed_CUG_miRNAname.keys():
	print key, seed_CUG_miRNAname[key]

random_miRNA_rep100_list = []
for i in range(0,randomRep):
	miRNAseq_list = miRNAseqDic.keys()
	random.shuffle(miRNAseq_list)
	miRrandomSeq = miRNAseq_list[0]
	diNuList = []
	for j in range(0, len(miRrandomSeq), 2):
		diNuList.append(miRrandomSeq[j:j+2])

	random_miRNAseqList = []
	n = 0

	while n < 50:
		random.shuffle(diNuList)
		randomSeq = ''.join(diNuList)
		randomSeedSeq = util.reverseComp(util.UtoT(randomSeq[1:7]))
		# print randomSeedSeq
		if not seqToHitsToSeed.has_key(randomSeedSeq):
			if not randomSeq in random_miRNAseqList:
				random_miRNAseqList.append(randomSeq)
				n += 1
	random_seqToHitsToSites_list, random_miSeq_dic = mainModule.get_miRNAsites_dic(random_miRNAseqList, "random")
	# print random_seqToHitsToSites_list[2]
	random_miRNA_rep100_list.append(random_seqToHitsToSites_list)

def getRandomSites_dict(genelist, geneID_tpUTRseq ,random_miRNA_rep100_list):
	random_dict = dict()
	random_siteLocus_name = dict()
	for i, random_miRNA in enumerate(random_miRNA_rep100_list):
		random_dict[i] = dict()
		random_siteLocus_name[i] = dict()
		for gene in genelist:
			geneName = gene[1].name()
			geneID = gene[1].geneID()
			chr = gene[1].chr()
			sense = gene[1].sense()
			tpUTR = gene[1].tpUtr()
			tpExons = gene[1].tpExons(sense)
			tpUTRseq = geneID_tpUTRseq[geneID]
			if sense == "+": tpUTRstart = tpUTR.start()
			else: tpUTRstart = tpUTR.end()
			dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites = mainModule.searchMiRNAsite(chr, sense, tpUTRseq, tpUTRstart, random_miRNA, "7A1")
			for locus in dict_sites.keys():
				randomName = dict_sites[locus][0]
				random_siteLocus_name[i][locus] = randomName
			random_dict[i][geneID] = dict_sites.keys()
		sys.stdout.write("\r%s%d%%" % ("random miRNA list status: ", i))
		sys.stdout.flush()
	return random_dict, random_siteLocus_name

#///////////////////////// elapsed time check /////////////////////
miRDataSettingT = time.time()            #check miRDataSettingT elapse time
miRDataElapseT = Umodule.elapseTime(startT,miRDataSettingT)
print "Finish the miRNA data setting: ", miRDataElapseT 

if analyType == "CUGmotif": CUGmotif_File = open(outputDir+cellLine +'_' + miRNA_top +'_CUGmotifLocus.bed', 'w')
if analyType == "CUG": CUGmotif_File = open(outputDir+cellLine +'_' + miRNA_top +'_CUGLocus.bed', 'w')
miRNA_File = open(outputDir+cellLine +'_' + miRNA_top +'_miRNAlocus.bed', 'w')


def get_writeLines(locus, name):
	newLine = "\t".join(map(str,[locus.chr(), locus.start(), locus.end(), name, 1, locus.sense()])) + "\n"
	return newLine

allgeneID_list = []
geneID_tpUTRseq = dict()
geneID_geneName = dict()
geneID_tpUTRlength_dict = dict()
geneID_miRNAtarget= dict()
geneID_miRNA_8merTo7A1 = dict()
geneID_miRNA_CUGmotif = dict()
geneID_CUGmotif = dict()
miSiteLocus_Name = dict()
CUGlocus_motif = dict()

genelist = filter(lambda x: geneID_fpkm_dict.has_key(x[0]), geneAnno.items())

TotalgeneC = len(genelist)
geneC = 0
geneID_strand = dict()
CUGmotif_count = 0
random_dict = dict()

UMD_random_list = []
nonUMD_random_list = []

UMD_CUG_count = 0
nonUMD_CUG_count = 0
UMD_random_count = 0
nonUMD_random_count = 0
for gene in  genelist:
	geneC += 1
	status = int(float(geneC)/float(TotalgeneC) * 100)
	geneName = gene[1].name()
	geneID = gene[1].geneID()
	geneID_geneName[geneID] = geneName
	allgeneID_list.append(geneID) 
	chr = gene[1].chr()
	sense = gene[1].sense()
	geneID_strand[geneID] = sense
	tpExons = gene[1].tpExons(sense)
	tpUTRseq = Umodule.getListSequence(tpExons, nib)
	geneID_tpUTRseq[geneID] = tpUTRseq
	tpUTRlen = len(tpUTRseq)
	geneID_tpUTRlength_dict[geneID] = tpUTRlen
	if sense == "+": tpUTRstart = gene[1].tpUtr().start()
	else: tpUTRstart = gene[1].tpUtr().end()
	geneID_CUGmotif[geneID] = []
	geneID_miRNAtarget[geneID] = []
	geneID_miRNA_8merTo7A1[geneID] = []
	geneID_miRNA_CUGmotif[geneID] = []
	group = geneID_UMDgroup[geneID]
	for n in xrange(len(tpUTRseq)-6):
		if analyType == "CUGmotif": locSeq = tpUTRseq[n:n+7]
		elif analyType == "CUG": locSeq = tpUTRseq[n:n+3]
		if CUGmotif_dict.has_key(locSeq):
			CUGmotif_count += 1
			if analyType =="CUGmotif": siteLocus = getLocus(chr, sense, tpUTRstart, "7m8", n)
			elif analyType =="CUG": 
				siteLocus = getLocus(chr, sense, tpUTRstart, "CUG", n)
			CUGlocus_motif[siteLocus] = locSeq
			CUGmotif_File.write(get_writeLines(siteLocus, locSeq))
			geneID_CUGmotif[geneID].append(siteLocus)

	skip = "off"
	m = 0
	for n in xrange(len(tpUTRseq) - miRlength + 1):
		if m <= len(tpUTRseq) - miRlength + 1:
			locSeq8 = tpUTRseq[m:m+8]
			locSeq7 = tpUTRseq[m:m+7]
			locSeq6 = tpUTRseq[m:m+6]
			if seqToHitsTo8m.has_key(locSeq8):
				siteLocus = getLocus(chr, sense, tpUTRstart, "8mer", m)
				miRNA_File.write(get_writeLines(siteLocus, locSeq8))
				if seed_CUG_miRNAname.has_key(seqToHitsTo8m[locSeq8]): geneID_miRNA_CUGmotif[geneID].append(locSeq8)
				if signiMiRNAseed_dict.has_key(locSeq8): miSiteLocus_Name[siteLocus] = seqToHitsTo8m[locSeq8] + "_signi"
				else: miSiteLocus_Name[siteLocus] = seqToHitsTo8m[locSeq8] + "_insigni"
				geneID_miRNAtarget[geneID].append(siteLocus)
				geneID_miRNA_8merTo7A1[geneID].append(siteLocus)
				skip = "on"
				m += 8
				continue
			elif seqToHitsTo7m8.has_key(locSeq7):
				siteLocus = getLocus(chr, sense, tpUTRstart, "7m8", m)
				miRNA_File.write(get_writeLines(siteLocus, locSeq7))
				if seed_CUG_miRNAname.has_key(seqToHitsTo7m8[locSeq7]): geneID_miRNA_CUGmotif[geneID].append(locSeq7)
				if signiMiRNAseed_dict.has_key(locSeq8): miSiteLocus_Name[siteLocus] = seqToHitsTo7m8[locSeq7] + "_signi"
				else: miSiteLocus_Name[siteLocus] = seqToHitsTo7m8[locSeq7] + "_insigni"
				geneID_miRNAtarget[geneID].append(siteLocus)
				geneID_miRNA_8merTo7A1[geneID].append(siteLocus)
				skip = "on"
				m += 7
				continue
			elif seqToHitsTo7A1.has_key(locSeq7):
				siteLocus = getLocus(chr, sense, tpUTRstart, "7A1", m)
				miRNA_File.write(get_writeLines(siteLocus, locSeq7))
				if seed_CUG_miRNAname.has_key(seqToHitsTo7A1[locSeq7]): geneID_miRNA_CUGmotif[geneID].append(locSeq7)
				if signiMiRNAseed_dict.has_key(locSeq8): miSiteLocus_Name[siteLocus] = seqToHitsTo7A1[locSeq7] +  "_signi"
				else: miSiteLocus_Name[siteLocus] = seqToHitsTo7A1[locSeq7] + "_insigni"
				geneID_miRNAtarget[geneID].append(siteLocus)
				geneID_miRNA_8merTo7A1[geneID].append(siteLocus)
				skip = "on"
				m += 7
				continue
			elif seqToHitsToSeed.has_key(locSeq6):
				siteLocus = getLocus(chr, sense, tpUTRstart, "6mer", m)
				miRNA_File.write(get_writeLines(siteLocus, locSeq6))
				geneID_miRNAtarget[geneID].append(siteLocus)
				skip = "on"
				m += 6
			else: 
				skip = "off"
				m += 1
		else: break
	sys.stdout.write("\r%s%d%%" % ("miRNA target analysis status: ", status))
	sys.stdout.flush()

analysisT = time.time()
analysisElapseT = Umodule.elapseTime(startT,analysisT)
print '\n'+ "Finish miRNA target analysis, it's elapse time: " + analysisElapseT 

miRNA_File.close()
CUGmotif_File.close()

#//////////////////// target //////////////////////////////
def cal_overlap(allgeneID_list, geneID_UMDgroup, geneID_miRNA_locus, geneID_CUGmotif, distanceValue, miSiteLocus_Name, CUGlocus_motif, analyType, miRNAorRandom):
	miRNA_count = dict()
	geneID_group = dict()
	CUGlocus_miLocus_50 = dict()

	for geneID in allgeneID_list:
		if len(geneID_miRNA_locus[geneID]) >0 and len(geneID_CUGmotif[geneID]) > 0:
			geneID_group[geneID] = "Both"
		elif len(geneID_miRNA_locus[geneID]) >0 and len(geneID_CUGmotif[geneID]) == 0:
			geneID_group[geneID] = "miRNA"
		elif len(geneID_miRNA_locus[geneID]) ==0 and len(geneID_CUGmotif[geneID]) > 0:
			geneID_group[geneID] = "CUGmotif"
		else: geneID_group[geneID] = "nonTarget"

	def getDistance(miName, flocus, slocus):
		MRE = miName.split("(")[-1].split(")")[0]
		if MRE == "7A1":
			if flocus.sense() == "+": dis = slocus.start() - flocus.start()
			else: dis = flocus.end() - slocus.end()
		if MRE == "7m8":
			if flocus.sense() == "+": dis = slocus.start() - (flocus.start() +1)
			else: dis = (flocus.end()-1) - slocus.end()
		if MRE == "8mer":
			if flocus.sense() == "+": dis = slocus.start() - (flocus.start() +1)
			else: dis = (flocus.end()-1) - slocus.end()
		return dis

	def getMin(disList):
		for i, value in enumerate(disList):
			if i == 0:
				fValue = value[1]
				minIndex = i
			else:
				if abs(fValue) > abs(value[1]):
					minIndex = i
					fValue = value[1]
		return disList[minIndex]
	CUGmotifGroup = filter(lambda x: geneID_group[x] =="CUGmotif", geneID_group.keys())
	CUGonlyCount = sum(map(lambda x: len(geneID_CUGmotif[x]), CUGmotifGroup))

	bothGroup = filter(lambda x: geneID_group[x] == "Both", geneID_group.keys())
	geneID_overlapC = dict()
	CUGmotif_overlapCount  = []
	totalOverlap = 0
	CUGbothCount = 0
	UMD_distance_count_dict = dict()
	nonUMD_distance_count_dict = dict()
	miRNAlocus_UMDgroup = dict()
	num = 0

	for geneID in bothGroup:
		group = geneID_UMDgroup[geneID]
		num+=1
		sys.stdout.write("\r%s%d%%" % ("overlap status: ", int(float(num)/float(len(bothGroup)) * 100)))
		sys.stdout.flush()
		CUGoverlapD_dict = dict()
		CUGnonOverlapD_dict = dict()
		CUG_all_dict = dict()
		# for CUGlocus in geneID_CUGmotif[geneID]:
		for miLocus in geneID_miRNA_locus[geneID]:
			miName = miSiteLocus_Name[miLocus]
			miRNAlocus_UMDgroup[miLocus] = group
			CUGbothCount +=1
			CUG_all_dict[miLocus] = []
			# for miLocus in geneID_miRNA_locus[geneID]:
			for CUGlocus in geneID_CUGmotif[geneID]:
				CUG_all_dict[miLocus].append([CUGlocus,getDistance(miName, miLocus, CUGlocus)])

		if len(CUG_all_dict.keys()) > 0:
			for miLocus in CUG_all_dict.keys():
				miName = miSiteLocus_Name[miLocus]
				for CUGlocus_Distance_list in CUG_all_dict[miLocus]:
					CUGlocus = CUGlocus_Distance_list[0]
					dis = CUGlocus_Distance_list[1]
					CUGmotif = CUGlocus_motif[CUGlocus]

					if group == "UMD":
						if UMD_distance_count_dict.has_key(dis): UMD_distance_count_dict[dis] +=1
						else: UMD_distance_count_dict[dis] = 1
					elif group == "nonUMD":
						if nonUMD_distance_count_dict.has_key(dis): nonUMD_distance_count_dict[dis] +=1
						else: nonUMD_distance_count_dict[dis] = 1
					if distanceValue >= dis and dis >= -distanceValue: 
						geneID_group[geneID] = "Both_5in"
						CUGlocus_miLocus_50[miLocus] = CUGlocus
					elif distanceValue < dis or dis < -distanceValue: geneID_group[geneID] = "Both_5out" 
	return geneID_group, UMD_distance_count_dict, nonUMD_distance_count_dict, CUGonlyCount, CUGbothCount, CUGlocus_miLocus_50, miRNAlocus_UMDgroup

print '\n'+ "complete miRNA overlap"

if analyType == "CUGmotif": groupGenesFpkm_File = open(outputDir+cellLine +'_' + miRNA_top +'_groupGeneID_log2FoldChange_CUGmotif.txt', 'w')
elif analyType == "CUG": groupGenesFpkm_File = open(outputDir+cellLine +'_' + miRNA_top +'_groupGeneID_log2FoldChange_CUG.txt', 'w')

groupGenesFpkm_File.write("geneName" + "\t" + "geneID" + "\t" + "log2Fold" + "\t" + "CUGin_miRNA" + "\t" + "CUGin_miRNA(count)" + "\t" + "miRNA" + "\t" + "miRNA(count)" + "\t" + "CUG" + "\t" + "CUG(count)" + "\n")
geneID_group = dict()
for geneID in allgeneID_list:
	if len(geneID_miRNA_CUGmotif[geneID]) >0: Both_CUGmiRNA_group = "Both_CUGmiRNA_O"
	if len(geneID_miRNA_CUGmotif[geneID]) ==0: Both_CUGmiRNA_group = "Both_CUGmiRNA_X"
	if len(geneID_miRNA_8merTo7A1[geneID]) >0: miRNAgroup = "miRNA_O"
	if len(geneID_miRNA_8merTo7A1[geneID]) ==0: miRNAgroup = "miRNA_X"
	if len(geneID_CUGmotif[geneID]) >0: CUGgroup = "CUG_O"
	if len(geneID_CUGmotif[geneID]) ==0: CUGgroup = "CUG_X"
	print Both_CUGmiRNA_group, miRNAgroup, CUGgroup, geneID, len(geneID_miRNA_8merTo7A1[geneID]), len(geneID_miRNA_CUGmotif[geneID]), len(geneID_CUGmotif[geneID])
	groupGenesFpkm_File.write(geneID_geneName[geneID] + "\t" + geneID + "\t" + str(geneID_fpkm_dict[geneID]) + "\t" + Both_CUGmiRNA_group + "\t" + str(len(geneID_miRNA_CUGmotif[geneID])) + "\t" +miRNAgroup  + "\t" + str(len(geneID_miRNA_8merTo7A1[geneID])) + "\t" +CUGgroup + "\t" + str(len(geneID_CUGmotif[geneID])) + "\n")
groupGenesFpkm_File.close()




