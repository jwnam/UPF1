


import sys, os
import random
import utilityModule as util
import AGO2_UPF1_miRNA_7A1_effect_module as mainModule

outputName = sys.argv[1]    #
cellLine = sys.argv[2]      # 
analysis = sys.argv[3] 		# random vs top50, random vs all

for f in ["A","C","G","T"]:
	for s in ["A","C","G","T"]:
		for t in ["A","C","G","T"]:
			checkMotif.append(f+s+t)
motif_statLines = dict()
for motif in checkMotif:
	def read_conserved_seed(conserved_miRNAfile, cellLine):
		conserved_seed_miRNAname = dict()
		file = open(conserved_miRNAfile,'r')
		lines = file.readlines()
		if cellLine == "HeLa": indi = "hsa"
		else: indi = cellLine
		for line in lines[1:]:
			if cellLine == "dme":
				miRNAname = line.strip().split("\t")[2]
				seq = line.strip().split("\t")[3]
				conservScore = float(line.strip().split("\t")[4])
			else:
				miRNAname = line.strip().split("\t")[3]
				seq = line.strip().split("\t")[4]
				conservScore = float(line.strip().split("\t")[5])
			if miRNAname.startswith(indi):
				if conservScore >=1:
					seed = util.reverseComp(util.UtoT(seq[1:7]))
					conserved_seed_miRNAname[seed] = miRNAname
		return conserved_seed_miRNAname


	def read_fa_seed(file, cellLine, conserved_seed_miRNAname):
		seed_miRNAname_7mer = dict()
		fa_file = open(file,'r')
		fa_lines = fa_file.readlines()
		total_miRNA_count = 0
		for i in range(0,len(fa_lines),2):
			if cellLine == "HeLa": 
				miRNAname = fa_lines[i][1:].strip()
				indi = "Hsa"
			else: 
				miRNAname = fa_lines[i][1:].strip().split(" ")[0]
				indi = cellLine
			if miRNAname.startswith(indi):
				seqLine = fa_lines[i+1].strip()
				seed = util.reverseComp(util.UtoT(seqLine[1:7]))
				seven = util.reverseComp(util.UtoT(seqLine[1:8]))
				# if conserved_seed_miRNAname.has_key(seed):
				total_miRNA_count +=1
				if seed_miRNAname_7mer.has_key(seed):
					seed_miRNAname_7mer[seed][2]+=1
				else: seed_miRNAname_7mer[seed] = [miRNAname, seven, 1]
		return seed_miRNAname_7mer, total_miRNA_count

	def find_CUG_inSeed(seed_miRNAname_7mer, type, motif):
		# checkMotif = ["CTG"]
		# checkMotif = ["GGG", "CCT", "CTG", "AGG", "GAG", "GGA", "CCG", "CGG", "CGC", "GCG", "CGT", "TCG", "ACG", "CGA"]
		sevenM_motif_miRNAname = dict()
		CUG_count = 0
		for seed in seed_miRNAname_7mer.keys():
			if type == "all": 
				miRNAname, sevenSeq, count = seed_miRNAname_7mer[seed]	
			elif type == "top50" or type == "random": 
				sevenSeq = seed; miRNAname = seed_miRNAname_7mer[seed]
				count = 1
			for n in xrange(len(sevenSeq) - 2):
				locSeq3 = sevenSeq[n:n+3]
				if locSeq3 == motif:
					sevenM_motif_miRNAname[miRNAname] = sevenSeq
					CUG_count += count
					break
					# print miRNAname, sevenSeq
		return sevenM_motif_miRNAname, CUG_count

	def getSeedExpMiRNA(file, cellLine):
		file_lines = file.readlines()
		file.close()
		sevenD = dict()
		seedD = dict()
		miRNAseqDic = dict()
		for miRNA_lines in file_lines:
			line = miRNA_lines.strip().split('\t')
			miRNAName = line[0]
			if cellLine =="HeLa": 
				miRNAseq = line[2]
			elif cellLine =="dme" or cellLine =="cel": miRNAseq = line[1]
			miRNAseqDic[miRNAseq] = miRNAName
			sevenSeq = util.reverseComp(util.UtoT(miRNAseq[1:8]))
			seedSeq = util.reverseComp(util.UtoT(miRNAseq[1:7]))
			if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = line
			if not (seedD.has_key(seedSeq)): seedD[seedSeq] = line
		return seedD

	def get_top50_randomMiRNA(cellLine, miRNA_top50, analyType, analysis, total_miRNA_count):
		if cellLine =="HeLa": 
			miRNA_list = miRNA_top50.readlines()
			miRNA_top50.close()
		else: miRNA_list = miRNA_top50
		sevenD = dict()
		seedD = dict()
		seqToHitsTo8m = dict()
		seqToHitsTo7m8 = dict()
		seqToHitsTo7A1 = dict()
		seqToHitsToSeed = dict()
		miRNAseqDic = dict()
		for miRNA_lines in miRNA_list:
			if cellLine =="HeLa": line = miRNA_lines.strip().split('\t')
			else: line = miRNA_lines
			miRNAName = line[0]
			if cellLine =="HeLa": 
				miRNAseq = line[2]
			elif cellLine =="dme" or cellLine =="cel": miRNAseq = line[1]
			miRNAseqDic[miRNAseq] = miRNAName
			sevenSeq = util.reverseComp(util.UtoT(miRNAseq[1:8]))
			seedSeq = util.reverseComp(util.UtoT(miRNAseq[1:7]))
			if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = miRNAName
			if not (seedD.has_key(seedSeq)): seedD[seedSeq] = miRNAName
			miRlength = len(miRNAseq)

		for seedKey in seedD.keys():
			seedseq = seedKey.upper()
			seqToHitsToSeed[seedseq] = seedD[seedKey]+"(6mer)"
			seqToHitsTo7A1[seedseq + 'A'] = seedD[seedKey]+"(7A1)"
		for sevenKey in sevenD.keys():
			sevenseq = sevenKey.upper()
			seqToHitsTo8m[sevenseq + 'A'] = sevenD[sevenKey]+"(8mer)"
			seqToHitsTo7m8[sevenseq] = sevenD[sevenKey]+"(7m8)"
		if analysis == "top50": cohort = len(miRNA_list)
		elif analysis == "all": cohort = total_miRNA_count

		random_miRNA_rep100_list = []
		for i in range(0,10000):
			miRNAseq_list = miRNAseqDic.keys()
			random.shuffle(miRNAseq_list)
			miRrandomSeq = miRNAseq_list[0]
			diNuList = []
			if analyType == "di":
				for j in range(0, len(miRrandomSeq), 2):
					diNuList.append(miRrandomSeq[j:j+2])
			elif analyType == "mono":
				ranSeq = ["A","C","U","G"]
				for j in range(0,22):
					random.shuffle(ranSeq)
					diNuList.append(ranSeq[0])
			random_miRNAseqList = []
			n = 0
			while n < cohort:
				random.shuffle(diNuList)
				randomSeq = ''.join(diNuList)
				randomSeedSeq = util.reverseComp(util.UtoT(randomSeq[1:7]))
				# print randomSeedSeq
				if not seqToHitsToSeed.has_key(randomSeedSeq):
					if not randomSeq in random_miRNAseqList:
						random_miRNAseqList.append(randomSeq)
						n += 1
			random_seqToHitsToSites_list, random_miSeq_dic = mainModule.get_miRNAsites_dic(random_miRNAseqList, "random")
			random_seqToHitsToSites_7m8 = random_seqToHitsToSites_list[1]
			random_miRNA_rep100_list.append(random_seqToHitsToSites_7m8)
		return seqToHitsTo7m8, random_miRNA_rep100_list


	# mature_miRNAfile = /home/jwawon/Project/LiverCancer/reference/mirbase.v21/mature.fa
	if cellLine == "HeLa":
		mature_miRNAfile = "/home/jwawon/Project/UPF1/Data_set/Fromm_2015_miRNA/human_mature_star_523.fa"
		conserved_miRNAfile = "/home/jwawon/Project/UPF1/Data_set/TargetScan/Human/miR_Family_Info.txt"
		miRNA_top50 = open("/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top50.txt",'r')
	elif cellLine == "dme":
		conserved_miRNAfile = "/home/jwawon/Project/UPF1/Data_set/TargetScan/Fly/miR_Family_Info.txt"
		mature_miRNAfile = "/home/jwawon/Project/LiverCancer/reference/mirbase.v21/mature.fa"
		miRNA_top100 = open("/home/jwawon/Project/UPF1/Data_set/jwnam_miRNA/s2_fly/dme_miRNA_list_new_top100.txt",'r')
		miRNA_top100_ovary = open("/home/jwawon/Project/UPF1/Data_set/jwnam_miRNA/s2_fly/dme_ovary_miRNA_list_new_top100.txt",'r')
		miRNA_top100_seedD = getSeedExpMiRNA(miRNA_top100, cellLine)
		miRNA_top100_ovary_seedD = getSeedExpMiRNA(miRNA_top100_ovary, cellLine)
		miRNA_top50 = []
		for seed in miRNA_top100_seedD.keys():
			if miRNA_top100_ovary_seedD.has_key(seed): 
				miRNA_top50.append(miRNA_top100_seedD[seed])
		print "total overlap: ", len(miRNA_top50)


	elif cellLine == "cel":
		conserved_miRNAfile = "/home/jwawon/Project/UPF1/Data_set/TargetScan/c.elegans/miR_Family_Info.txt"
		mature_miRNAfile = "/home/jwawon/Project/LiverCancer/reference/mirbase.v21/mature.fa"
		miRNA_top100_adult = open("/home/jwawon/Project/UPF1/Data_set/jwnam_miRNA/c.elegans/cel_adult_miRNA_list_new_top100.txt",'r')
		miRNA_top100_glp4 = open("/home/jwawon/Project/UPF1/Data_set/jwnam_miRNA/c.elegans/cel_glp4_miRNA_list_new_top100.txt",'r')
		miRNA_top100_L4 = open("/home/jwawon/Project/UPF1/Data_set/jwnam_miRNA/c.elegans/cel_L4_miRNA_list_new_top100.txt",'r')
		miRNA_top100_adult_seedD = getSeedExpMiRNA(miRNA_top100_adult, cellLine)
		miRNA_top100_glp4_seedD = getSeedExpMiRNA(miRNA_top100_glp4, cellLine)
		miRNA_top100_L4_seedD = getSeedExpMiRNA(miRNA_top100_L4, cellLine)
		miRNA_top50 = []
		for seed in miRNA_top100_adult_seedD.keys():
			if miRNA_top100_glp4_seedD.has_key(seed) and miRNA_top100_L4_seedD.has_key(seed) : 
				miRNA_top50.append(miRNA_top100_adult_seedD[seed])
		print "total overlap: ", len(miRNA_top50)


	conserved_seed_miRNAname = read_conserved_seed(conserved_miRNAfile, cellLine)
	seed_miRNAname_7mer, total_miRNA_count = read_fa_seed(mature_miRNAfile, cellLine, conserved_seed_miRNAname)
	print "totalLine: ", total_miRNA_count
	seqToHitsTo7m8,random_miRNA_rep100_list= get_top50_randomMiRNA(cellLine, miRNA_top50, "di", analysis, total_miRNA_count)


	sevenM_motif_top50, top50_CUG_count = find_CUG_inSeed(seqToHitsTo7m8, "top50", motif)
	sevenM_motif_allmiRNA, all_CUG_count = find_CUG_inSeed(seed_miRNAname_7mer, "all", motif)
	print "motif check: ", motif
	print "Motif in 7m8 in top50: ", len(sevenM_motif_top50.keys()), top50_CUG_count
	print "total line (seed): ", len(seed_miRNAname_7mer.keys()), total_miRNA_count
	print "Motif in 7m8 in all miRNA: ", len(sevenM_motif_allmiRNA.keys()), all_CUG_count

	random_CUG_count_list = []
	random_CUG_more12_list = []
	if analysis == "all": CUG_count = all_CUG_count
	elif analysis == "top50": CUG_count = top50_CUG_count
	for i, random_miRNA in enumerate(random_miRNA_rep100_list):
		# print i, random_miRNA
		seed_CUG_random, random_CUG_count = find_CUG_inSeed(random_miRNA, "random", motif)
		random_CUG_count_list.append(len(seed_CUG_random.keys()))
		if len(seed_CUG_random.keys()) > CUG_count:
			random_CUG_more12_list.append(len(seed_CUG_random.keys()))
	random_count, random_meanCount, random_medianCount, random_stdCount, random_steCount = mainModule.getMeanSteFromList(random_CUG_count_list)
	print "random in all miRNA"
	print "random_count: ", random_count
	print motif, " in random (Mean): ", random_meanCount
	print motif, " in random (ste): ", random_steCount
	print "random_count (>", str(CUG_count), "): ", len(random_CUG_more12_list)
# motif	top50	random (mean)	p-value	Signal to Noise Ratio	miRBase (394)	random (miRBase)	p-value (miRBase)	Signal to Noise Ratio
	pValue = len(random_CUG_more12_list) / float(10000)
	if analysis == "top50":
		SNR = top50_CUG_count / random_meanCount
		statLines = [str(top50_CUG_count), str(random_meanCount), str(pValue), str(SNR)]
	if analysis == "all": 
		SNR = all_CUG_count / random_meanCount
		statLines = [str(all_CUG_count), str(random_meanCount), str(pValue), str(SNR)]
		print statLines
	motif_statLines[motif] = statLines
outputDir = "/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/" + outputName+"_summary_motifIn7mer_top50_all_random/" + cellLine + "/"
if not os.path.exists(outputDir): os.makedirs(outputDir)
stat_outputFile = open(outputDir+cellLine+ "_" + analysis+"_overall_stat_top50_allrandom.txt", "w")
stat_outputFile.write("total line (seed):" + str(total_miRNA_count)+ "\n")
for motif in motif_statLines.keys():
	stat_outputFile.write(motif +"\t" + "\t".join(motif_statLines[motif]) + "\n")
stat_outputFile.close()
