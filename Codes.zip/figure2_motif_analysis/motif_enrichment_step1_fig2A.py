

## make geneID list of inputed expressionFile file 
def get_geneID_log2Fold(fpkmFile):
	geneID_dict = dict()
	fpkmFileOpen = open(fpkmFile, 'r')
	fpkmFileLines = fpkmFileOpen.readlines()
	fpkmFileOpen.close()
	log2FoldLists = []
	for line in fpkmFileLines:
		lineList = line.strip().split('\t')
		geneID = lineList[0]; length = int(lineList[1]); log2Fold = float(lineList[3])
		geneID_dict[geneID] = log2Fold
		log2FoldLists.append(log2Fold)
	return geneID_dict


## make hash tables of miRNA list
def get_miRNAsites_dict(miRNAfile, Xmer):
	sevenD = dict()
	seedD = dict()
	seqToHitsTo8mer = dict()
	seqToHitsTo7m8 = dict()
	seqToHitsTo7A1 = dict()
	seqToHitsTo7mer = dict()
	seqToHitsTo6mer = dict()
	miRNAseqDic = dict()
	miRNAfileOpen = open(miRNAfile, 'r')
	miRNAfileLines = miRNAfileOpen.readlines()
	miRNAfileOpen.close()
	for line in miRNAfileLines:
		lineList = line.strip().split('\t')
		miRNAName = lineList[0].strip(">")
		seq = lineList[2]
		miRNAseqDic[seq] = miRNAName
	for miRNAseq in miRNAseqDic.keys():
		sevenSeq = util.reverseComp(util.UtoT(miRNAseq[1:8]))
		seedSeq = util.reverseComp(util.UtoT(miRNAseq[1:7]))
		if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = miRNAseqDic[miRNAseq]
		if not (seedD.has_key(seedSeq)): seedD[seedSeq] = miRNAseqDic[miRNAseq]
	for seedKey in seedD.keys():
		seedseq = seedKey.upper()
		seqToHitsTo6mer[seedseq] = seedD[seedKey]
		seqToHitsTo7A1[seedseq + 'A'] = seedD[seedKey]
		seqToHitsTo7mer[seedseq + 'A'] = seedD[seedKey]
	for sevenKey in sevenD.keys():
		sevenseq = sevenKey.upper()
		seqToHitsTo8mer[sevenseq + 'A'] = sevenD[sevenKey]
		seqToHitsTo7m8[sevenseq] = sevenD[sevenKey]
		seqToHitsTo7mer[sevenseq] = sevenD[sevenKey]
	return seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer 

def getListSequence(list,f):
	locusList = []
	if f[-1]=='/': f = f[:-1]
#   print list
	for locus in list:
		chr = locus.chr()
		start = locus.start() # Loci of List is difference start, end position with nomal locus
		finish = locus.end()
		sense = locus.sense()
		if start == finish: continue
		command = 'nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(sense)+' stdout'
		a = os.popen(command,'r')
		b = a.read().split('\n')
		a.close()
		locusSeq = ''.join(b[1:]).upper()
		locusList.append(locusSeq)
	if list[0].sense() == '-': 
		locusList.reverse()
	listSeq = ''.join(locusList)
	return listSeq

def make_count_dict(count_dict, key):
	if count_dict.has_key(key): count_dict[key] += 1
	else: count_dict[key] = 1
	return count_dict

## search miRNA site (8mer, 7m8, 7A1, 6mer)
def make_motif_dict(motif_count_dict, motif_count_over_dict, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over, seq, Xmer, log2Fold, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer):
	m = 0
	i = 0
	for n in xrange(len(seq) - Xmer +1):
		locSeq = seq[n:n+Xmer]
		motif_count_dict = make_count_dict(motif_count_dict, locSeq)
		if log2Fold >= 0.2: motif_count_over_dict = make_count_dict(motif_count_over_dict, locSeq)
		if m <= len(seq) -8+1:
			locSeq8 = seq[m:m+8]
			locSeq7 = seq[m:m+7]
			locSeq6 = seq[m:m+6]
			if seqToHitsTo8mer.has_key(locSeq8):		##8mer
				dict_8mer = make_count_dict(dict_8mer, locSeq8)
				if log2Fold >= 0.2: dict_8mer_over = make_count_dict(dict_8mer_over, locSeq8)
				m += 2
				continue
			elif seqToHitsTo7m8.has_key(locSeq7):		##7m8
				dict_7m8 = make_count_dict(dict_7m8, locSeq7)
				if log2Fold >= 0.2: dict_7m8_over = make_count_dict(dict_7m8_over, locSeq7)
				m +=1
				continue
			elif seqToHitsTo7A1.has_key(locSeq7):		##7A1
				dict_7A1 = make_count_dict(dict_7A1, locSeq7)
				if log2Fold >= 0.2: dict_7A1_over = make_count_dict(dict_7A1_over, locSeq7)
				m +=1
				continue
			elif seqToHitsTo6mer.has_key(locSeq6):		##6mer
				dict_6mer = make_count_dict(dict_6mer, locSeq6)
				if log2Fold >= 0.2: dict_6mer_over = make_count_dict(dict_6mer_over, locSeq6)
				m +=1
				continue
			else: m +=1
		else: break
	return motif_count_dict, motif_count_over_dict, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over, i


def get_motif_dict(geneAnno, nib, geneID_log2Fold, Xmer, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer):
	geneID_geneName = dict()
	geneID_motifDic = dict()
	motif_count_dict = dict()
	motif_count_over_dict = dict()
	dict_8mer = dict()
	dict_7m8 = dict()
	dict_7A1 = dict()
	dict_6mer = dict()
	dict_8mer_over = dict()
	dict_7m8_over = dict()
	dict_7A1_over = dict()
	dict_6mer_over = dict()
	genelist = filter(lambda x: geneID_log2Fold.has_key(x[0]), geneAnno.items())

	for gene in genelist:
		geneName = gene[1].name()
		geneID = gene[1].geneID()
		geneID_geneName[geneID] = geneName
		log2Fold = geneID_log2Fold[geneID]
		chr = gene[1].chr()
		sense = gene[1].sense()
		tpUTR = gene[1].tpUtr()
		tpExons = gene[1].tpExons(sense)
		tpUTRseq = getListSequence(tpExons, nib)
		motif_count_dict, motif_count_over_dict, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over, i = make_motif_dict(motif_count_dict, motif_count_over_dict, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over, tpUTRseq, Xmer, log2Fold, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer)
		geneID_motifDic[geneID] = motif_count_dict
	return geneID_geneName, geneID_motifDic, motif_count_dict, motif_count_over_dict, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over


def dataSetting(cell_line, miRNAtopX):
	if args.cellLine =="HeLa":
		nib = "/Data_Set/Genome/human/hg19/blat/"
		geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
		if miRNAtopX == "top10": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top10.txt"
		if miRNAtopX == "top30": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top30.txt"
		if miRNAtopX == "top50": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top50.txt"
	elif args.cellLine =="mES":
		nib ='/Data_Set/Genome/mouse/mm9/blat/'
		geneAnno = anno.getNewRefFlat("mm9", 'major', 'mESC')
		if miRNAtopX == "top10": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top10.txt"
		if miRNAtopX == "top30": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top30.txt"
		if miRNAtopX == "top50": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top50.txt"
	return geneAnno, nib, miRNAfile

def get_sorted_list(input_dict):
	sorted_list = []
	for key in sorted(input_dict, key=input_dict.get, reverse=True):
		sorted_list.append(key)
	return sorted_list

def get_sorted_total_list(input_dict, miRNA_combined_over_dict):
	sorted_dict = dict()
	for key in sorted(input_dict, key=input_dict.get, reverse=True):
		sorted_dict[key] = 0
	for key in sorted(miRNA_combined_over_dict, key=miRNA_combined_over_dict.get, reverse=True):
		sorted_dict[key] = 0
	return sorted_dict.keys()

def get_totalCount(input_dict):
	totalCount = sum(input_dict.values())
	return totalCount

def get_combined_miRNA_motif_dict(Xmer, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over):
	miRNA_combined_dict = dict()
	miRNA_combined_over_dict = dict()
	if Xmer == 8:
		miRNA_combined_dict = dict_8mer
		miRNA_combined_over_dict = dict_8mer_over
	elif Xmer == 7 or Xmer ==3 or Xmer ==4 or Xmer ==5:
		for motif_7m8 in dict_7m8.keys():
			if not dict_8mer.has_key(motif_7m8+"A"): dict_8mer[motif_7m8+"A"] = 0
			if not dict_7m8_over.has_key(motif_7m8): dict_7m8_over[motif_7m8] = 0
			if not dict_8mer_over.has_key(motif_7m8+"A"): dict_8mer_over[motif_7m8+"A"] = 0
			miRNA_combined_dict[motif_7m8] = dict_7m8[motif_7m8] + dict_8mer[motif_7m8+"A"]
			miRNA_combined_over_dict[motif_7m8] = dict_7m8_over[motif_7m8] + dict_8mer_over[motif_7m8+"A"]
		for motif_7A1 in dict_7A1.keys():
			if not dict_7A1_over.has_key(motif_7A1): dict_7A1_over[motif_7A1] = 0
			miRNA_combined_dict[motif_7A1] = dict_7A1[motif_7A1]
			miRNA_combined_over_dict[motif_7A1] = dict_7A1_over[motif_7A1]
	elif Xmer == 6:
		for motif_6mer in dict_6mer.keys():
			motif_7A1 = filter(lambda x: x[0:6] == motif_6mer, dict_7A1.keys())[0]
			motif_7m8 = filter(lambda x: x[1:7] == motif_6mer, dict_7m8.keys())[0]
			motif_8mer = filter(lambda x: x[1:7] == motif_6mer, dict_8mer.keys())[0]
			miRNA_combined_dict[motif_6mer] = dict_6mer[motif_6mer] + dict_7A1[motif_7A1] + dict_7m8[motif_7m8] + dict_8mer[motif_8mer]
			miRNA_combined_over_dict[motif_6mer] = dict_6mer_over[motif_6mer] + dict_7A1_over[motif_7A1] + dict_7m8_over[motif_7m8] + dict_8mer_over[motif_8mer]
	return miRNA_combined_dict, miRNA_combined_over_dict


def get_miRNA_dict_pValue(miRNA_dict, miRNA_dict_over, totalSeed, totalOverSeed, motif_pValue_dict, all_miRNA_pValue_list, all_miRNA_totalMotif_list, all_miRNA_overMotifCount_list):
	for miRNA_motif in miRNA_dict.keys():
		pValue = stats.hypergeom.sf(miRNA_dict_over[miRNA_motif]-1, totalSeed, totalOverSeed, miRNA_dict[miRNA_motif])
		motif_pValue_dict[miRNA_motif] = pValue
		# print miRNA_motif, pValue
		if pValue <0.005: 
			all_miRNA_pValue_list.append(pValue)
			all_miRNA_totalMotif_list.append(miRNA_dict[miRNA_motif])
			all_miRNA_overMotifCount_list.append(miRNA_dict_over[miRNA_motif])
	return motif_pValue_dict, all_miRNA_pValue_list, all_miRNA_totalMotif_list, all_miRNA_overMotifCount_list

def get_pValue_dict(motif_count_dict, motif_count_over_dict, totalSeed, totalOverSeed, miRNA_combined_dict, miRNA_combined_over_dict):
	motif_pValue_dict = dict()
	all_miRNA_pValue_list = []
	all_miRNA_totalMotif_list = []
	all_miRNA_overMotifCount_list = []
	motif_list = filter(lambda x: not (miRNA_combined_over_dict.has_key(x)), motif_count_over_dict.keys())
	for motif in motif_list:
		totalMotif = motif_count_dict[motif]
		overMotifCount = motif_count_over_dict[motif]
		pValue = stats.hypergeom.sf(overMotifCount-1, totalSeed, totalOverSeed, totalMotif)
		# pValue = stats.hypergeom(totalSeed, totalOverSeed, totalMotif).pmf(overMotifCount)
		motif_pValue_dict[motif] = pValue
		if motif == "CTG": print "CTG", totalMotif, overMotifCount, pValue
	motif_pValue_dict, all_miRNA_pValue_list, all_miRNA_totalMotif_list, all_miRNA_overMotifCount_list = get_miRNA_dict_pValue(miRNA_combined_dict, miRNA_combined_over_dict, totalSeed, totalOverSeed, motif_pValue_dict, all_miRNA_pValue_list, all_miRNA_totalMotif_list, all_miRNA_overMotifCount_list)
	all_miRNA_totalMotif = sum(all_miRNA_totalMotif_list)
	all_miRNA_overMotifCount = sum(all_miRNA_overMotifCount_list)
	all_miRNA_pValue = stats.combine_pvalues(all_miRNA_pValue_list, method = "fisher")[1]
	return motif_pValue_dict, all_miRNA_pValue, all_miRNA_totalMotif, all_miRNA_overMotifCount


def write_pValue_table(outputFileName, motif_sortedCount_over_list, motif_pValue_dict, motif_count_dict, motif_count_over_dict, all_miRNA_pValue, all_miRNA_totalMotif, all_miRNA_overMotifCount, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer, miRNA_combined_dict, miRNA_combined_over_dict, Xmer):
	outputFile = open(outputFileName,'w')
	outputFile.write("group" + "\t" + "motif" + "\t" + "miRNAname" + "\t" + "pValue" + "\t" + "pValue(log10)" + "\t" + "totalMotif" + "\t" + "MotifCount(log2Fold >= 0.2)" + "\n")
	for motif in motif_sortedCount_over_list:
		if Xmer == 8: 
			if seqToHitsTo8mer.has_key(motif): group = "miRNA (8mer)"; miRNAname = seqToHitsTo8mer[motif]; motif_count = miRNA_combined_dict[motif]; motif_count_over = miRNA_combined_over_dict[motif]
			else: group = "others (8mer)"; miRNAname = "none"; motif_count = motif_count_dict[motif]; motif_count_over = motif_count_over_dict[motif]
		if Xmer == 7 or Xmer ==3 or Xmer ==4 or Xmer ==5:
			if seqToHitsTo7m8.has_key(motif): group = "miRNA (7m8)"; miRNAname = seqToHitsTo7m8[motif]; motif_count = miRNA_combined_dict[motif]; motif_count_over = miRNA_combined_over_dict[motif]
			elif seqToHitsTo7A1.has_key(motif): group = "miRNA (7A1)"; miRNAname = seqToHitsTo7A1[motif]; motif_count = miRNA_combined_dict[motif]; motif_count_over = miRNA_combined_over_dict[motif]
			elif not (seqToHitsTo7m8.has_key(motif) or seqToHitsTo7A1.has_key(motif)): group = "others (7mer)"; miRNAname = "none"; motif_count = motif_count_dict[motif]; motif_count_over = motif_count_over_dict[motif]
		if Xmer == 6:
			if seqToHitsTo6mer.has_key(motif): group = "miRNA (6mer)"; miRNAname = seqToHitsTo6mer[motif]; motif_count = miRNA_combined_dict[motif]; motif_count_over = miRNA_combined_over_dict[motif]
			else: group = "others (6mer)"; miRNAname = "none"; motif_count = motif_count_dict[motif]; motif_count_over = motif_count_over_dict[motif]
		if motif_pValue_dict.has_key(motif):
			if motif_pValue_dict[motif] == 0:
				outputFile.write(group +"\t" + motif + "\t"+ miRNAname+ "\t"+ str(0) + "\t"+ str(0) + "\t"+ str(motif_count) + "\t"+  str(motif_count_over) + "\n")
			if not motif_pValue_dict[motif] == 0:
				outputFile.write(group +"\t" + motif + "\t"+ miRNAname+ "\t"+ str(motif_pValue_dict[motif]) + "\t"+ str(-math.log(motif_pValue_dict[motif], 10)) + "\t"+ str(motif_count) + "\t"+  str(motif_count_over) + "\n")
	outputFile.write("combined miRNA" +"\t" + "all_miRNA"+ "\t" +"all_miRNA"+ "\t"+ str(all_miRNA_pValue) + "\t"+ str(-math.log(all_miRNA_pValue, 10)) + "\t"+ str(all_miRNA_totalMotif) + "\t"+  str(all_miRNA_overMotifCount) + "\n")
	outputFile.close()

def write_significant_miRNA(signiMiRNA_outputFileName, motif_pValue_dict, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer, Xmer):
	outputFile = open(signiMiRNA_outputFileName, 'w')
	outputFile.write("group" + "\t" + "miRNAname" + "\t" + "motif" + "\t" + "pValue" + "\n")
	signi_miRNA_dict = dict()
	for motif in motif_pValue_dict.keys(): 
		pValue = motif_pValue_dict[motif]
		if Xmer == 8: 
			if seqToHitsTo8mer.has_key(motif): 
				group = "miRNA (8mer)"; miRNAname = seqToHitsTo8mer[motif]
				if pValue <= 0.005: outputFile.write(group + "\t" + miRNAname + "\t" + motif + "\t" + str(pValue) + "\n")
		if Xmer == 7 or Xmer ==3 or Xmer ==4 or Xmer ==5: 
			if seqToHitsTo7m8.has_key(motif): 
				group = "miRNA (7m8)"; miRNAname = seqToHitsTo7m8[motif]
				if pValue <= 0.005: outputFile.write(group + "\t" + miRNAname + "\t" + motif + "\t" + str(pValue) + "\n")
			if seqToHitsTo7A1.has_key(motif): 
				group = "miRNA (7A1)"; miRNAname = seqToHitsTo7A1[motif]
				if pValue <= 0.005: outputFile.write(group + "\t" + miRNAname + "\t" + motif + "\t" + str(pValue) + "\n")
		if Xmer == 6: 
			if seqToHitsTo6mer.has_key(motif): 
				group = "miRNA (6mer)"; miRNAname = seqToHitsTo6mer[motif]
				if pValue <= 0.005: outputFile.write(group + "\t" + miRNAname + "\t" + motif + "\t" + str(pValue) + "\n")
	outputFile.close()

def main(args):
	geneAnno, nib, miRNAfile = dataSetting(args.cellLine, args.miRNAtopX)
	print "Data setting is done"
	seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer = get_miRNAsites_dict(miRNAfile, args.Xmer)
	print "miRNA dict is done"
	geneID_log2Fold = get_geneID_log2Fold(args.foldChangeFile)
	geneID_sortedFPKM_list = get_sorted_list(geneID_log2Fold)
	print "log2 Fold dict is done"
	geneID_geneName, geneID_motifDic, motif_count_dict, motif_count_over_dict, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over = get_motif_dict(geneAnno, nib, geneID_log2Fold, args.Xmer, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer) 
	print "motif dict is done"
	totalSeed = get_totalCount(motif_count_dict)
	totalOverSeed = get_totalCount(motif_count_over_dict)
	miRNA_combined_dict, miRNA_combined_over_dict = get_combined_miRNA_motif_dict(args.Xmer, dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_8mer_over, dict_7m8_over, dict_7A1_over, dict_6mer_over)
	motif_sortedCount_over_list = get_sorted_total_list(motif_count_over_dict, miRNA_combined_over_dict)

	motif_pValue_dict, all_miRNA_pValue, all_miRNA_totalMotif, all_miRNA_overMotifCount = get_pValue_dict(motif_count_dict, motif_count_over_dict, totalSeed, totalOverSeed, miRNA_combined_dict, miRNA_combined_over_dict)
	print "all miRNA p-value: ", all_miRNA_pValue
	print "TotalSeed: " + str(totalSeed) + "\t" + "TotalOverSeed (log2Fold >= 0.2): " + str(totalOverSeed) + "\t" + "Total Motif (log2Fold >= 0.2): " + str(len(motif_count_over_dict.keys()))

	if not os.path.exists(args.outputDir): os.makedirs(args.outputDir)
	if not os.path.exists(args.outputDir+"/log/"): os.makedirs(args.outputDir+"/log/")
	outputFileName = args.outputDir + "/" + "_".join(args.foldChangeFile.split("/")[-1].split(".")[0].split("_")[0:4]) + "_motifEnrich_" + args.miRNAtopX + "_" + str(args.Xmer)+"mer_combined_7m8.txt"
	write_pValue_table(outputFileName, motif_sortedCount_over_list, motif_pValue_dict, motif_count_dict, motif_count_over_dict, all_miRNA_pValue, all_miRNA_totalMotif, all_miRNA_overMotifCount, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer, miRNA_combined_dict, miRNA_combined_over_dict, args.Xmer)
	signiMiRNA_outputFileName = args.outputDir + "/" + "_".join(args.foldChangeFile.split("/")[-1].split(".")[0].split("_")[0:4]) + "_motifEnrich_" + args.miRNAtopX + "_" + str(args.Xmer)+"mer_significant_0.005_miRNAlist_7m8.txt"
	write_significant_miRNA(signiMiRNA_outputFileName, motif_pValue_dict, seqToHitsTo8mer, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsTo6mer, args.Xmer)

if __name__ == '__main__':
	import argparse
	import os
	import math
	import numpy
	import scipy.stats as stats
	import re
	import annotationImporter as anno
	import utilityModule as util
	parser = argparse.ArgumentParser(description = "motif enrichment test of UPF1 KD target genes")
	parser.add_argument("-c", "--cellLine", default="HeLa", help = "HeLa / mES")
	parser.add_argument("-mi", "--miRNAtopX", default="top50", help = "miRNA top10 / top30 / top50")
	parser.add_argument("-x", "--Xmer", type = int, default="7", help="motif 6 / 7 / 8")
	parser.add_argument("-f", "--foldChangeFile", help = "potential NMD filteration file")
	parser.add_argument("-o", "--outputDir", help = "output directory")
	args = parser.parse_args()
	main(args)
