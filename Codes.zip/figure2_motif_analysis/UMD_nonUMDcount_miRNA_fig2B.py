


import sys, random, numpy, time, math, os
import annotationImporter as anno, utilityModule as util, UPF1module as Umodule
import AGO2_UPF1_miRNA_7A1_effect_module as mainModule
startT = time.time() 		#check elapse time
print "Start analysis: 00:00:00"

cellLine = "HeLa_BIGlab_Dicer_UPF1KD"
miRNA_top = "top50"
date = "20170322_UMD_nonUMD_miRNAcount"
randomRep = 100
analyType = "CUG"

chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
nib = "/Data_Set/Genome/human/hg19/blat/"
geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
if cellLine == "HeLa_BIGlab_Dicer_UPF1KD":
	expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/UPF1KD/HeLa_BIGlab_DicerExp_UPF1KD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	CUGmotifFile = open("/home/jwawon/Project/UPF1/14.CUGmotif/CUGmotif.txt", "r")
	outputDir = "/home/jwawon/Project/UPF1/14.CUGmotif/Dicer_Exp/UPF1KD/" + date + "/"

if miRNA_top == "top50": 
	miRNA = open("/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top50.txt",'r')
	signi_miRNA = open("/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170305_new_miRNA/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_7mer_significant_0.005_miRNAlist_7m8.txt", 'r')


if not os.path.exists(outputDir): os.makedirs(outputDir)


def getLocus(chr, sense, tpUTRstart, siteType, miRNAindex):
	if siteType =="8mer": plusIndex = 7
	if siteType =="7m8" or siteType =="7A1": plusIndex = 6
	if siteType =="6mer": plusIndex = 5
	if siteType =="CUG": plusIndex = 2
	if sense == "+": miRNAlocus = Umodule.Locus(chr, tpUTRstart + miRNAindex , tpUTRstart + miRNAindex +plusIndex+1, sense)
	else: miRNAlocus = Umodule.Locus(chr, tpUTRstart - miRNAindex - plusIndex -1, tpUTRstart - miRNAindex, sense)
	return miRNAlocus

def get_signiMiRNAlist(signi_miRNA):
	signiMiRNAseed_dict = dict()
	signi_miRNAlist = signi_miRNA.readlines()
	for lines in signi_miRNAlist[1:]:
		line_list = lines.strip().split("\t")
		# print line_list
		group = line_list[0].split(" ")[-1].strip("()")
		if group == '7m8':
			seed_7m8 = line_list[2]
			miRNAname = line_list[1]
			signiMiRNAseed_dict[seed_7m8] = miRNAname
			seed_8mer = line_list[2] +"A"
			miRNAname = line_list[1]
			signiMiRNAseed_dict[seed_8mer] = miRNAname
		elif group == "7A1":
			seed_7A1 = line_list[2]
			miRNAname = line_list[1]
			signiMiRNAseed_dict[seed_7A1] = miRNAname
	return signiMiRNAseed_dict
signiMiRNAseed_dict = get_signiMiRNAlist(signi_miRNA)



############################ Data Setting ###################################
## make geneID list of inputed expressionFile file 


expressionFileOpen = open(expressionFile, 'r')
expressionFilelist = expressionFileOpen.readlines()
expressionFileOpen.close()


geneID_fpkm_dict = dict()
geneID_UMDgroup = dict()
for lines in expressionFilelist:
	line = lines.strip('\n').split('\t')
	geneID = line[0]
	fpkm = float(line[3])
	if fpkm >= 0.2: geneID_UMDgroup[geneID] = "UMD"
	else: geneID_UMDgroup[geneID] = "nonUMD"
	geneID_fpkm_dict[geneID] = fpkm


#/////////////////////////////////////////////////////////////////
## make hash tables of motif list

CUGmotifLine_list = CUGmotifFile.readlines()
CUGmotifFile.close()

if analyType == "CUGmotif":
	CUGmotif_dict = dict()
	for lines in CUGmotifLine_list:
		line_list = lines.strip().split("\t")
		CUGmotif_dict[line_list[1]] = line_list[0]
elif analyType == "CUG":
	CUGmotif_dict = {"CTG":"CUGmotif"}



#/////////////////////////////////////////////////////////////////
## make hash tables of miRNA list


miRNA_list = miRNA.readlines()
miRNA.close()

sevenD = dict()
seedD = dict()
seqToHitsTo8m = dict()
seqToHitsTo7m8 = dict()
seqToHitsTo7A1 = dict()
seqToHitsToSeed = dict()
miRNAseqDic = dict()


for miRNA_lines in miRNA_list:
	line = miRNA_lines.strip().split('\t')
	miRNAName = line[0][1:]
	miRNAseq = line[2]
	miRNAseqDic[miRNAseq] = miRNAName
	sevenSeq = util.reverseComp(util.UtoT(miRNAseq[1:8]))
	seedSeq = util.reverseComp(util.UtoT(miRNAseq[1:7]))
	if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = miRNAName
	if not (seedD.has_key(seedSeq)): seedD[seedSeq] = miRNAName
	miRlength = len(miRNAseq)

for seedKey in seedD.keys():
	seedseq = seedKey.upper()
	seqToHitsToSeed[seedseq] = seedD[seedKey]+"(6mer)"
	seqToHitsTo7A1[seedseq + 'A'] = seedD[seedKey]+"(7A1)"
for sevenKey in sevenD.keys():
	sevenseq = sevenKey.upper()
	seqToHitsTo8m[sevenseq + 'A'] = sevenD[sevenKey]+"(8mer)"
	seqToHitsTo7m8[sevenseq] = sevenD[sevenKey]+"(7m8)"

random_miRNA_rep100_list = []
for i in range(0,randomRep):
	miRNAseq_list = miRNAseqDic.keys()
	random.shuffle(miRNAseq_list)
	miRrandomSeq = miRNAseq_list[0]
	diNuList = []
	for j in range(0, len(miRrandomSeq), 2):
		diNuList.append(miRrandomSeq[j:j+2])
	random_miRNAseqList = []
	n = 0
	while n < 50:
		random.shuffle(diNuList)
		randomSeq = ''.join(diNuList)
		randomSeedSeq = util.reverseComp(util.UtoT(randomSeq[1:7]))
		if not seqToHitsToSeed.has_key(randomSeedSeq):
			if not randomSeq in random_miRNAseqList:
				random_miRNAseqList.append(randomSeq)
				n += 1
	random_seqToHitsToSites_list, random_miSeq_dic = mainModule.get_miRNAsites_dic(random_miRNAseqList, "random")
	random_miRNA_rep100_list.append(random_seqToHitsToSites_list)

#///////////////////////// elapsed time check /////////////////////
miRDataSettingT = time.time()            #check miRDataSettingT elapse time
miRDataElapseT = Umodule.elapseTime(startT,miRDataSettingT)
print "Finish the miRNA data setting: ", miRDataElapseT 


################################## step1 ######################################
## make expressionFile 3'UTR loci list with AGO, UPF1 and sites

allgeneID_list = []
geneID_tpUTRseq = dict()
geneID_geneName = dict()
geneID_tpUTRlength_dict = dict()
geneID_miRNAtarget= dict()
geneID_miRNA_8merTo7A1 = dict()
geneID_CUGmotif = dict()
miSiteLocus_Name = dict()
CUGlocus_motif = dict()

genelist = filter(lambda x: geneID_fpkm_dict.has_key(x[0]), geneAnno.items())

TotalgeneC = len(genelist)
geneC = 0
geneID_strand = dict()
CUGmotif_count = 0
random_dict = dict()

UMD_random_list = []
nonUMD_random_list = []

UMD_CUG_count = 0
nonUMD_CUG_count = 0
UMD_random_count = 0
nonUMD_random_count = 0

for gene in  genelist:
	geneC += 1
	status = int(float(geneC)/float(TotalgeneC) * 100)
	geneName = gene[1].name()
	geneID = gene[1].geneID()
	geneID_geneName[geneID] = geneName
	allgeneID_list.append(geneID) 
	chr = gene[1].chr()
	sense = gene[1].sense()
	geneID_strand[geneID] = sense
	tpExons = gene[1].tpExons(sense)
	tpUTRseq = Umodule.getListSequence(tpExons, nib)
	geneID_tpUTRseq[geneID] = tpUTRseq
	tpUTRlen = len(tpUTRseq)
	geneID_tpUTRlength_dict[geneID] = tpUTRlen
	if sense == "+": tpUTRstart = gene[1].tpUtr().start()
	else: tpUTRstart = gene[1].tpUtr().end()
	geneID_CUGmotif[geneID] = []
	geneID_miRNAtarget[geneID] = []
	geneID_miRNA_8merTo7A1[geneID] = []
	group = geneID_UMDgroup[geneID]

	skip = "off"
	m = 0
	for n in xrange(len(tpUTRseq) - miRlength + 1):
		if m <= len(tpUTRseq) - miRlength + 1:
			locSeq8 = tpUTRseq[m:m+8]
			locSeq7 = tpUTRseq[m:m+7]
			locSeq6 = tpUTRseq[m:m+6]
			if seqToHitsTo8m.has_key(locSeq8):
				siteLocus = getLocus(chr, sense, tpUTRstart, "8mer", m)
				if signiMiRNAseed_dict.has_key(locSeq8): miSiteLocus_Name[siteLocus] = seqToHitsTo8m[locSeq8] + "_signi"
				else: miSiteLocus_Name[siteLocus] = seqToHitsTo8m[locSeq8] + "_insigni"
				geneID_miRNAtarget[geneID].append(siteLocus)
				geneID_miRNA_8merTo7A1[geneID].append(siteLocus)
				skip = "on"
				m += 8
				continue
			elif seqToHitsTo7m8.has_key(locSeq7):
				siteLocus = getLocus(chr, sense, tpUTRstart, "7m8", m)
				if signiMiRNAseed_dict.has_key(locSeq8): miSiteLocus_Name[siteLocus] = seqToHitsTo7m8[locSeq7] + "_signi"
				else: miSiteLocus_Name[siteLocus] = seqToHitsTo7m8[locSeq7] + "_insigni"
				geneID_miRNAtarget[geneID].append(siteLocus)
				geneID_miRNA_8merTo7A1[geneID].append(siteLocus)
				skip = "on"
				m += 7
				continue
			elif seqToHitsTo7A1.has_key(locSeq7):
				siteLocus = getLocus(chr, sense, tpUTRstart, "7A1", m)
				if signiMiRNAseed_dict.has_key(locSeq8): miSiteLocus_Name[siteLocus] = seqToHitsTo7A1[locSeq7] +  "_signi"
				else: miSiteLocus_Name[siteLocus] = seqToHitsTo7A1[locSeq7] + "_insigni"
				geneID_miRNAtarget[geneID].append(siteLocus)
				geneID_miRNA_8merTo7A1[geneID].append(siteLocus)
				skip = "on"
				m += 7
				continue
			elif seqToHitsToSeed.has_key(locSeq6):
				siteLocus = getLocus(chr, sense, tpUTRstart, "6mer", m)
				geneID_miRNAtarget[geneID].append(siteLocus)
				skip = "on"
				m += 6
			else: 
				skip = "off"
				m += 1
		else: break
	sys.stdout.write("\r%s%d%%" % ("miRNA target analysis status: ", status))
	sys.stdout.flush()

analysisT = time.time()
analysisElapseT = Umodule.elapseTime(startT,analysisT)
print '\n'+ "Finish miRNA target analysis, it's elapse time: " + analysisElapseT 

UMD_count_File = open(outputDir+cellLine +'_' + miRNA_top +'_UMD_nonUMD_miRNAcount', 'w')

UMD_miRNA_count = 0
nonUMD_miRNA_count = 0

for geneID in geneID_miRNA_8merTo7A1.keys():
	group = geneID_UMDgroup[geneID]
	if group == "UMD": UMD_miRNA_count+=len(geneID_miRNA_8merTo7A1[geneID])
	if group == "nonUMD": nonUMD_miRNA_count+=len(geneID_miRNA_8merTo7A1[geneID])

print "UMD miRNA sites count: " + "\t" + str(UMD_miRNA_count)
print "nonUMD miRNA sites count: " + "\t" + str(nonUMD_miRNA_count)

UMD_randomMiRNA_count_list = []
nonUMD_randomMiRNA_count_list = []

random_siteLocus_name = dict()
for i, random_miRNA in enumerate(random_miRNA_rep100_list):
	UMD_randomMiRNA_count = 0
	nonUMD_randomMiRNA_count = 0
	random_dict[i] = dict()
	random_siteLocus_name[i] = dict()
	for gene in genelist:
		geneName = gene[1].name()
		geneID = gene[1].geneID()
		chr = gene[1].chr()
		sense = gene[1].sense()
		tpUTR = gene[1].tpUtr()
		tpExons = gene[1].tpExons(sense)
		tpUTRseq = geneID_tpUTRseq[geneID]
		if sense == "+": tpUTRstart = tpUTR.start()
		else: tpUTRstart = tpUTR.end()
		dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites = mainModule.searchMiRNAsite(chr, sense, tpUTRseq, tpUTRstart, random_miRNA, "7A1")
		group = geneID_UMDgroup[geneID]
		if group == "UMD": UMD_randomMiRNA_count+=len(dict_sites.keys())
		elif group == "nonUMD": nonUMD_randomMiRNA_count+=len(dict_sites.keys())
	UMD_randomMiRNA_count_list.append(UMD_randomMiRNA_count)
	nonUMD_randomMiRNA_count_list.append(nonUMD_randomMiRNA_count)
	sys.stdout.write("\r%s%d%%" % ("random miRNA list status: ", i))
	sys.stdout.flush()

print "UMD random sites count: " + "\t" + str(numpy.mean(UMD_randomMiRNA_count_list))
print "nonUMD random sites count: " + "\t" + str(numpy.mean(nonUMD_randomMiRNA_count))

UMD_count_File.write("UMD miRNA sites count: " + "\t" + str(UMD_miRNA_count)+"\n")
UMD_count_File.write("nonUMD miRNA sites count: " + "\t" + str(nonUMD_miRNA_count)+"\n")
UMD_count_File.write("UMD random sites count: " + "\t" + str(numpy.mean(UMD_randomMiRNA_count_list))+"\n")
UMD_count_File.write("nonUMD random sites count: " + "\t" + str(numpy.mean(nonUMD_randomMiRNA_count))+"\n")

