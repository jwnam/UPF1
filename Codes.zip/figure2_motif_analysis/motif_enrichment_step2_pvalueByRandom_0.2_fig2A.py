

## make geneID list of inputed expressionFile file 
def get_motifCount_file(motifCountFile):
	motif_countDict = dict()
	motif_infoDict = dict()
	motifCountFileOpen = open(motifCountFile, 'r')
	motifCountFileLines = motifCountFileOpen.readlines()
	motifCountFileOpen.close()
	totalSum = 0
	for line in motifCountFileLines[1:]:
		lineList = line.strip().split('\t')
		motif = lineList[1]; totalCount = float(lineList[5]); overCount = float(lineList[6])
		group = lineList[0]; name = lineList[2];
		underCount = totalCount - overCount
		totalSum += totalCount
		if not motif == "all_miRNA":
			motif_countDict[motif] = [overCount, underCount]
			motif_infoDict[motif] = [group, name]
	return motif_countDict, motif_infoDict, totalSum


def dataSetting(DataType):
	motifAnalysisDir = "/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/"
	if args.DataType =="UPF1_7mer":
		normfileName = "20170313_miRNA_new_combined_pValue/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_7mer_combined_7m8.txt"
		randomfileName = "20170813_random/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_7mer_combined_7m8.txt"
	if args.DataType =="UPF1_3mer":
		normfileName = "20170803_tripleNu/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_3mer_combined_7m8.txt"
		randomfileName = "20170813_3mer_random/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_3mer_combined_7m8.txt"
	if args.DataType =="UPF1_4mer":
		normfileName = "20170804_4mer/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_4mer_combined_7m8.txt"
		randomfileName = "20170813_4mer_random/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_4mer_combined_7m8.txt"
	if args.DataType =="SMG7_7mer":
		normfileName = "20170804_smg7/HeLa_BIGlab_SMG7KD_onetpEx_motifEnrich_top50_7mer_combined_7m8.txt"
		randomfileName = "20170813_smg7_random/HeLa_BIGlab_SMG7KD_onetpEx_motifEnrich_top50_7mer_combined_7m8.txt"
	normMotif_dict, normMotif_infoDict, normTotalSum = get_motifCount_file(motifAnalysisDir+normfileName)
	randomMotif_dict, randomMotif_infoDict, randomTotalSum = get_motifCount_file(motifAnalysisDir+randomfileName)
	return normMotif_dict, randomMotif_dict, normMotif_infoDict, normTotalSum

def get_pValue_dict(normMotif_dict, randomMotif_dict, normTotalSum):
	motif_pValue_dict = dict()
	for motif in normMotif_dict.keys():
		## normal motif   >=0.2  |  all
		## random motif   >=0.2  |  all
		oddsratio, pValue = stats.fisher_exact([[normMotif_dict[motif][0], normTotalSum], [randomMotif_dict[motif][0], normTotalSum]], alternative = "greater")
		motif_pValue_dict[motif] = pValue
	return motif_pValue_dict


def write_pValue_table(outputDir, DataType, motif_pValue_dict, normMotif_dict, randomMotif_dict,normMotif_infoDict, normTotalSum):
	if not os.path.exists(outputDir): os.makedirs(outputDir)
	if not os.path.exists(outputDir+"/log/"): os.makedirs(outputDir+"/log/")
	outputFileName = outputDir + "/" + DataType + "_motifEnrich_normal_random.txt"
	outputFile = open(outputFileName,'w')
	outputFile.write("group" + "\t" + "motif" + "\t" + "name" + "\t" + "pValue" + "\t" + "pValue(log10)" + "\t" + "MotifCount(log2Fold >= 0.2)"+ "\t"  + "randomCount(log2Fold >= 0.2)" + "\t" + "totalCount" + "\n")
	for motif in motif_pValue_dict.keys():
		if randomMotif_dict.has_key(motif):
			group = normMotif_infoDict[motif][0]; name = normMotif_infoDict[motif][1]
			if motif_pValue_dict[motif] == 0:
				outputFile.write(group +"\t" + motif + "\t"+ name+ "\t"+ str(0) + "\t"+ str(0) + "\t"+ str(normMotif_dict[motif][0]) +"\t"+ str(randomMotif_dict[motif][0]) + "\t"+  str(normTotalSum) + "\n")
			if not motif_pValue_dict[motif] == 0:
				outputFile.write(group +"\t" + motif + "\t"+ name+ "\t"+ str(motif_pValue_dict[motif]) + "\t"+ str(-math.log(motif_pValue_dict[motif], 10)) + "\t"+ str(normMotif_dict[motif][0])+"\t"+ str(randomMotif_dict[motif][0]) + "\t"+  str(normTotalSum) + "\n")
	outputFile.close()

def main(args):
	normMotif_dict, randomMotif_dict, normMotif_infoDict, normTotalSum = dataSetting(args.DataType)
	motif_pValue_dict = get_pValue_dict(normMotif_dict, randomMotif_dict, normTotalSum)
	write_pValue_table(args.outputDir, args.DataType, motif_pValue_dict, normMotif_dict, randomMotif_dict, normMotif_infoDict, normTotalSum)

if __name__ == '__main__':
	import os
	import math
	import argparse
	import scipy.stats as stats
	parser = argparse.ArgumentParser(description = "motif enrichment test of UPF1 KD target genes")
	parser.add_argument("-d", "--DataType", default="UPF1", help = "UPF1_7mer / SMG7_7mer / UPF1_3mer / UPF1_4mer")
	parser.add_argument("-o", "--outputDir", help = "output directory")
	args = parser.parse_args()
	main(args)
