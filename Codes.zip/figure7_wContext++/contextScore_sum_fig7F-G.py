


def readFile(file):
	f = open(file, 'r')
	fLine = f.readlines()
	f.close()
	return fLine

def makeDic_list(dictName, keyName, valueName):
	if dictName.has_key(keyName): dictName[keyName].append(valueName)
	else: dictName[keyName] =[valueName]
	return dictName

class contextScore:
	def __init__(self, ensTxID, geneSymbol, miRNA7m8seed, repMiRNA, wContextPPscore):
		self._ensTxID = ensTxID
		self._geneSymbol = geneSymbol
		self._miRNA7m8seed = miRNA7m8seed
		self._repMiRNA = repMiRNA
		self._wContextPPscore = float(wContextPPscore)
	def geneSymbol(self): return self._ensTxID
	def miRNA7m8seed(self): return self._miRNA7m8seed
	def repMiRNA(self): return self._repMiRNA
	def wContextPPscore(self): return self._wContextPPscore

def getContextScore(contextFile):
	filteredContext_line_list = [] 
	gene_contextObj_dict = dict()
	contextLines = readFile(contextFile)
	lineCount = 0
	for line in contextLines[1:]:
		lineCount+=1
		status = int((float(lineCount))/float(len(contextLines)) *100)
		line_list = line.strip().split("\t")
		if line_list[3] == "9606":
			ensTxID = line_list[0]; geneSymbol = line_list[1]; miRNA7m8seed = line_list[2]; 
			species = line_list[3]; repMiRNA = line_list[13]; wContextPPscore = line_list[15]
			if not wContextPPscore == "NULL":
				filteredContext_line_list.append(line)
				contextScoreObj = contextScore(ensTxID, geneSymbol, miRNA7m8seed, repMiRNA, wContextPPscore)
				if gene_contextObj_dict.has_key(geneSymbol): gene_contextObj_dict[geneSymbol].append(contextScoreObj)
				else: gene_contextObj_dict[geneSymbol] = [contextScoreObj] 
		# sys.stdout.write("\r%s%d%%" % ("Context file loading status: ", status))
		# sys.stdout.flush()
	return gene_contextObj_dict, filteredContext_line_list

def getTargetGenesDic(targetGeneFile):
	targetGeneName_dict = dict()
	targetGeneLines = readFile(targetGeneFile)
	for line in targetGeneLines[1:]:
		line_list = line.strip().split("\t")
		targetGeneName_dict[line_list[1]] = [float(line_list[3]),line_list[2]]
	return targetGeneName_dict

class value:
	# parsing miRNA transfection values
	def __init__(self, geneID, geneName, headerList, infoLineList, index):
		self._geneID = geneID
		self._geneName = geneName
		self._header = headerList[index]
		self._value = infoLineList[index]
	def geneID(self): return self._geneID
	def geneName(self): return self._geneName
	def header(self): return self._header
	def value(self): return self._value

def get_miRNAtransfectInfo(miRNA_transfect_file):
	miTransf_header_valueObj_dict = dict()
	miTransf_geneName_expValue_dict = dict()
	fileLines = readFile(miRNA_transfect_file)
	header = fileLines[2]
	headerList = header.strip().split("\t")
	infoLines = fileLines[3:]
	for infoLine in infoLines:
		infoLineList = infoLine.strip().split("\t")
		geneID = infoLineList[0]
		geneName = infoLineList[2]
		for index in range(3,len(infoLineList)):
			valueObj = value(geneID, geneName, headerList, infoLineList, index)
			expValue = valueObj.value()
			if not expValue == "N/A": makeDic_list(miTransf_geneName_expValue_dict, geneName, float(expValue))
			# print valueObj.header(), valueObj.geneID(), valueObj.geneName(), valueObj.value()
			makeDic_list(miTransf_header_valueObj_dict, valueObj.header(), valueObj)
	miTransf_geneName_AvgExpValue_dict = dict()
	for geneName in miTransf_geneName_expValue_dict:
		miTransf_geneName_AvgExpValue_dict[geneName] = numpy.mean(miTransf_geneName_expValue_dict[geneName])
	return miTransf_header_valueObj_dict, miTransf_geneName_AvgExpValue_dict

def getData(miRNA_top, experiment):
	## NMD filtered all genes
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	if experiment == "DICER1KD": expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/DicerKD/HeLa_BIGlab_DicerExp_DicerKD_UPF1KD_to_DicerKD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	if experiment == "UPF1KD": expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/UPF1KD/HeLa_BIGlab_DicerExp_UPF1KD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	if experiment == "SMG7KD": expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/smg7_Exp/HeLa_BIGlab_SMG7KD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	if experiment == "TNRC6KD_UPF1KD_to_TNRC6KD": expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/TNRC6_Exp/TNRC6KD/HeLa_BIGlab_TNRC6KD_UPF1KD_to_TNRC6KD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	if experiment == "TNRC6KD_UPF1KD_to_UPF1KD": expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/TNRC6_Exp/UPF1KD/HeLa_BIGlab_TNRC6KD_UPF1KD_to_UPF1KD_onetpEx_noNMD_offtarget_all_medianNorm.txt"
	if experiment == "Wang_UPF1KD": expressionFile = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/Wang/HeLa_Wang_onetpEx_noNMD_offtarget_all_medianNorm.txt"

	## consider significantly / insignificantly enriched miRNA and UPF1 response genes
	if miRNA_top == "top10": 
		miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top10.txt"
		signi_miRNAfile = "/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170313_miRNA_new_combined_pValue/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top10_7mer_significant_0.005_miRNAlist_7m8.txt"
		targetGeneFile = "/home/jwawon/Project/UPF1/12.DicerOX_UPF1OX_analysis/top10/20170314_new_top10/UPF1KD_02up_sites_allGenes.txt"
		targetGeneName_dict = getTargetGenesDic(targetGeneFile)
	if miRNA_top == "top30": 
		miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top30.txt"
		signi_miRNAfile = "/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170313_miRNA_new_combined_pValue/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top30_7mer_significant_0.005_miRNAlist_7m8.txt"
		targetGeneFile = "/home/jwawon/Project/UPF1/12.DicerOX_UPF1OX_analysis/top30/20170314_new_top30/UPF1KD_02up_sites_allGenes.txt"
		targetGeneName_dict = getTargetGenesDic(targetGeneFile)
	if miRNA_top == "top50": 
		miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_new_top50.txt"
		signi_miRNAfile = "/home/jwawon/Project/UPF1/10.motif_enrichment_offTarget/20170313_miRNA_new_combined_pValue/HeLa_BIGlab_DicerExp_UPF1KD_motifEnrich_top50_7mer_significant_0.005_miRNAlist_7m8.txt"
		targetGeneFile = "/home/jwawon/Project/UPF1/12.DicerOX_UPF1OX_analysis/top50/20170314_new_top50/UPF1KD_02up_sites_allGenes.txt"
		targetGeneName_dict = getTargetGenesDic(targetGeneFile)
	## vikram miRNA transfection data
	miRNA_transfect_file = "/home/jwawon/Project/UPF1/11.contextModel/vikram_sRNA/vikram_elife_supp1_miRNAtransfection_normalized.txt"

	return geneAnno, miRNAfile, signi_miRNAfile, targetGeneName_dict, expressionFile, miRNA_transfect_file

def get_miRNAsites_dic(miRNAfileOrlist):
	sevenD = dict()
	seedD = dict()
	seqToHitsTo7m8 = dict()
	miRNAseqDic = dict()
	miRNAfileOpen = open(miRNAfileOrlist, 'r')
	miRNAfileLines = miRNAfileOpen.readlines()
	miRNAfileOpen.close()
	for line in miRNAfileLines:
		lineList = line.strip().split('\t')
		miRNAName = lineList[0].strip(">")
		seq = lineList[2][1:8]
		miRNAseqDic[seq] = miRNAName
	return miRNAseqDic

def get_signiMiRNAlist(signi_miRNAfile):
	signiMiRNA_dict = dict()
	signi_miRNAfileOpen = open(signi_miRNAfile, 'r')
	signi_miRNAlist = signi_miRNAfileOpen.readlines()
	for lines in signi_miRNAlist[1:]:
		line_list = lines.strip().split("\t")
		group = line_list[0].split(" ")[-1].strip("()")
		if group == '7m8':
			seed_7m8 = line_list[2]
			miRNAname = line_list[1]
			signiMiRNA_dict[miRNAname] = 0
	return signiMiRNA_dict

def getSumScore(scoreList):
	if len(scoreList) > 0: sum_scoreList = sum(scoreList)
	else: sum_scoreList = 0
	return sum_scoreList

class combinedInfo:
	def __init__(self, geneName, UPF1target, log2Fold, group, contextObj,miRNAseqDic,signiMiRNA_dict):
		self._geneName = geneName
		self._UPF1target = UPF1target
		self._log2Fold = log2Fold
		self._group = group
		self._miRNA7m8seed = contextObj.miRNA7m8seed()
		self._wContextPPscore = contextObj.wContextPPscore()

def checkVikramData(geneAnno, gene_contextObj_dict, miTransf_geneName_AvgExpValue_dict, vikram_outputDir_topX):
	vikram_context_exp_all = open(vikram_outputDir_topX + "/" + "vikram_allGenes_wContextPP_expValue.txt", 'w')
	vikram_context_exp_all.write("geneName" + "\t"+ "geneID" + "\t" + "wContextPPscore" + "\t" + "mean(log2, vikram data)" + "\n")
	binningAllGeneVikramExp_dict = dict()
	genelist = filter(lambda x: miTransf_geneName_AvgExpValue_dict.has_key(x[1].name()), geneAnno.items())
	for gene in genelist:
		geneName = gene[1].name()
		geneID = gene[1].geneID()
		if gene_contextObj_dict.has_key(geneName):
			wContextPPscore_list = []
			for contextObj in gene_contextObj_dict[geneName]:
				wContextPPscore_list.append(contextObj.wContextPPscore())
			sum_wContextPPscore = getSumScore(wContextPPscore_list)
		# print geneName, geneID, sum_wContextPPscore, miTransf_geneName_AvgExpValue_dict[geneName]
		vikram_context_exp_all.write(geneName +"\t" + geneID + "\t"+ str(sum_wContextPPscore) + "\t"+ str(miTransf_geneName_AvgExpValue_dict[geneName]) + "\n")
		if sum_wContextPPscore > -0.2: 
			binningAllGeneVikramExp_dict = makeDic_list(binningAllGeneVikramExp_dict, 0, miTransf_geneName_AvgExpValue_dict[geneName])
		elif -0.2 >= sum_wContextPPscore and sum_wContextPPscore > -0.4: 
			binningAllGeneVikramExp_dict = makeDic_list(binningAllGeneVikramExp_dict, -0.2, miTransf_geneName_AvgExpValue_dict[geneName])
		elif -0.4 >= sum_wContextPPscore > -0.6: 
			binningAllGeneVikramExp_dict = makeDic_list(binningAllGeneVikramExp_dict, -0.4, miTransf_geneName_AvgExpValue_dict[geneName])
		elif -0.6 >= sum_wContextPPscore: 
			binningAllGeneVikramExp_dict = makeDic_list(binningAllGeneVikramExp_dict, -0.6, miTransf_geneName_AvgExpValue_dict[geneName])
	vikram_binningContext_exp_all = open(vikram_outputDir_topX + "/" + "vikram_binning_wContextPP_expValue.txt", 'w')
	vikram_binningContext_exp_all.write("bin" + "\t"+ "count" + "\t" + "Mean" + "\t" + "median" + "\t" + "std" + "\t"+ "ste" + "\t" + "Pvalue" + "\n")
	binningAllGeneVikramExp_pValue_dict = mainModule.getGroupRankSumPvalue(binningAllGeneVikramExp_dict)
	for binScore in [0,-0.2,-0.4,-0.6]:
		vikram_binningContext_exp_all.write(str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(binningAllGeneVikramExp_dict[binScore]))) + "\t" + "|".join(binningAllGeneVikramExp_pValue_dict[binScore]) + "\n")
	vikram_context_exp_all.close()
	vikram_binningContext_exp_all.close()


def combine_log2Fold_contextScore(geneAnno, geneID_fpkmLength, gene_contextObj_dict, targetGeneName_dict, miRNAseqDic, signiMiRNA_dict):
	genelist = filter(lambda x: geneID_fpkmLength.has_key(x[0]), geneAnno.items())
	geneName_allInfo_dict = dict()
	geneName_supported = []
	geneName_notSupported = []
	for gene in genelist:
		wContextPPscore_list = []
		wContextPPscore_signilist = []
		wContextPPscore_InSignilist = []
		wContextPPscore_miR24 = []
		geneName = gene[1].name()
		geneID = gene[1].geneID()
		log2Fold = geneID_fpkmLength[geneID][0]
		if gene_contextObj_dict.has_key(geneName):
			if targetGeneName_dict.has_key(geneName): 
				group = targetGeneName_dict[geneName][1]; UPF1target = "O"
			else: group = "None"; UPF1target = "X"
			for contextObj in gene_contextObj_dict[geneName]:
				miRNA7m8seed = contextObj.miRNA7m8seed()
				wContextPPscore = contextObj.wContextPPscore()
				if miRNAseqDic.has_key(miRNA7m8seed): 
					wContextPPscore_list.append(wContextPPscore)
					if signiMiRNA_dict.has_key(miRNAseqDic[miRNA7m8seed]):
						wContextPPscore_signilist.append(wContextPPscore)
					else: wContextPPscore_InSignilist.append(wContextPPscore)
					if miRNAseqDic[miRNA7m8seed] == "hsa-miR-24-3p": wContextPPscore_miR24.append(wContextPPscore)

			sum_wContextPPscore = getSumScore(wContextPPscore_list)
			sum_wContextPPscore_signi = getSumScore(wContextPPscore_signilist)
			sum_wContextPPscore_InSigni = getSumScore(wContextPPscore_InSignilist)
			sum_wContextPPscore_miR24 = getSumScore(wContextPPscore_miR24)

			# print "matchedID: ", geneName, UPF1target, log2Fold, group, sum_wContextPPscore, sum_wContextPPscore_signi, sum_wContextPPscore_InSigni
			geneName_supported.append(geneName)
			geneName_allInfo_dict[geneName] = [log2Fold, UPF1target, group, sum_wContextPPscore, sum_wContextPPscore_signi, sum_wContextPPscore_InSigni, sum_wContextPPscore_miR24]
		else: 
			geneName_notSupported.append(geneName)
	print "total genes: ", len(genelist)
	print "contextScore supported: ", len(geneName_supported)
	print "contextScore not supported: ", len(geneName_notSupported)
	return geneName_allInfo_dict, geneName_supported, geneName_notSupported

def makeOutputDir(outputDir, miRNAtopX):
	if not os.path.exists(outputDir): os.makedirs(outputDir)
	outputDir_topX = outputDir + "/" + miRNAtopX
	logDir = outputDir + "/" + miRNAtopX +"/log/"
	if not os.path.exists(logDir): os.makedirs(logDir)
	return outputDir_topX


def scoreBinning(geneName_allInfo_dict, index, miTransf_geneName_AvgExpValue_dict):
	binningGen_dict = dict()
	binningFold_dict = dict()
	binningVikramExp_dict = dict()
	binningVikramExp_UPF1O_dict = dict()
	binningVikramExp_UPF1X_dict = dict()
	for geneName in geneName_allInfo_dict:
		wContextPPscore = geneName_allInfo_dict[geneName][index]
		log2Fold = geneName_allInfo_dict[geneName][0]
		UPF1target = geneName_allInfo_dict[geneName][1]
		if wContextPPscore > -0.2: 
			binningGen_dict = makeDic_list(binningGen_dict, 0, geneName)
			binningFold_dict = makeDic_list(binningFold_dict, 0, log2Fold)
			if miTransf_geneName_AvgExpValue_dict.has_key(geneName): 
				binningVikramExp_dict = makeDic_list(binningVikramExp_dict, 0, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "O": binningVikramExp_UPF1O_dict = makeDic_list(binningVikramExp_UPF1O_dict, 0, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "X": binningVikramExp_UPF1X_dict = makeDic_list(binningVikramExp_UPF1X_dict, 0, miTransf_geneName_AvgExpValue_dict[geneName])
		elif -0.2 >= wContextPPscore and wContextPPscore > -0.4: 
			binningGen_dict = makeDic_list(binningGen_dict, -0.2, geneName)
			binningFold_dict = makeDic_list(binningFold_dict, -0.2, log2Fold)
			if miTransf_geneName_AvgExpValue_dict.has_key(geneName): 
				binningVikramExp_dict = makeDic_list(binningVikramExp_dict, -0.2, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "O": binningVikramExp_UPF1O_dict = makeDic_list(binningVikramExp_UPF1O_dict, -0.2, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "X": binningVikramExp_UPF1X_dict = makeDic_list(binningVikramExp_UPF1X_dict, -0.2, miTransf_geneName_AvgExpValue_dict[geneName])
		elif -0.4 >= wContextPPscore > -0.6: 
			binningGen_dict = makeDic_list(binningGen_dict, -0.4, geneName)
			binningFold_dict = makeDic_list(binningFold_dict, -0.4, log2Fold)
			if miTransf_geneName_AvgExpValue_dict.has_key(geneName): 
				binningVikramExp_dict = makeDic_list(binningVikramExp_dict, -0.4, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "O": binningVikramExp_UPF1O_dict = makeDic_list(binningVikramExp_UPF1O_dict, -0.4, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "X": binningVikramExp_UPF1X_dict = makeDic_list(binningVikramExp_UPF1X_dict, -0.4, miTransf_geneName_AvgExpValue_dict[geneName])
		elif -0.6 >= wContextPPscore: 
			binningGen_dict = makeDic_list(binningGen_dict, -0.6, geneName)
			binningFold_dict = makeDic_list(binningFold_dict, -0.6, log2Fold)
			if miTransf_geneName_AvgExpValue_dict.has_key(geneName): 
				binningVikramExp_dict = makeDic_list(binningVikramExp_dict, -0.6, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "O": binningVikramExp_UPF1O_dict = makeDic_list(binningVikramExp_UPF1O_dict, -0.6, miTransf_geneName_AvgExpValue_dict[geneName])
				if UPF1target == "X": binningVikramExp_UPF1X_dict = makeDic_list(binningVikramExp_UPF1X_dict, -0.6, miTransf_geneName_AvgExpValue_dict[geneName])
	return binningGen_dict, binningFold_dict, binningVikramExp_dict, binningVikramExp_UPF1O_dict, binningVikramExp_UPF1X_dict

def getGroup_contextFoldChange(geneName_allInfo_dict, signi_binningGen_dict):
	bin_UPF1target_FoldChange_dict = dict()
	bin_AGO2_UPF1_sites_FoldChange_dict = dict()
	bin_AGO2_sites_FoldChange_dict = dict()
	for binScore in signi_binningGen_dict.keys():
		for geneName in signi_binningGen_dict[binScore]:
			log2Fold = geneName_allInfo_dict[geneName][0]
			UPF1target = geneName_allInfo_dict[geneName][1]
			if UPF1target == "O":
				bin_UPF1target_FoldChange_dict = makeDic_list(bin_UPF1target_FoldChange_dict, binScore, log2Fold)
			if geneName_allInfo_dict[geneName][2] == "AGO2-UPF1-sites":
				bin_AGO2_UPF1_sites_FoldChange_dict = makeDic_list(bin_AGO2_UPF1_sites_FoldChange_dict, binScore, log2Fold)
			if geneName_allInfo_dict[geneName][2] == "AGO2-sites":
				bin_AGO2_sites_FoldChange_dict = makeDic_list(bin_AGO2_sites_FoldChange_dict, binScore, log2Fold)
	return bin_UPF1target_FoldChange_dict, bin_AGO2_UPF1_sites_FoldChange_dict, bin_AGO2_sites_FoldChange_dict

def writeFile(geneName_allInfo_dict, outputDir_topX, all_binningGen_dict, all_binningFold_dict, signi_binningGen_dict, signi_binningFold_dict, inSigni_binningGen_dict, inSigni_binningFold_dict, filteredContext_line_list,vikram_outputDir_topX, all_binningVikramExp_dict, all_binningVikramExp_UPF1O_dict, all_binningVikramExp_UPF1X_dict):
	filter_context_table = open(outputDir_topX + "/" + "filteredContextScore_table.txt", 'w')
	filter_context_table.write("\n".join(filteredContext_line_list))
	filter_context_table.close()
	all_table = open(outputDir_topX + "/" + "allGenes_wContextPP_table.txt", 'w')
	all_table.write("geneName" + "\t" +"log2Fold" + "\t" +"UPF1target" + "\t" +"group"  + "\t" +"sum_wContextPPscore" + "\t" +"sum_wContextPPscore_signi"+ "\t" +"sum_wContextPPscore_inSigni" + "\t" +"wContextPPscore(hsa-miR-24-3p)" + "\t" +"\n")
	for geneName in geneName_allInfo_dict.keys():
		all_table.write(geneName + "\t" + "\t".join(map(str, geneName_allInfo_dict[geneName])) + "\n")
	all_table.close()
	all_binnedContext_table = open(outputDir_topX + "/" + "allGenes_signi_insigni_wContextPP_foldChange.txt", 'w')
	all_binnedContext_table.write("group" + "\t"+ "bin" + "\t" + "count" + "\t" + "Mean" + "\t" + "median" + "\t" + "std" + "\t"+ "ste" + "\t" + "Pvalue" + "\n")
	all_binningFold_pValue_dict = mainModule.getGroupRankSumPvalue(all_binningFold_dict)
	signi_binningFold_pValue_dict =  mainModule.getGroupRankSumPvalue(signi_binningFold_dict)
	inSigni_binningFold_pValue_dict =  mainModule.getGroupRankSumPvalue(inSigni_binningFold_dict)
	for binScore in [0,-0.2,-0.4,-0.6]:
		all_binnedContext_table.write("all" +"\t"+ str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(all_binningFold_dict[binScore]))) + "\t" + "|".join(all_binningFold_pValue_dict[binScore]) + "\n")
		all_binnedContext_table.write("signi" +"\t"+str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(signi_binningFold_dict[binScore]))) + "\t" + "|".join(signi_binningFold_pValue_dict[binScore]) + "\n")
		all_binnedContext_table.write("insigni" +"\t"+str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(inSigni_binningFold_dict[binScore]))) + "\t" + "|".join(inSigni_binningFold_pValue_dict[binScore]) + "\n")
	all_binnedContext_table.close()

	UPF1target_binnedContext_table = open(outputDir_topX + "/" + "UPF1targets_CLIP_wContextPP_foldChange.txt", 'w')
	UPF1target_binnedContext_table.write("group" + "\t"+ "bin" + "\t" + "count" + "\t" + "Mean" + "\t" + "median" + "\t" + "std" + "\t"+ "ste" + "\t" + "Pvalue" + "\n")

	bin_UPF1target_FoldChange_dict, bin_AGO2_UPF1_sites_FoldChange_dict, bin_AGO2_sites_FoldChange_dict = getGroup_contextFoldChange(geneName_allInfo_dict, signi_binningGen_dict)
	UPF1target_pValue_dict = mainModule.getGroupRankSumPvalue(bin_UPF1target_FoldChange_dict)
	AGO2_UPF1_sites_pValue_dict = mainModule.getGroupRankSumPvalue(bin_AGO2_UPF1_sites_FoldChange_dict)
	AGO2_sites_pValue_dict =  mainModule.getGroupRankSumPvalue(bin_AGO2_sites_FoldChange_dict)
	for binScore in [0,-0.2,-0.4,-0.6]:
		UPF1target_binnedContext_table.write("UPF1target" + "\t" + str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(bin_UPF1target_FoldChange_dict[binScore]))) + "\t" + "|".join(UPF1target_pValue_dict[binScore]) + "\n")
		UPF1target_binnedContext_table.write("AGO2-UPF1-sites" + "\t" +str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(bin_AGO2_UPF1_sites_FoldChange_dict[binScore]))) + "\t" + "|".join(AGO2_UPF1_sites_pValue_dict[binScore]) + "\n")
		UPF1target_binnedContext_table.write("AGO2-sites" + "\t"+str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(bin_AGO2_sites_FoldChange_dict[binScore]))) + "\t" + "|".join(AGO2_sites_pValue_dict[binScore]) + "\n")

	vikram_binning_exp_dict = open(vikram_outputDir_topX + "/" + "vikram_allsample_wContextPP_expValue.txt", 'w')
	vikram_binning_exp_dict.write("group" + "\t"+ "bin" + "\t" + "count" + "\t" + "Mean" + "\t" + "median" + "\t" + "std" + "\t"+ "ste" + "\t" + "Pvalue" + "\n")

	all_binningVikramExp_pValue_dict = mainModule.getGroupRankSumPvalue(all_binningVikramExp_dict)
	UPF1O_binningVikramExp_pValue_dict = mainModule.getGroupRankSumPvalue(all_binningVikramExp_UPF1O_dict)
	UPF1X_binningVikramExp_pValue_dict = mainModule.getGroupRankSumPvalue(all_binningVikramExp_UPF1X_dict)
	for binScore in [0,-0.2,-0.4,-0.6]:
		vikram_binning_exp_dict.write("all" +"\t"+ str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(all_binningVikramExp_dict[binScore]))) + "\t" + "|".join(all_binningVikramExp_pValue_dict[binScore]) + "\n")
		vikram_binning_exp_dict.write("UPF1O" +"\t"+ str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(all_binningVikramExp_UPF1O_dict[binScore]))) + "\t" + "|".join(UPF1O_binningVikramExp_pValue_dict[binScore]) + "\n")
		vikram_binning_exp_dict.write("UPF1X" +"\t"+ str(binScore) + "\t" + "\t".join(map(str,mainModule.getMeanSteFromList(all_binningVikramExp_UPF1X_dict[binScore]))) + "\t" + "|".join(UPF1X_binningVikramExp_pValue_dict[binScore]) + "\n")
	vikram_binning_exp_dict.close()

def main(args):
	outputDir_topX = makeOutputDir("/home/jwawon/Project/UPF1/11.contextModel_offTarget/" + args.Experiment +"/"+ args.outputDir,args.miRNAtopX)
	vikram_outputDir_topX = makeOutputDir("/home/jwawon/Project/UPF1/11.contextModel_offTarget/vikram_sRNA/"+ args.outputDir,args.miRNAtopX)
	geneAnno, miRNAfile, signi_miRNAfile, targetGeneName_dict, expressionFile, miRNA_transfect_file = getData(args.miRNAtopX, args.Experiment)
	geneID_fpkmLength = mainModule.get_geneID_fpkm_length(expressionFile)
	miRNAseqDic =  get_miRNAsites_dic(miRNAfile)
	gene_contextObj_dict, filteredContext_line_list = getContextScore(contextFile = "/home/jwawon/Project/UPF1/11.contextModel/TargetScan7_result/Summary_Counts.all_predictions.txt")
	signiMiRNA_dict = get_signiMiRNAlist(signi_miRNAfile)
	geneName_allInfo_dict, geneName_supported, geneName_notSupported = combine_log2Fold_contextScore(geneAnno, geneID_fpkmLength, gene_contextObj_dict, targetGeneName_dict, miRNAseqDic, signiMiRNA_dict)
	miTransf_header_valueObj_dict, miTransf_geneName_AvgExpValue_dict = get_miRNAtransfectInfo(miRNA_transfect_file)
	all_binningGen_dict, all_binningFold_dict, all_binningVikramExp_dict, all_binningVikramExp_UPF1O_dict, all_binningVikramExp_UPF1X_dict = scoreBinning(geneName_allInfo_dict, 3, miTransf_geneName_AvgExpValue_dict)
	signi_binningGen_dict, signi_binningFold_dict, signi_binningVikramExp_dict, signi_binningVikramExp_UPF1O_dict, signi_binningVikramExp_UPF1X_dict = scoreBinning(geneName_allInfo_dict, 4, miTransf_geneName_AvgExpValue_dict)
	inSigni_binningGen_dict, inSigni_binningFold_dict, inSigni_binningVikramExp_dict, inSigni_binningVikramExp_UPF1O_dict, inSigni_binningVikramExp_UPF1X_dict = scoreBinning(geneName_allInfo_dict, 5, miTransf_geneName_AvgExpValue_dict)
	checkVikramData(geneAnno, gene_contextObj_dict, miTransf_geneName_AvgExpValue_dict, vikram_outputDir_topX)
	writeFile(geneName_allInfo_dict, outputDir_topX, all_binningGen_dict, all_binningFold_dict, signi_binningGen_dict, signi_binningFold_dict, inSigni_binningGen_dict, inSigni_binningFold_dict, filteredContext_line_list, vikram_outputDir_topX, all_binningVikramExp_dict, all_binningVikramExp_UPF1O_dict, all_binningVikramExp_UPF1X_dict)


if __name__ == '__main__':
	import os
	import sys
	import argparse
	import AGO2_UPF1_miRNA_7A1_effect_module as mainModule
	import annotationImporter as anno
	import scipy.stats as stats
	import utilityModule as util
	import numpy
	parser = argparse.ArgumentParser(description = "get total weighted context++ score for genes")
	parser.add_argument("-e", "--Experiment", help = "UPF1KD / Wang_UPF1KD / DICER1KD / SMG7KD / TNRC6KD_UPF1KD_to_TNRC6KD / TNRC6KD_UPF1KD_to_UPF1KD")
	parser.add_argument("-o", "--outputDir", help = "output directory")
	parser.add_argument("-mi", "--miRNAtopX", help = "choose miRNA top10 / top30 / top50")
	# parser.add_argument("-c", "--cellLine", help = "mES / HeLa")
	args = parser.parse_args()
	main(args)