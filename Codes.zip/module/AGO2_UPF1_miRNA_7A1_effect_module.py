

import utilityModule as util, UPF1module as Umodule
from scipy import stats
import numpy, math

########## fpkm Data processing ##########
def getLines(file, header = "T"):
	fileOpen = open(file, 'r')
	fileLines = fileOpen.readlines()
	fileOpen.close()
	if header == "T": 
		headerLine = fileLines[0]
		otherLines = fileLines[1:]
	else:
		headerLine = None
		otherLines = fileLines
	return headerLine, otherLines

def getFPKMofCufflinks(file):
	geneName_fpkm = dict()
	fileOpen = open(file, 'r')
	fileLines = fileOpen.readlines()
	fileOpen.close()
	for lines in fileLines:
		if not lines.startswith("tracking_id"):
			line = lines.strip().split("\t")
			geneName = line[0]
			fpkm = float(line[9])
			geneName_fpkm[geneName] = fpkm
	return geneName_fpkm

def getFPKMlog2foldChange(fpkmTable_file, targetName, controlName):
	headerLine, otherLines = getLines(fpkmTable_file)
	targetIndex = headerLine.strip().split("\t").index(targetName)
	controlIndex = headerLine.strip().split("\t").index(controlName)
	geneID_log2Fold_dic = dict()
	for lines in otherLines:
		line = lines.strip().split("\t")
		geneID = line[0]; geneName = line[1]; tpUTRlength = float(line[3])
		targetFPKM = float(line[targetIndex]); controlFPKM = float(line[controlIndex])
		if controlFPKM == 0.0:
			log2Fold = math.log(((targetFPKM+0.1)/(controlFPKM+0.1)), 2)
		else:
			log2Fold = math.log((targetFPKM/controlFPKM), 2)
		geneID_log2Fold_dic[geneID] = [log2Fold, tpUTRlength]
	return geneID_log2Fold_dic

## make geneID list of inputed expressionFile file 
def get_geneID_fpkm_length(fpkmFile):
	geneID_dict = dict()
	fpkmFileOpen = open(fpkmFile, 'r')
	fpkmFileLines = fpkmFileOpen.readlines()
	fpkmFileOpen.close()
	for line in fpkmFileLines:
		lineList = line.strip().split('\t')
		geneID = lineList[0]; length = int(lineList[1]); fpkm = float(lineList[3])
		geneID_dict[geneID] = [fpkm, length]
	return geneID_dict

########## CLIP-seq data processing ##########
## make dict of peak Data using locus Obj
def get_peakObj(peakFile):
	peakFileOpen = open(peakFile, 'r')
	peakFileLines = peakFileOpen.readlines()
	peakFileOpen.close()
	chr_obj_dict = dict()
	for line in peakFileLines:
		if line.startswith("chr"):
			lineList = line.strip().split("\t")
			chr = lineList[0]; start = lineList[1]; end = lineList[2]; sense = lineList[5]
			locusObj = Umodule.Locus(chr, start, end, sense)
			if chr_obj_dict.has_key(chr): chr_obj_dict[chr].append(locusObj)
			else: chr_obj_dict[chr] = [locusObj]
	return chr_obj_dict

#/////////////////////////////////////////////////////////////////
## make hash tables of miRNA list
def get_miRNAsites_dic(miRNAfileOrlist, type, cellLine):
	sevenD = dict()
	seedD = dict()
	offSeedD = dict()
	seqToHitsTo8m = dict()
	seqToHitsTo7m8 = dict()
	seqToHitsTo7A1 = dict()
	seqToHitsToSeed = dict()
	seqToHitsToOffSeed = dict()
	miRNAseqDic = dict()
	if type == "miRNA":
		miRNAfileOpen = open(miRNAfileOrlist, 'r')
		miRNAfileLines = miRNAfileOpen.readlines()
		miRNAfileOpen.close()
		for line in miRNAfileLines:
			lineList = line.strip().split('\t')
			miRNAName = lineList[0].strip(">")
			if cellLine.split("_")[0] == "HeLa": seq = lineList[1]
			if cellLine.split("_")[0] == "mES": seq = lineList[2]
			# seq = lineList[1]
			# print miRNAName, seq
			miRNAseqDic[seq] = miRNAName
	if type =="random":
		i = 0
		for randomSeq in miRNAfileOrlist:
			i+=1
			miRNAName = "random_" + str(i)
			miRNAseqDic[randomSeq] = miRNAName

	for miRNAseq in miRNAseqDic.keys():
		sevenSeq = util.reverseComp(util.UtoT(miRNAseq[1:8]))
		seedSeq = util.reverseComp(util.UtoT(miRNAseq[1:7]))
		offSeedSeq = util.reverseComp(util.UtoT(miRNAseq[2:8]))
		if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = miRNAseqDic[miRNAseq]
		if not (seedD.has_key(seedSeq)): seedD[seedSeq] = miRNAseqDic[miRNAseq]
		if not (offSeedD.has_key(offSeedSeq)): offSeedD[offSeedSeq] = miRNAseqDic[miRNAseq]
		miRlength = len(miRNAseq)
	for seedKey in seedD.keys():
		seedseq = seedKey.upper()
		seqToHitsToSeed[seedseq] = seedD[seedKey]
		seqToHitsTo7A1[seedseq + 'A'] = seedD[seedKey]
	for offSeedKey in offSeedD.keys():
		offSeedseq = offSeedKey.upper()
		seqToHitsToOffSeed[offSeedseq] = offSeedD[offSeedKey]
	for sevenKey in sevenD.keys():
		sevenseq = sevenKey.upper()
		seqToHitsTo8m[sevenseq + 'A'] = sevenD[sevenKey]
		seqToHitsTo7m8[sevenseq] = sevenD[sevenKey]
	return [seqToHitsTo8m, seqToHitsTo7m8, seqToHitsTo7A1, seqToHitsToSeed, seqToHitsToOffSeed], miRNAseqDic

def searchMiRNAsite_wSigni(chr, sense, seq, tpUTRstart, seqToHitsTolist, mre, singiMiRNAseed_dict):
	dict_8mer = dict()
	dict_7m8 = dict()
	dict_7A1 = dict()
	dict_6mer = dict()
	dict_off6mer = dict()
	dict_sites = dict()
	dict_26a = dict()
	dict_24 = dict()
	dict_22 = dict()

	def getLocus(chr, sense, tpUTRstart, siteType, miRNAindex):
		if siteType =="8mer": plusIndex = 7
		if siteType =="7m8" or siteType =="7A1": plusIndex = 6
		if siteType =="6mer": plusIndex = 5
		if sense == "+": miRNAlocus = Umodule.Locus(chr, tpUTRstart + miRNAindex, tpUTRstart + miRNAindex +plusIndex+1, sense)
		else: miRNAlocus = Umodule.Locus(chr, tpUTRstart - miRNAindex - plusIndex-1, tpUTRstart - miRNAindex, sense)
		return miRNAlocus
	skip = "off"
	m = 0
	for n in xrange(len(seq) - 21):
		if m <= len(seq) - 21:
			if skip == "on": m += 8
			elif skip == "off": m += 1
			locSeq8 = seq[m:m+8]
			locSeq7 = seq[m:m+7]
			locSeq6 = seq[m:m+6]
			if seqToHitsTolist[0].has_key(locSeq8):		##8mer
				siteLocus = getLocus(chr, sense, tpUTRstart, "8mer", m)
				dict_8mer[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				if seqToHitsTolist[0][locSeq8] == "hsa-miR-26a-5p": dict_26a[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				if seqToHitsTolist[0][locSeq8] == "hsa-miR-24-3p": dict_24[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				if seqToHitsTolist[0][locSeq8] == "hsa-miR-22-3p": dict_22[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				if mre in ["8mer", "7m8", "7A1", "6mer", "6mer_offset"]:
					if singiMiRNAseed_dict.has_key(locSeq8):
						dict_sites[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[1].has_key(locSeq7):		##7m8
				siteLocus = getLocus(chr, sense, tpUTRstart, "7m8", m)
				dict_7m8[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				if seqToHitsTolist[1][locSeq7] == "hsa-miR-26a-5p": dict_26a[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				if seqToHitsTolist[1][locSeq7] == "hsa-miR-24-3p": dict_24[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				if seqToHitsTolist[1][locSeq7] == "hsa-miR-22-3p": dict_22[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				if mre in ["7m8", "7A1", "6mer", "6mer_offset"]:
					if singiMiRNAseed_dict.has_key(locSeq7):
						dict_sites[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[2].has_key(locSeq7):		##7A1
				siteLocus = getLocus(chr, sense, tpUTRstart, "7A1", m)
				dict_7A1[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				if seqToHitsTolist[2][locSeq7] == "hsa-miR-26a-5p": dict_26a[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				if seqToHitsTolist[2][locSeq7] == "hsa-miR-24-3p": dict_24[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				if seqToHitsTolist[2][locSeq7] == "hsa-miR-22-3p": dict_22[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				if mre in ["7A1", "6mer", "6mer_offset"]:
					if singiMiRNAseed_dict.has_key(locSeq7):
						dict_sites[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[3].has_key(locSeq6):		##6mer
				siteLocus = getLocus(chr, sense, tpUTRstart, "6mer", m)
				dict_6mer[siteLocus] = [seqToHitsTolist[3][locSeq6], locSeq6]
				if mre in ["6mer", "6mer_offset"]:
					dict_sites[siteLocus] = [seqToHitsTolist[3][locSeq6], locSeq6]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[4].has_key(locSeq6):		##offset 6mer
				siteLocus = getLocus(chr, sense, tpUTRstart, "6mer", m)
				dict_off6mer[siteLocus] = [seqToHitsTolist[4][locSeq6], locSeq6]
				if mre == ["6mer_offset"]:
					dict_sites[siteLocus] = [seqToHitsTolist[4][locSeq6], locSeq6]
				else: pass
			else: skip = "off"
		else: break
	return dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites, dict_26a, dict_24, dict_22

#/////////////////////////////////////////////////////////////////
## search miRNA site (8mer, 7m8, 7A1, 6mer)
def searchMiRNAsite(chr, sense, seq, tpUTRstart, seqToHitsTolist, mre):
	dict_8mer = dict()
	dict_7m8 = dict()
	dict_7A1 = dict()
	dict_6mer = dict()
	dict_off6mer = dict()
	dict_sites = dict()

	def getLocus(chr, sense, tpUTRstart, siteType, miRNAindex):
		if siteType =="8mer": plusIndex = 7
		if siteType =="7m8" or "7A1": plusIndex = 6
		if siteType =="6mer": plusIndex = 5
		if sense == "+": miRNAlocus = Umodule.Locus(chr, tpUTRstart + miRNAindex, tpUTRstart + miRNAindex +plusIndex+1, sense)
		else: miRNAlocus = Umodule.Locus(chr, tpUTRstart - miRNAindex - plusIndex-1, tpUTRstart - miRNAindex, sense)
		return miRNAlocus
	skip = "off"
	m = 0
	for n in xrange(len(seq) - 21):
		if m <= len(seq) - 21:
			if skip == "on": m += 8
			elif skip == "off": m += 1
			locSeq8 = seq[m:m+8]
			locSeq7 = seq[m:m+7]
			locSeq6 = seq[m:m+6]
			if seqToHitsTolist[0].has_key(locSeq8):		##8mer
				siteLocus = getLocus(chr, sense, tpUTRstart, "8mer", m)
				dict_8mer[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				if mre in ["8mer", "7m8", "7A1", "6mer", "6mer_offset"]:
				# if mre == "8mer":
					dict_sites[siteLocus] = [seqToHitsTolist[0][locSeq8], locSeq8]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[1].has_key(locSeq7):		##7m8
				siteLocus = getLocus(chr, sense, tpUTRstart, "7m8", m)
				dict_7m8[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				if mre in ["7m8", "7A1", "6mer", "6mer_offset"]:
				# if mre == "7m8":
					dict_sites[siteLocus] = [seqToHitsTolist[1][locSeq7], locSeq7]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[2].has_key(locSeq7):		##7A1
				siteLocus = getLocus(chr, sense, tpUTRstart, "7A1", m)
				dict_7A1[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				if mre in ["7A1", "6mer", "6mer_offset"]:
				# if mre == "7A1":
					dict_sites[siteLocus] = [seqToHitsTolist[2][locSeq7], locSeq7]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[3].has_key(locSeq6):		##6mer
				siteLocus = getLocus(chr, sense, tpUTRstart, "6mer", m)
				dict_6mer[siteLocus] = [seqToHitsTolist[3][locSeq6], locSeq6]
				if mre in ["6mer", "6mer_offset"]:
				# if mre == "6mer":
					dict_sites[siteLocus] = [seqToHitsTolist[3][locSeq6], locSeq6]
				else: pass
				skip = "on"
				continue
			elif seqToHitsTolist[4].has_key(locSeq6):		##offset 6mer
				siteLocus = getLocus(chr, sense, tpUTRstart, "6mer", m)
				dict_off6mer[siteLocus] = [seqToHitsTolist[4][locSeq6], locSeq6]
				if mre in ["6mer_offset"]:
				# if mre == "6mer_offset":
					dict_sites[siteLocus] = [seqToHitsTolist[4][locSeq6], locSeq6]
				else: pass
			else: skip = "off"
		else: break
	return dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites

def getMiRNAGroup(dict_8mer, dict_7m8, dict_7A1, dict_6mer):
	if len(dict_8mer) > 0: miRNA_group = "8mer"
	elif len(dict_8mer)==0 and len(dict_7m8) > 0: miRNA_group = "7m8"
	elif len(dict_8mer)==0 and len(dict_7m8)==0 and len(dict_7A1) > 0: miRNA_group = "7A1"
	elif len(dict_8mer)==0 and len(dict_7m8)==0 and len(dict_7A1)==0 and len(dict_6mer) > 0: miRNA_group = "6mer"
	elif len(dict_8mer)==0 and len(dict_7m8)==0 and len(dict_7A1)==0 and len(dict_6mer) == 0: miRNA_group = "noSites"
	return miRNA_group

def getPeakCenter(peak):
	if peak.sense() == "+":
		peakCenter = float(peak.start()) + (peak.len() / float(2))
	else:
		peakCenter = float(peak.end()) - (peak.len() / float(2))
	return peakCenter

def getRelativePeakDis(tpUtrObj, peak):
	peakCenter = getPeakCenter(peak)
	if peak.sense() == "+":
		relativePeak = (peakCenter - tpUtrObj.start()) / float(tpUtrObj.len())
	else:
		relativePeak = (tpUtrObj.end() - peakCenter) / float(tpUtrObj.len())
	return relativePeak

#/////////////////////////////////////////////////////////////////
## find peak and sites on 3'UTR
def findPeakSites(tpUtrObj, tpExonsList, peakList, miRNALocusDic):
	peak_sitesNosites = dict()
	relPeakCenterDict = dict()
	for tpExon in tpExonsList:
		for peak in peakList:
			if tpExon.overlaps(peak):
				peak_sitesNosites[peak] =[]
				relPeakCenterDict[peak] = getRelativePeakDis(tpUtrObj, peak)
				for miRNALocus in miRNALocusDic.keys():
					if peak.contains(miRNALocus):
						peak_sitesNosites[peak].append({miRNALocus:miRNALocusDic[miRNALocus]})
	return peak_sitesNosites, relPeakCenterDict

#/////////////////////////////////////////////////////////////////
## find overlap peak and relative distance
def findOverlapPeakSites(tpUtrObj, ago2Peak_dic, upf1Peak_dic):
	overlapPeaksites_dic = dict()
	overlapAgo2Peak_dic = dict()
	overlapUpf1Peak_dic = dict()
	relativeDis_dic = dict()
	overlapRelativePos = dict()
	for upf1Peak in upf1Peak_dic.keys():
		for ago2Peak in ago2Peak_dic.keys():
			if upf1Peak.overlaps(ago2Peak):
				if upf1Peak.sense() == "+": relativeDis = getPeakCenter(ago2Peak) - getPeakCenter(upf1Peak)
				else: relativeDis = getPeakCenter(upf1Peak) - getPeakCenter(ago2Peak)
				relativeDis_dic[upf1Peak] = relativeDis
				overlapRelativePos[upf1Peak] = getRelativePeakDis(tpUtrObj, ago2Peak)
				overlapAgo2Peak_dic[ago2Peak] = 0
				overlapUpf1Peak_dic[upf1Peak] = 0
				if overlapPeaksites_dic.has_key(upf1Peak): overlapPeaksites_dic[upf1Peak].append({ago2Peak:ago2Peak_dic[ago2Peak]})
				else : overlapPeaksites_dic[upf1Peak] = [{ago2Peak:ago2Peak_dic[ago2Peak]}]
	return overlapPeaksites_dic, overlapAgo2Peak_dic, overlapUpf1Peak_dic, relativeDis_dic, overlapRelativePos

### make group 1) noAGO2-noUPF1-noSites, 2) AGO2-noSites, 3) AGO2-sites, 4) AGO2-UPF1-noSites, 5) AGO2-UPF1-sites
def defineGroup(dict_sites, dict_6mer, AGO2_sites_key, AGO2_noSites_key, UPF1_sites_key, UPF1_noSites_key, AGO2_UPF1_noSites_key, overlapAgo2Peak_dic, overlapUpf1Peak_dic, total_overlap_sitesN):
	if len(dict_6mer.keys()) == 0 and len(dict_sites.keys()) == 0 and len(AGO2_noSites_key) ==0 and len(UPF1_noSites_key) == 0:
		group = "noAGO2-noUPF1-noSites"
	elif len(dict_6mer.keys()) == 0 and len(dict_sites.keys()) == 0 and len(UPF1_noSites_key) == 0 and len(AGO2_noSites_key) > 0:
		group = "AGO2-noSites"
	elif len(AGO2_sites_key) > 0 and len(AGO2_sites_key) == len(dict_sites.keys()) and len(UPF1_sites_key) == 0 and len(UPF1_noSites_key) == 0:
		group = "AGO2-sites"
	elif len(dict_6mer.keys()) == 0 and len(dict_sites.keys()) == 0 and len(AGO2_UPF1_noSites_key) >0 and len(overlapAgo2Peak_dic.keys()) == len(AGO2_noSites_key) and len(overlapUpf1Peak_dic.keys()) == len(UPF1_noSites_key):
		group = "AGO2-UPF1-noSites"
	elif total_overlap_sitesN >0 and total_overlap_sitesN == len(dict_sites.keys()) and len(AGO2_noSites_key) ==0 and (len(UPF1_noSites_key) + len(UPF1_sites_key) == len(overlapUpf1Peak_dic.keys())) and len(overlapAgo2Peak_dic.keys()) == len(AGO2_sites_key):
		group = "AGO2-UPF1-sites"
	elif len(dict_6mer.keys()) == 0 and len(dict_sites.keys()) == 0 and len(AGO2_sites_key) == 0 and len(AGO2_noSites_key) == 0 and len(UPF1_noSites_key) >0:
		group = "UPF1-noSites"
	elif len(dict_6mer.keys()) == 0 and len(dict_sites.keys()) >0 and len(UPF1_sites_key) == len(dict_sites.keys()) and len(AGO2_sites_key) == 0 and len(AGO2_noSites_key) == 0:
		group = "UPF1-sites"
	else: group = "undefined"
	return group

### make mild group 1) noAGO2-noUPF1-noSites, 2) AGO2-noSites, 3) AGO2-sites, 4) AGO2-UPF1-noSites, 5) AGO2-UPF1-sites
def defineMildGroup(sitesCount, seedCount, ago2SitesCount, ago2noSitesCount, upf1SitesCount, upf1noSitesCount, ago2upf1SitesCount, ago2upf1noSitesCount, upf1SitesAgo2Count):
	if (sitesCount + seedCount + ago2SitesCount + ago2noSitesCount + upf1SitesCount + upf1noSitesCount) == 0:
		group = "noAGO2-noUPF1-noSites"
	elif (sitesCount + seedCount == 0) and ago2noSitesCount > 0 and ago2upf1noSitesCount == 0:
		group = "AGO2-noSites"
	elif (sitesCount + seedCount == 0) and upf1noSitesCount > 0 and ago2upf1noSitesCount == 0:
		group = "UPF1-noSites"
	elif ago2SitesCount > 0 and ago2upf1SitesCount ==0:
		group = "AGO2-sites"
	elif upf1SitesCount > 0 and ago2SitesCount == 0 and ago2upf1SitesCount ==0:
		group = "UPF1-sites"
	elif ago2upf1noSitesCount > 0 and (sitesCount + seedCount == 0):
		group = "AGO2-UPF1-noSites"
	elif ago2upf1SitesCount > 0:
		group = "AGO2-UPF1-sites"
	else: group = "undefined"
	return group

def getGroupRankSumPvalue(fpkm_dict):
	pValue_dict = dict()
	for index in range(0, len(fpkm_dict.keys())):
		pValue_dict[fpkm_dict.keys()[index]] = []
		x=1
		# print fpkm_dict.keys()
		while (index + x) < len(fpkm_dict.keys()):
			pValue = str(stats.ranksums(fpkm_dict[fpkm_dict.keys()[index]],fpkm_dict[fpkm_dict.keys()[index+x]])[1])
			value = str(fpkm_dict.keys()[index])+ "_vs_" + str(fpkm_dict.keys()[index+x]) +":"+pValue
			pValue_dict[fpkm_dict.keys()[index]].append(value)
			x +=1 
	return pValue_dict

def getGroupRankSumPvalueForExclude(fpkm_dict):
	pValue_dict = dict()
	for index in range(0, len(fpkm_dict.keys())):
		pValue_dict[fpkm_dict.keys()[index]] = []
		x=1
		# print fpkm_dict.keys()
		while (index + x) < len(fpkm_dict.keys()):
			pValue = str(stats.ranksums(fpkm_dict[fpkm_dict.keys()[index]]["All"],fpkm_dict[fpkm_dict.keys()[index+x]]["All"])[1])
			value = str(fpkm_dict.keys()[index])+ "_vs_" + str(fpkm_dict.keys()[index+x]) +":"+pValue
			pValue_dict[fpkm_dict.keys()[index]].append(value)
			x +=1 
	return pValue_dict

def getMeanSteFromList(fpkm_list):
	count = len(fpkm_list)
	if count == 0: meanFpkm = 0; medianFpkm = 0; stdFpkm = 0; steFpkm=0
	else:
		meanFpkm = numpy.mean(fpkm_list)
		medianFpkm = numpy.median(fpkm_list)
		stdFpkm = numpy.std(fpkm_list)
		steFpkm = float(stdFpkm) / float(math.sqrt(count))
	return count, meanFpkm, medianFpkm, stdFpkm, steFpkm

def getRandomSitesFPKM(gene_dict,geneID_tpUTRseq, geneID_fpkmLength,random_miRNA_rep100_list, type, mre):
	if type == "all": fpkm_dic = {"50nt": [], "350nt": [], "500nt": [], "800nt": []}
	elif type == "count": fpkm_dic = {"0": [], "1": [], "2":[], ">=3":[]}
	genelist = filter(lambda x: geneID_fpkmLength.has_key(x[1].geneID()), gene_dict.keys())
	i=0
	for random_miRNA in random_miRNA_rep100_list:
		i+=1
		print "random miRNA:",i
		fpkm_count = {"0": [], "1": [], "2":[], ">=3":[]}
		for gene in genelist:
			geneName = gene[1].name()
			geneID = gene[1].geneID()
			fpkm = float(geneID_fpkmLength[geneID][0])
			tpUTRlength = int(geneID_fpkmLength[geneID][1])
			chr = gene[1].chr()
			sense = gene[1].sense()
			tpUTR = gene[1].tpUtr()
			tpExons = gene[1].tpExons(sense)
			tpUTRseq = geneID_tpUTRseq[geneID]
			if sense == "+": tpUTRstart = tpUTR.start()
			else: tpUTRstart = tpUTR.end()
			dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites = searchMiRNAsite(chr, sense, tpUTRseq, tpUTRstart, random_miRNA, mre)
			if type == "all":
				miRNAGroup = getMiRNAGroup(dict_8mer, dict_7m8, dict_7A1, dict_6mer)
				if not fpkm_dic.has_key(miRNAGroup): fpkm_dic[miRNAGroup] = []; fpkm_dic[miRNAGroup].append(fpkm)
				else: fpkm_dic[miRNAGroup].append(fpkm)
				if len(dict_sites.keys()) > 0:
					tag = "All_"+str(i)
					fpkm_dic[tag] = []
					fpkm_dic[tag].append(fpkm)
					if 50 <= tpUTRlength < 350: fpkm_dic["50nt"].append(fpkm)
					elif 350 <= tpUTRlength < 500: fpkm_dic["350nt"].append(fpkm)
					elif 500 <= tpUTRlength < 800: fpkm_dic["500nt"].append(fpkm)
					elif 800 <= tpUTRlength < 20000: fpkm_dic["800nt"].append(fpkm)
			elif type == "count":
				if len(dict_sites.keys()) >=3:
					fpkm_count[">=3"].append(fpkm)
				else: fpkm_count[str(len(dict_sites.keys()))].append(fpkm)
		if type == "count":
			for count in fpkm_count.keys():
				fpkm_dic[count].append(numpy.mean(fpkm_count[count]))
	return fpkm_dic

def getRandomInAGO2FPKM(gene_dict,geneID_AGO2seq, geneID_fpkmLength,random_miRNA_rep100_list, type, mre):
	if type == "all": fpkm_dic = {"All": [], "50nt": [], "350nt": [], "500nt": [], "800nt": []}
	elif type == "count": fpkm_dic = {0: [], 1: [], 2:[]}
	geneID_ago2RandomSites = dict()
	for random_miRNA in random_miRNA_rep100_list:
		for gene in gene_dict.keys():
			geneName = gene[1].name()
			geneID = gene[1].geneID()
			geneID_ago2RandomSites[geneID] = []
			fpkm = float(geneID_fpkmLength[geneID][0])
			tpUTRlength = int(geneID_fpkmLength[geneID][1])
			chr = gene[1].chr()
			sense = gene[1].sense()
			tpUTR = gene[1].tpUtr()
			tpExons = gene[1].tpExons(sense)
			if sense == "+": tpUTRstart = tpUTR.start()
			else: tpUTRstart = tpUTR.end()
			for ago2Seq in geneID_AGO2seq[geneID]:
				dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites = searchMiRNAsite(chr, sense, ago2Seq, tpUTRstart, random_miRNA, mre)
				geneID_ago2RandomSites[geneID].append(len(dict_sites.keys()))
			total_random = sum(geneID_ago2RandomSites[geneID])
			if type =="all":
				if len(dict_sites.keys()) > 0:
					fpkm_dic["All"].append(fpkm)
					if 50 <= tpUTRlength < 350: fpkm_dic["50nt"].append(fpkm)
					elif 350 <= tpUTRlength < 500: fpkm_dic["350nt"].append(fpkm)
					elif 500 <= tpUTRlength < 800: fpkm_dic["500nt"].append(fpkm)
					elif 800 <= tpUTRlength < 20000: fpkm_dic["800nt"].append(fpkm)
			elif type == "count":
				if total_random >=2:
					fpkm_dic[2].append(fpkm)
				else: fpkm_dic[total_random].append(fpkm)
	return fpkm_dic


def divideBytpUTRlength(geneID_list, geneID_fpkmLength):
	length_fpkm = {"All":[], "50nt": [], "350nt": [], "500nt": [], "800nt": []}
	tpUTRlengthList = []
	for geneID_fpkm in geneID_list:
		geneID = geneID_fpkm[0]
		fpkm = geneID_fpkmLength[geneID][0]
		tpUTRlength = geneID_fpkmLength[geneID][1]
		tpUTRlengthList.append(tpUTRlength)
		length_fpkm["All"].append(fpkm)
		if 50 <= tpUTRlength < 350: length_fpkm["50nt"].append(fpkm)
		elif 350 <= tpUTRlength < 500: length_fpkm["350nt"].append(fpkm)
		elif 500 <= tpUTRlength < 800: length_fpkm["500nt"].append(fpkm)
		elif 800 <= tpUTRlength < 20000: length_fpkm["800nt"].append(fpkm)
	return length_fpkm, tpUTRlengthList


def writeListLine(writeFile, header, val_list):
	for val in val_list:
		writeFile.write(header + "\t" + str(val) + "\n")


def RNAfold(seq):
	commandBase = 'RNAfold '
	p = Popen(commandBase, shell=True, stdout=PIPE, stdin=PIPE, stderr=PIPE)
	output = p.communicate(input=seq)
	freeE = output[0].strip().split(" (")[1].strip(")")
	return freeE














