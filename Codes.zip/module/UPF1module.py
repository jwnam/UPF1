


import sys, os, math
import string, os
from subprocess import Popen, PIPE, STDOUT
# locus

class Locus:
    # this may save some space by reducing the number of chromosome strings
    # that are associated with Locus instances (see __init__).
    __chrDict = dict()
    __senseDict = {'+':'+', '-':'-', '.':'.'}
    # chr = chromosome name (string)
    # sense = '+' or '-' (or '.' for an ambidexterous locus)
    # start,end = ints of the start and end coords of the locus;
    #      end coord is the coord of the last nucleotide.
    def __init__(self,chr,start,end,sense):
        coords = [start,end]
        coords.sort()
        # this method for assigning chromosome should help avoid storage of
        # redundant strings.
        if not(self.__chrDict.has_key(chr)): self.__chrDict[chr] = chr
        self._chr = self.__chrDict[chr]
        self._sense = self.__senseDict[sense]
        self._start = min(map(int, coords))
        self._end = max(map(int, coords))
    def chr(self): return self._chr
    def start(self): return self._start  ## returns the smallest coordinate
    def end(self): return self._end   ## returns the biggest coordinate
    def len(self): return self._end - self._start + 1
    def center(self):
        if self._chr == "+": return self._start + (self.len()/2)
        else: return self._end - (self.len()/2)
    def getAntisenseLocus(self):
        if self._sense=='.': return self
        else:
            switch = {'+':'-', '-':'+'}
            return Locus(self._chr,self._start,self._end,switch[self._sense])
    def coords(self): return [self._start,self._end]  ## returns a sorted list of the coordinates
    def sense(self): return self._sense
    # returns boolean; True if two loci share any coordinates in common
    def overlaps(self,otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif not(self._sense=='.' or \
                 otherLocus.sense()=='.' or \
                 self.sense()==otherLocus.sense()): return False
        elif self.start() > otherLocus.end() or otherLocus.start() > self.end(): return False
        else: return True

    def overlaps_bothDir(self,otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif self.start() > otherLocus.end() or otherLocus.start() > self.end(): return False
        else: return True
    def exactMatch(self, otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif not(self._sense=='.' or otherLocus.sense()=='.' or self.sense()==otherLocus.sense()): return False
        elif self.start() != otherLocus.start(): return False
        else: return True
    # returns boolean; True if all the nucleotides of the given locus overlap
    #      with the self locus
    def contains(self,otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif not(self._sense=='.' or \
                 otherLocus.sense()=='.' or \
                 self.sense()==otherLocus.sense()): return False
        elif self.start() > otherLocus.start() or otherLocus.end() > self.end(): return False
        else: return True

    # same as overlaps, but considers the opposite strand
    def overlapsAntisense(self,otherLocus):
        return self.getAntisenseLocus().overlaps(otherLocus)
    # same as contains, but considers the opposite strand
    def containsAntisense(self,otherLocus):
        return self.getAntisenseLocus().contains(otherLocus)
    def __hash__(self): return self._start + self._end
    def __eq__(self,other):
#        if self.__class__ != other.__class__: return False
        if self.chr()!=other.chr(): return False
        if self.start()!=other.start(): return False
        if self.end()!=other.end(): return False
        if self.sense()!=other.sense(): return False
        return True
    def __ne__(self,other): return not(self.__eq__(other))
    def coord(self): return self.chr()+':'+'-'.join(map(str,self.coords()))
    def __str__(self): return self.chr()+'('+self.sense()+'):'+'-'.join(map(str,self.coords()))
    def checkRep(self):
        pass







################################## Function ######################################


def getSequence(locus,f):
    if f[-1]=='/': f = f[:-1]
    chr = locus.chr()
    start = locus.start()
    finish = locus.end()
    side = locus.sense()
#    print 'nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(side)
    a = os.popen('nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(side)+' stdout','r')
    b = a.read().split('\n')
    a.close()
    return ''.join(b[1:]).upper()


def get_reviseSequence(locus, revisedStart, revisedEnd ,f):
    if f[-1]=='/': f = f[:-1]
    chr = locus.chr()
    start = revisedStart
    finish = revisedEnd
    side = locus.sense()
#    print 'nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(side)
    a = os.popen('nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(side)+' stdout','r')
    b = a.read().split('\n')
    a.close()
    return ''.join(b[1:]).upper()


def getListSequence(list,f):
    locusList = []
    if f[-1]=='/': f = f[:-1]
#   print list
    for locus in list:    
        chr = locus.chr()
        start = locus.start() # Loci of List is difference start, end position with nomal locus
        finish = locus.end()
        sense = locus.sense()
        if start == finish: continue
        command = 'nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(sense)+' stdout'
        #print command
        a = os.popen(command,'r')
        #print a
        b = a.read().split('\n')
        a.close()
        locusSeq = ''.join(b[1:]).upper()
        locusList.append(locusSeq)
    if list[0].sense() == '-': 
        locusList.reverse()
    listSeq = ''.join(locusList)
    return listSeq

def getListSequence2(list,f, sense):
	locusList = []
	if f[-1]=='/': f = f[:-1]
#	print list
	for locus in list:    
		chr = locus.chr()
		start = locus.start() # Loci of List is difference start, end position with nomal locus
		finish = locus.end()
		sense = locus.sense()
		if start == finish: continue
		command = 'nibFrag '+f+'/'+chr+'.nib '+str(start)+' '+str(finish)+' '+str(sense)+' stdout'
		#print command
		a = os.popen(command, 'r')
                #print a
		b = a.read().split('\n')
		a.close()
		locusSeq = ''.join(b[1:]).upper()
		locusList.append(locusSeq)
	if sense == '-': 
		locusList.reverse()
	listSeq = ''.join(locusList)
	return listSeq
	

def potentialIntron(seq):
	fpIntron = seq.find('GT')
	tpIntron = seq.find('AG')
	if fpIntron < tpIntron:
		intronLength = int(tpIntron) - int(fpIntron) + 1
		return intronLength	






def find_sites(geneID, seq, miRNAid, seed, seven):
        seq.upper()
        seqLen = len(seq)

        #find all seed sites in the seq(motif match)
        miter = stf.findAllIterUsingRE(seed,seq)

        for match in miter:
                span = match.span() #start, end information
#               print span
                if span[0]>=15: #ribosome shadowing
                        psite = seq[span[0]-1:span[1]+1]
                        #classifying target sites
                        if psite[-1]=='A' and psite[:-1]==seven: return geneID, miRNAid, '8mer', [span[0]-1, span[1]+1], psite
                        elif psite[-1]=='A': return geneID, miRNAid,'7A1', [span[0], span[1]+1], psite[1:]
                        elif psite[:-1]==seven: return geneID, miRNAid,'7m8',[span[0]-1, span[1]], psite[:-1]
                        else: return geneID , miRNAid , '6mer', span, psite[1:-1]




def fpkm(filetype, geneName, fpkm_D):
        def dictionary(Xlines):
                fpkm_dict = dict()
                for lines in Xlines:
                        xline = lines.strip().split('\t')
                        xName = xline[0]
                        xFPKM = xline[1]
                        fpkm_dict[xName] = xFPKM
                return fpkm_dict

        if filetype == "mm9":
                GFPfpkmFile = '/home/jwawon/upf1/9.AGO_clipseq/fpkm/mm9_GFP_1_fpkm_over1.txt'
                GFPfpkm = open(GFPfpkmFile, 'r')

                UPF1fpkmFile = '/home/jwawon/upf1/9.AGO_clipseq/fpkm/mm9_UPF1_1_fpkm_over1.txt'
                UPF1fpkm = open(UPF1fpkmFile, 'r')
        elif filetype =="hg19":
                GFPfpkmFile = '/home/jwawon/upf1/9.AGO_clipseq/fpkm/hg19_control_1_fpkm_over1.txt'
                GFPfpkm = open(GFPfpkmFile, 'r')

                UPF1fpkmFile = '/home/jwawon/upf1/9.AGO_clipseq/fpkm/hg19_UPF1_1_fpkm_over1.txt'
                UPF1fpkm = open(UPF1fpkmFile, 'r')

        GFPLines = GFPfpkm.readlines()
        GFPfpkm.close()

        UPF1Lines = UPF1fpkm.readlines()
        UPF1fpkm.close()

        GFP_dict = dictionary(GFPLines)
        UPF1_dict = dictionary(UPF1Lines)


        if GFP_dict.has_key(geneName):
                if UPF1_dict.has_key(geneName):
                        ufpkm = float(UPF1_dict[geneName])
                        gfpkm = float(GFP_dict[geneName])
                        fpkm_round = ufpkm / gfpkm
                        fpkm = math.log(fpkm_round, 2)
                        fpkm_D[geneName] = fpkm
                else: fpkm_D[geneName] = 'None'
        else: fpkm_D[geneName] = 'None'
        return fpkm_D


def fpm(filetype, geneID, fpm_D):
        def dictionary(Xlines):
                fpm_dict = dict()
                for lines in Xlines:
                        xline = lines.strip().split('\t')
                        xID = xline[0]
                        xFPM = xline[1]
                        fpm_dict[xID] = xFPM
                return fpm_dict

	if filetype == "mm9":
	        GFPfpmFile = '/home/jwawon/upf1/6.cufflinks/mm9/merge_cufflinks/GFP/GFP_fpm_over3.txt'
	        GFPfpm = open(GFPfpmFile, 'r')

        	UPF1fpmFile = '/home/jwawon/upf1/6.cufflinks/mm9/merge_cufflinks/UPF1/UPF1_fpm_over3.txt'
	        UPF1fpm = open(UPF1fpmFile, 'r')
	elif filetype =="hg19":
                GFPfpmFile = '/home/jwawon/upf1/6.cufflinks/hg19/merge_cufflinks/control/HeLa_control_FPM.txt'
                GFPfpm = open(GFPfpmFile, 'r')

                UPF1fpmFile = '/home/jwawon/upf1/6.cufflinks/hg19/merge_cufflinks/UPF1/HeLa_UPF1_FPM.txt'
                UPF1fpm = open(UPF1fpmFile, 'r')		

        GFPLines = GFPfpm.readlines()
	GFPfpm.close()

        UPF1Lines = UPF1fpm.readlines()
        UPF1fpm.close()

	GFP_dict = dictionary(GFPLines)
        UPF1_dict = dictionary(UPF1Lines)


        if GFP_dict.has_key(geneID):
                if UPF1_dict.has_key(geneID):
                        ufpm = float(UPF1_dict[geneID])
                        gfpm = float(GFP_dict[geneID])
			fpm_round = ufpm / gfpm
			fpm = math.log(fpm_round, 2)
			fpm_D[geneID] = fpm
                else: fpm_D[geneID] = 'None'
        else: fpm_D[geneID] = 'None'
        return fpm_D


def elapseTime(startT, endT):
        elapseT = endT - startT
        if elapseT >= 3600:
                elapse = elapseT / 60
                elapseH = "%02d" % (elapse / 60)
                elapseM = "%02d" % (elapse % 60)
                elapseS = "%02d" % (elapseT % 60)
                elapsetime = elapseH + ":" + elapseM + ":" + elapseS
        elif elapseT < 3600:
                elapseM = "%02d" % (elapseT / 60)
                elapseS = "%02d" % (elapseT % 60)
                elapsetime = "00:" + elapseM + ":" + elapseS
        return elapsetime

def NMD(seq):
	seqLen = len(seq)
	for n in xrange(0, len(seq), 3):
		locStop = seq[n:n+3]
		if locStop == 'TAG' or locStop == 'TAA' or locStop == 'TGA':
			if seqLen - n > 50: 
				return "NMDtarget"
				break
			else: return "nonNMD"
		else: return "nonNMD"

