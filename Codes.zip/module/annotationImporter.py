


import utilityModule, os

def getRefFlat2(genomeName,test = lambda g: True):
    genomeToFile=dict()
    genomeToFile['mm9'] = '/home/jwawon/Project/UPF1/Data_set/Annotation/mm9/refFlat_mm9_20140215.genePred'
    genomeToFile['hg19'] = '/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/refFlat.txt'
    genomeToFile['dm3'] = '/home/jwnam/WI/bartel3_ata/jwnam/d.melanogaster/annotation/refFlat.txt'
    filename = genomeToFile[genomeName]
    geneList = dict()
    f = open(filename)
    for line in f.readlines():
        raw_line = line.split('\t')
        if len(raw_line)==10: raw_line.insert(1, raw_line[0])
        name = raw_line[0]
        geneID = raw_line[1]
        chr = raw_line[2]
        sense = raw_line[3]
        txCoords = map(int,raw_line[4:6])
        cdCoords = map(int,raw_line[6:8])
        exStarts = map(int,raw_line[9].split(',')[:-1])
        exEnds = map(int,raw_line[10].split(',')[:-1])
        # fix the edges to work with the Gene specs
        #exEnds = map(lambda n: n-1, exEnds)
        txCoords = [txCoords[0], txCoords[1] ]

        cdCoords = [cdCoords[0], max([cdCoords[1] ,0])]
        if cdCoords[0]!=0 or cdCoords[1]!=0:
            newGene = utilityModule.Gene(name, geneID,chr,sense,txCoords,cdCoords,exStarts,exEnds)
            if not(geneList.has_key(geneID)): geneList[geneID] = newGene
    f.close()
    return geneList



def cmp1(a1, a2): return cmp(a1[1], a2[1])
def cmp0(a1, a2): return cmp(a1[0], a2[0])
def get_new3UTR(assembly, method, tpSeqSample):
    newUTR=dict()
    new3UTRD=dict()
    #newUTR['hg19'] = '/home/jwnam/jwnam/Project/Human/DifferentialTargets/Apps/3PSeq/3PSeq_Signals_Across_Samples_15_L3UTR_All.txt'
    #newUTR['mm9'] = '/home/jwnam/jwnam/Project/Mouse/DifferentialTargets/Apps/3PSeq/3PSeq_Signals_Across_Samples_15_L3UTR_Calvin_All.txt'
    #newUTR['dm3'] = '/home/jwnam/jwnam/Project/Fly/DifferentialTargets/Apps/3PSeq/3PSeq_Signals_Across_Samples_15_L3UTR_All.txt'
    newUTR['hg19'] = '/home/jwawon/Project/UPF1/Data_set/3P-seq/Human/3PSeq_Signals_Across_Samples_15_L3UTR_All.txt'
    newUTR['mm9'] = '/home/jwawon/Project/UPF1/Data_set/3P-seq/Mouse/3PSeq_Signals_Across_Samples_15_L3UTR_Calvin_All_new.txt'
    #newUTR['mm9'] = '/home/jwawon/Project/UPF1/Data_set/3P-seq/Mouse/3PSeq_Signals_Across_Samples_15_L3UTR_Calvin_All.txt'
    newUTR['dm3'] = '/home/jwawon/Project/UPF1/Data_set/3P-seq/Fly/3PSeq_Signals_Across_Samples_15_L3UTR_All.txt'
    
    if newUTR.has_key(assembly):
    	file = open(newUTR[assembly])
    	lines = file.readlines(); file.close()
    	if assembly=='ce6':
    		for line in lines[1:]:
			tmp = line.split('\t')
			geneID = tmp[0]
			new3UTR = int(tmp[1])
			new3UTRD[geneID]=new3UTR
    	elif assembly=='hg19' or assembly=='dm3' or assembly=='mm9' or assembly=='danRer7':
	#NM_001143985    chr11   +       65771620:17,    65771620:26,    65771624:29,    65771624:23,
		title = lines[0].split('\n')[0].split('\t')[3:]
		titleD =dict(); col=3
		for t in title: titleD[t]=col; col+=1
		colNum = titleD[tpSeqSample]
#		print colNum
		for line in lines[1:]:
			tend=-1; tend1=-1; tend2=-1
			line = line.split('\t')
			mp=[]; lp=[]
			poss = line[colNum]
			if poss.find(':')>=0:
			    p = poss.split(',')
			    p = filter(lambda x: len(x)>0, p)
			    p = map(lambda x: map(float, x.split(':')), p)
			    majorEnd = p[0][0]
			    p.sort(cmp0)
			    if method=='longest':
				if line[2]=='+': tend = p[-1][0]
				else: tend = p[0][0]
			    elif method=='major':
				if line[2]=='+': tend1 = p[-1][0]
				else: tend1 = p[0][0]
				if line[2]=='+': tend = majorEnd 
				else: tend =  majorEnd
				#print line[2], tend1, tend
			if tend>0: new3UTRD[line[0]]=tend
#    print new3UTRD
    return new3UTRD
    


def getNewRefFlat(genomeName, method, tpSeqSample, test = lambda g: True):
    newRefFlat = get_new3UTR(genomeName, method, tpSeqSample)
    genomeToFile=dict()
    genomeToFile['mm9'] = '/home/jwawon/Project/UPF1/Data_set/Annotation/mm9/refFlat_mm9_20140215.genePred'
    genomeToFile['mm9_3000'] = '/home/jwawon/Project/UPF1/Data_set/Annotation/mm9/refFlat_mm9_20140215_3000.genePred'
    genomeToFile["hg19_sophie"] = "/home/sophie/annotation/hg19/raw_file/hg19_refseq20130909_only3UTR_longest3UTR.refFlat"
    genomeToFile["hg19_sophie_lncRNA"] = "/home/sophie/annotation/lncRNA/hg19/Homo_sapiens.GRCh37.54_lnc_bothInt2_lgstTX_rpm0.refFlat"
    genomeToFile["mm9_sophie"] = "/home/sophie/annotation/mm9/Refseq_20131124_only3UTR_longest3UTR.refFlat"
    genomeToFile["mm9_sophie_lncRNA"] = "/home/sophie/annotation/lncRNA/mm9/mm10To9_vega56_lnc_intv2_longestTX_rpm0.refFlat"

    genomeToFile['hg19'] = '/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/refFlat.txt'
    genomeToFile['dm3'] = '/home/jwnam/WI/bartel3_ata/jwnam/d.melanogaster/annotation/refFlat.txt'
    filename = genomeToFile[genomeName]
    geneList = dict()
    f = open(filename)
    lines = f.readlines()
    nnum=0
    updatedUTRNum=0
    updatedUTRNum_100D=0
    for line in lines:
        raw_line = line.split('\t')
	if len(raw_line)==10: raw_line.insert(1, raw_line[0])
        name = raw_line[0]
	if len(name)==0: nnum+=1; name = str(nnum)
        geneID = raw_line[1]
	if genomeName=='sangerGene' or genomeName=='sangerPseudogene' or genomeName=='sangerRna':
		name = geneID
        #///////////
        newEnd = int(newRefFlat.get(geneID,-1))
#	print geneID, newEnd

        chr = raw_line[2]
        sense = raw_line[3]
        txCoords = map(int,raw_line[4:6])
        cdCoords = map(int,raw_line[6:8])
        exStarts = map(int,raw_line[9].split(',')[:-1])
        exEnds = map(int,raw_line[10].split(',')[:-1])
        # fix the edges to work with the Gene specs
#        exEnds = map(lambda n: n-1, exEnds)     ********************************

        #print geneID, sense, txCoords,
        if newEnd>0:
           if sense=='+':
              txCoords = [txCoords[0], newEnd]
              #exEnds[-1] = max(exEnds[-1],newEnd)
              
	      if abs(exEnds[-1]-newEnd)>=100: updatedUTRNum_100D+=1
	      if abs(exEnds[-1]-newEnd)>=1: updatedUTRNum+=1
              exEnds[-1] = newEnd
           else:
              txCoords = [newEnd, txCoords[1]]
              #exStarts[0] = min(exStarts[0],newEnd)
	      if abs(exStarts[0]-newEnd)>=100: updatedUTRNum_100D+=1
	      if abs(exStarts[0]-newEnd)>=1: updatedUTRNum+=1
              exStarts[0] = newEnd
        #print txCoords
        cdCoords = [cdCoords[0], max([cdCoords[1],0])]
        if cdCoords[0]!=0 or cdCoords[1]!=0:
            newGene = utilityModule.Gene(name,geneID,chr,sense,txCoords,cdCoords,exStarts,exEnds)
            if not(geneList.has_key(geneID)): geneList[geneID] = newGene
	    else:
		preGene = geneList[geneID]
		geneLen = preGene.txLocus().end() - preGene.txLocus().start()
		geneLen2 = txCoords[1]-txCoords[0]
		if geneLen2>geneLen: geneList[geneID] = newGene
    f.close()
    print '#Updated 3UTR Number: ' + str(updatedUTRNum)
    print '#Updated 3UTR Number(>=100): ' + str(updatedUTRNum_100D)
    return geneList
