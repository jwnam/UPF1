

import sys, numpy, time, os
import annotationImporter as anno, utilityModule as util, UPF1module as Umodule

cellLine = sys.argv[1]			## mES, HeLa_Zhen, HeLa_Tani, HeLa_BIGlab_UPF1KD

histoneFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/all_histone.txt"

startT = time.time()			## check elapse time
print "Start analysis: 00:00:00"


if cellLine == "ENCODE_HepG2":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getRefFlat2("hg19")
	junctionBedFileName = "/home/jwawon/Project/UPF1/Data_set/RNA-seq/Human/HepG2/ENCODE_HepG2_junctions.bed"
	siRNA_list = ['CCAACCCGATAAACCGATGTT']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HepG2/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HepG2/ENCODE_HepG2_UPF1KD_multi5_foldChange.txt"


if cellLine == "ENCODE_K562":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getRefFlat2("hg19")
	junctionBedFileName = "/home/jwawon/Project/UPF1/Data_set/RNA-seq/Human/K562/ENCODE_K562_junctions.bed"
	siRNA_list = ['GCATCTTATTCTGGGTAATAA']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/K562/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/K562/ENCODE_K562_UPF1KD_multi5_foldChange.txt"


if cellLine == "HeLa_BIGlab_TNRC6KD_UPF1KD_to_TNRC6KD":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/TNRC6_Exp/junctions/siUPF1_siTNRC6_to_siTNRC6_junction.bed"
	siRNA_list = ['GCCUAAUCUCCGUGCUCAA', 'GCAUUAAGUGCUAAACAAA', 'CCAAGAUGCAGUUCCGCUCCAUU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/TNRC6_Exp/TNRC6KD/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/TNRC6_Exp/TNRC6KD_UPF1KD_to_TNRC6KD_multi5_foldChange.txt"

if cellLine == "HeLa_BIGlab_TNRC6KD_UPF1KD_to_UPF1KD":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/TNRC6_Exp/junctions/siUPF1_siTNRC6_to_siUPF1_junction.bed"
	siRNA_list = ['GCCUAAUCUCCGUGCUCAA', 'GCAUUAAGUGCUAAACAAA', 'CCAAGAUGCAGUUCCGCUCCAUU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/TNRC6_Exp/UPF1KD/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/TNRC6_Exp/TNRC6KD_UPF1KD_to_UPF1KD_multi5_foldChange.txt"

if cellLine == "HeLa_BIGlab_SMG7KD":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/smg7_Exp/junctions/siSMG7_siControl_junctions.bed"
	siRNA_list = ['CAGCUGGCUUGUAGACUGUGCUGUU', 'CCUACGCCACCAAUUUCGU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/smg7_Exp/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/smg7_Exp/BIG_SMG7KD_multi5_foldChange.txt"

if cellLine == "HeLa_BIGlab_DicerExp_UPF1KD":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/Dicer_Exp/junctions/UPF1KD_controlKD_junctions.bed"
	siRNA_list = ['CCAAGAUGCAGUUCCGCUCCAUU', 'CCUACGCCACCAAUUUCGU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/UPF1KD_jungyun/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/Dicer_Exp/DicerExp_UPF1KD_multi5_foldChange.txt"


if cellLine == "HeLa_BIGlab_DicerExp_DicerKD_UPF1KD_to_DicerKD":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/Dicer_Exp/junctions/UPF1KD_DicerKD_junctions.bed"
	
	siRNA_list = ['CCAAGAUGCAGUUCCGCUCCAUU', 'UAUAUAAUUAGAGAUGGGUGCCCUU', 'UUAUGAUCCAGAGCUGCUUCAAGCA']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Dicer_Exp/DicerKD/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/Dicer_Exp/DicerExp_DicerKD_UPF1KD_to_DicerKD_multi5_foldChange.txt"


if cellLine == "HeLa_BIGlab_Helicase_MTtoWT":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/Helicase_Exp/junctions/myc-UPF1-siUPF1_junctions_new.bed"
	siRNA_list = ['GAUGCAGUUCCGCUCCAUU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Helicase_Exp/helicaseMT/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/Helicase_Exp/Helicase_MTtoWT_multi5_foldChange.txt"

if cellLine == "HeLa_BIGlab_Helicase_UPF1KD":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/BIGlab/Helicase_Exp/junctions/siUPF1_junctions_new.bed"
	siRNA_list = ['GAUGCAGUUCCGCUCCAUU', 'CCUACGCCACCAAUUUCGU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/BIGlab/Helicase_Exp/UPF1KD/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/BIGlab/Helicase_Exp/Helicase_UPF1KD_multi5_foldChange.txt"

if cellLine == "HeLa_Tani":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/Tani/junctions/HeLa_Tani_junctions_new.bed"
	siRNA_list = ['AAUUUCUGUAACUUGUUUCCU', 'GAAACAAGUUACAGAAAUUAC', 'GTACCTGACTAGTCGCAGAAG', 'UUCUCCGAACGUGUCACGUTT']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/Tani/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/Tani/Tani_UPF1KD_multi5_foldChange.txt"

if cellLine == "HeLa_Wang":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/export/Data_Set/Genome/human/hg19/blat/"
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/hg19/gencode.v19.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/HeLa/Wang/junctions/HeLa_Zhen_junctions_new.bed"
	siRNA_list = ['GAUGCAGUUCCGCUCCAUU', 'UGAAUUAGAUGGCGAUGUU']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/HeLa/Wang/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/HeLa/Wang/Wang_UPF1KD_multi5_foldChange.txt"

if cellLine == "mES_Hurt": 
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,20))) + ['chrX','chrY','chrM']
	nib ='/Data_Set/Genome/mouse/mm9/blat/'
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/mm9/gencode.vM1.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("mm9", 'major', 'mESC')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/mES/Hurt/junctions/mES_junctions_new.bed"

	siRNA_list = ['GCTGCCATGAACATCCCTATT', 'AGCTATGTGGCTTAGTCTATC', 'ACAACAGCCACAACGTCTATA']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/mES/Hurt/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/mES/Hurt_UPF1KD_multi5_foldChange.txt"

if cellLine == "mES_SMG6KD_rep1": 
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,20))) + ['chrX','chrY','chrM']
	nib ='/Data_Set/Genome/mouse/mm9/blat/'
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/mm9/gencode.vM1.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("mm9", 'major', 'mESC')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/mES/Li/junctions/SMG6KD_rep1_junctions.bed"
	siRNA_list = ['GGCTTGCCAGCAACTTACA']
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/mES/Li/SMG6KD_rep1/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/mES/Li_SMG6KD_rep1_multi5_foldChange.txt"

if cellLine == "mES_SMG6KD_rep2": 
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,20))) + ['chrX','chrY','chrM']
	nib ='/Data_Set/Genome/mouse/mm9/blat/'
	GENECODE_FileName = "/home/jwawon/Project/UPF1/Data_set/Annotation/mm9/gencode.vM1.annotation_NMD.gtf"
	geneAnno = anno.getNewRefFlat("mm9", 'major', 'mESC')
	junctionBedFileName = "/home/jwawon/Project/UPF1/02.nonNMDeffect/mES/Li/junctions/SMG6KD_rep2_junctions.bed"
	siRNA_list = ['GGCTTGCCAGCAACTTACA'] #control
	outputDir = "/home/jwawon/Project/UPF1/02.nonNMDeffect_offtarget/mES/Li/SMG6KD_rep2/"
	fpkmFileName = "/home/jwawon/Project/UPF1/01.expression/mES/Li_SMG6KD_rep2_multi5_foldChange.txt"

if not os.path.exists(outputDir): os.makedirs(outputDir)


################################## step1 ######################################
# Data setting of FPM_file, NMD_GENECODE_anno, junction File (tophat), filtered genelist by NM and NMD_GENECODE
histone_geneName = dict()
histoneFile = open(histoneFileName, 'r')
histoneLines = histoneFile.readlines()
histoneFile.close()
for lines in histoneLines:
	line = lines.strip('\n').split('\t')
	geneName = line[1]
	if cellLine == "mES":
		geneName = geneName.lower().capitalize()
		if geneName.startswith("HI"):
			histone_geneName[geneName] = 1
	else:
		if geneName.startswith("HI"): 
			histone_geneName[geneName] = 1


geneName_fpkm = dict()
fpkmFile = open(fpkmFileName, 'r')
fpkmLines = fpkmFile.readlines()
fpkmFile.close()
for lines in fpkmLines:
	line = lines.strip('\n').split('\t')
	geneName = line[0]
	foldChange = line[1]
	controlFPKM = line[3]
	targetFPKM = line[4]
	geneName_fpkm[geneName] = foldChange + "\t" + controlFPKM + "\t" + targetFPKM

GENECODE_geneID_dict = dict()
NMD_File = open(GENECODE_FileName, 'r')
NMD_Lines = NMD_File.readlines()
NMD_File.close()
for lines in NMD_Lines:
	line = lines.strip('\n').split('\t')
	geneID = line[1]
	GENECODE_geneID_dict[geneID] = 1



junctionBedFile = open(junctionBedFileName, 'r')
junctionLists = junctionBedFile.readlines()
junctionBedFile.close()

junctionLocusList = []

for junctionlist in junctionLists:
	if junctionlist.startswith("chr"):
		junctionLine = junctionlist.strip().split('\t')
		junctionChr = junctionLine[0]
		junctionStart = junctionLine[1]
		junctionEnd = junctionLine[2]
		junctionSense = junctionLine[5]
		junctionLocus = Umodule.Locus(junctionChr, junctionStart, junctionEnd, junctionSense)
		junctionLocusList.append(junctionLocus)

#/////////////////////////////////////////////////////////////////
## make hash tables of siRNA list

#for siRNA_lines in siRNA_UPF1_list:
sevenD = dict()
seedD = dict()
seqToHitsTo8m = dict()
seqToHitsTo7m8 = dict()
seqToHitsTo7A1 = dict()
seqToHitsToSeed = dict()


for siRNAseq in siRNA_list:
	antisense_siRNAseq = util.reverseComp(util.UtoT(siRNAseq))
	sevenSeq = util.reverseComp(util.UtoT(antisense_siRNAseq[1:8]))
	seedSeq = util.reverseComp(util.UtoT(antisense_siRNAseq[1:7]))
	if not (sevenD.has_key(sevenSeq)): sevenD[sevenSeq] = 1
	if not (seedD.has_key(seedSeq)): seedD[seedSeq] = 1
	siRNAlength = len(siRNAseq)

for seedKey in seedD.keys():
	seedseq = seedKey.upper()
	seqToHitsToSeed[seedseq] = []
	seqToHitsTo7A1[seedseq + 'A'] = []
for sevenKey in sevenD.keys():
	sevenseq = sevenKey.upper()
	seqToHitsTo8m[sevenseq + 'A'] = []
	seqToHitsTo7m8[sevenseq] = []




#genelist = filter(lambda x: x[0], geneAnno.items())
genelist = filter(lambda x: x[0][:2]=='NM', geneAnno.items())
#genelist = filter(lambda x: geneName_fpkm.has_key(x[0]), geneAnno.items())

#///////////////////////// elapsed time check /////////////////////
dataSettingT = time.time()            #check junction DataSettingT elapse time
dataElapseT = Umodule.elapseTime(startT, dataSettingT)
print "Finish data setting: ", dataElapseT



################################## step2 ######################################
# make object of refFlat file


TotalgeneC = len(genelist)
geneC = 0

geneName_dic = dict()
spurious_geneID = dict()
GENECODE_list = []
tpUTR_intron_dict = dict()
tpUTRlength_dict = dict()
geneID_list = []
potential_NMD_dict = dict()
potenIntron_dict = dict()
filtered_geneID = dict()
onetpExon_dict = dict()
offTarget_dict = dict()
geneID_geneName = dict()
multiExon_dict = dict()

for gene in genelist:
	geneC += 1
	status = int(float(geneC)/float(TotalgeneC) * 100)
	geneName = gene[1].name()
	geneID = gene[1].geneID()
	geneID_geneName[geneID] = geneName
	geneID_list.append(geneID)
	chr = gene[1].chr()
	if chr in chr_info:
		geneName = gene[1].name()
		sense = gene[1].sense()
		cdExons = gene[1].cdExons()
		txExons = gene[1].txExons()
		txExonCount = len(txExons)
		if sense == '+': lastTxExon = txExons[txExonCount -1]
		elif sense == '-': lastTxExon = txExons[0]
		fpExons = gene[1].fpExons(sense)
		tpUTR = gene[1].tpUtr()
		introns = gene[1].introns()
		tpExons = gene[1].tpExons(sense)
		
		tpExonCount = len(tpExons)
		tpExonsSeq = Umodule.getListSequence2(tpExons, nib, sense)
		tpUTRLength = len(tpExonsSeq)

		tpUTRlength_dict[geneID] = tpUTRLength

		if geneName_dic.has_key(geneName): 
			geneName_dic[geneName][0].append(geneID)
			geneName_dic[geneName][1].append(tpUTRLength)
		else: 
			geneName_dic[geneName] = [[],[]]
			geneName_dic[geneName][0].append(geneID) 
			geneName_dic[geneName][1].append(tpUTRLength)
		
		if len(cdExons) != 0 and len(tpExons) !=0 and len(fpExons) !=0:
			cdsSeq = Umodule.getListSequence2(cdExons, nib, sense)
			#print cdsSeq
			cdsLength = len(cdsSeq)


 			fpExonsSeq = Umodule.getListSequence2(fpExons, nib, sense)
			fpUTRLength = len(fpExonsSeq)
			
			# if fpUTRLength >= 25 and cdsLength >= 200 and tpUTRLength >= 50:
			if fpUTRLength >= 25 and cdsLength >= 200:
				filtered_geneID[geneID] = 1
			else: spurious_geneID[geneID] = 1
				
			if GENECODE_geneID_dict.has_key(geneID):
				GENECODE_list.append(geneID)
			if tpExonCount == 1: 
				for junctionLocus in junctionLocusList:
					if junctionLocus.overlaps(tpUTR):
						tpUTR_intron_dict[geneID] = junctionLocus
						break
					break
			##################################### NMD ###############################
			cdsExonlength = map(lambda x: x.len(), cdExons)
			if sense == '-': cdsExonlength.reverse()
			cdsSplsites = [0]
			site = 0
			for length in cdsExonlength:
				site += length
				cdsSplsites.append(site)
			for n in xrange(0, cdsLength, 3):
				locStop = cdsSeq[n:n+3]
				if locStop == 'TAG' or locStop == 'TAA' or locStop == 'TGA':
					if int(cdsSplsites[-2]) - n +1 > 50:
							potential_NMD_dict[geneID] = "NMD"
					break

					

			potenIntronlength = Umodule.potentialIntron(tpExonsSeq)
			if potenIntronlength > 60:
				potenIntron_dict[geneID] = 1
			if tpExonCount == 1:
				onetpExon_dict[geneID] = 1
			elif tpExonCount > 1:
				multiExon_dict[geneID] = 1
			
			for n in xrange(len(tpExonsSeq) - siRNAlength + 1):
				locSeq8 = tpExonsSeq[n:n+8]
				locSeq7 = tpExonsSeq[n:n+7]
				locSeq6 = tpExonsSeq[n:n+6]
				if seqToHitsTo8m.has_key(locSeq8):
					offTarget_dict[geneID] = '8mer'
					break
				elif seqToHitsTo7m8.has_key(locSeq7):
					offTarget_dict[geneID] = '7m8'
					break
				elif seqToHitsTo7A1.has_key(locSeq7):
					offTarget_dict[geneID] = '7A1'
					break
	sys.stdout.write("\r%s%d%%" % ("Filtering status: ", status))
	sys.stdout.flush()
					
analysisT = time.time()
analysisElapseT = Umodule.elapseTime(startT,analysisT)

pipeLineStatFileName = outputDir+ cellLine + '_pipeline_stats.txt'
pipeLineStatFile = open(pipeLineStatFileName, 'w')
pipeLineStatFile.write('\n'+ "Filtering finished: " + analysisElapseT+ "\n")

## filtered geneID count
totalgene = len(geneID_list)
pipeLineStatFile.write("total geneID: "+ str(totalgene)+ "\n")

lengthfilteredgene = 0
for geneID in filtered_geneID.keys(): lengthfilteredgene += 1
pipeLineStatFile.write("Filtered by length: " + str(lengthfilteredgene)+ "\n")

genecodeNMD = len(GENECODE_list)
pipeLineStatFile.write("GENECODE NMD genes: " + str(genecodeNMD)+ "\n")

junction = 0
for geneID in tpUTR_intron_dict.keys(): junction += 1
pipeLineStatFile.write("junction file overlap genes: " + str(junction)+ "\n")

potenNMD = 0
for geneID in potential_NMD_dict.keys(): potenNMD += 1
pipeLineStatFile.write("potential_NMD genes: " + str(potenNMD)+ "\n")

potenSpl = 0
for geneID in potenIntron_dict.keys(): potenSpl += 1
pipeLineStatFile.write("potential splicing signal genes: " + str(potenSpl)+ "\n")

oneTpExon = 0
for geneID in onetpExon_dict.keys(): oneTpExon +=1
pipeLineStatFile.write("one 3'UTR exon genes: " + str(oneTpExon)+ "\n")

offTarget = 0
for geneID in offTarget_dict.keys(): offTarget += 1
pipeLineStatFile.write("The genes have off target effect on 3'UTR: " + str(offTarget)+ "\n")

pipeLineStatFile.write('\n' + '----------------------------------------------' + '\n')

################################## step3 ######################################
# apply each filter
## gene level
NMD_dependent_list = []


filteredGenesFileName = outputDir+ cellLine + '_filteredGenes.txt'
filteredGenesFile = open(filteredGenesFileName, 'w')

pipeLineStatFile.write("The number of total genes: " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	if histone_geneName.has_key(geneName): 
		filteredGenesFile.write("histoneGenes" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
		del geneName_dic[geneName]
pipeLineStatFile.write("Filtered histone genes: " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if spurious_geneID.has_key(geneID): 
			filteredGenesFile.write("spurious" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
			del geneName_dic[geneName]; break
pipeLineStatFile.write("Filtered spurious gene: " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if GENECODE_geneID_dict.has_key(geneID): 
			NMD_dependent_list.append(geneID)
			filteredGenesFile.write("GENCODE_NMD" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
			del geneName_dic[geneName]; break
pipeLineStatFile.write("Filtered GENECODE NMD: " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if tpUTR_intron_dict.has_key(geneID): 
			NMD_dependent_list.append(geneID)
			filteredGenesFile.write("tpUTRjunctionReads" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
			del geneName_dic[geneName]; break
pipeLineStatFile.write("Filtered 3'UTR overlap with RNAseq junction: " + str(len(geneName_dic.keys())) + "\n")


for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if potential_NMD_dict.has_key(geneID): 
			NMD_dependent_list.append(geneID)
			filteredGenesFile.write("potentialPTC" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
			del geneName_dic[geneName]; break
pipeLineStatFile.write("Filtered potential NMD (PTC): " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if potenIntron_dict.has_key(geneID): 
			filteredGenesFile.write("potentialIntron" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
			del geneName_dic[geneName]; break
pipeLineStatFile.write("Filtered potential splicing signal in 3'UTR: " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if not onetpExon_dict.has_key(geneID): 
			filteredGenesFile.write("multiTpExons" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")
			del geneName_dic[geneName]; break
pipeLineStatFile.write("Filtered multi exon on tpUTR: " + str(len(geneName_dic.keys())) + "\n")

for geneName in geneName_dic.keys():
	for geneID in geneName_dic[geneName][0]:
		if offTarget_dict.has_key(geneID):
			filteredGenesFile.write("offTarget" + "\t" + geneName + "\t" + ",".join(geneName_dic[geneName][0]) + "\n")

filteredGenesFile.close()

final_geneID_dic = dict()
geneName_geneID = dict()
for geneName in geneName_dic.keys():
	geneID_maxtpUTR = geneName_dic[geneName][0][geneName_dic[geneName][1].index(max(geneName_dic[geneName][1]))]
	final_geneID_dic[geneID_maxtpUTR] = geneName


pipeLineStatFile.write("After isoform selection (the longest 3'UTR): " + str(len(final_geneID_dic.keys()))+ "\n")



################################## step4 ######################################
# bining final genePred list according to tpUTR length


n50 = 0
n350= 0
n500 = 0
n800 = 0
allCount = 0
for geneID in final_geneID_dic.keys():
	if tpUTRlength_dict.has_key(geneID) and geneName_fpkm.has_key(final_geneID_dic[geneID]):
		allCount += 1
		length = tpUTRlength_dict[geneID]
		if 50 <= length < 350: n50 +=1
		elif 350 <= length < 500: n350 +=1
		elif 500 <= length < 800: n500 +=1
		elif 800 <= length < 20000: n800 +=1

pipeLineStatFile.write("Total transcript with FPKM: " + "\t" + str(allCount)+ "\n")
pipeLineStatFile.write("50 <= length < 350: " + "\t" + str(n50)+ "\n")
pipeLineStatFile.write("350 <= length < 500: " + "\t" + str(n350)+ "\n")
pipeLineStatFile.write("500 <= length < 800: " + "\t" + str(n500)+ "\n")
pipeLineStatFile.write("800 <= length < 20000: " + "\t" + str(n800)+ "\n")




FileNameAll = outputDir+ cellLine + '_onetpEx_noNMD_all.txt'
FileAll = open(FileNameAll, 'w')

FileName800nt = outputDir+ cellLine + '_onetpEx_noNMD_800nt.txt'
File800nt = open(FileName800nt, 'w')

FileName500nt =outputDir+ cellLine +'_onetpEx_noNMD_500nt.txt'
File500nt = open(FileName500nt, 'w')

FileName350nt = outputDir+ cellLine +'_onetpEx_noNMD_350nt.txt'
File350nt = open(FileName350nt, 'w')

FileName50nt = outputDir+ cellLine +'_onetpEx_noNMD_50nt.txt'
File50nt = open(FileName50nt, 'w')


for geneID in final_geneID_dic.keys():
        if tpUTRlength_dict.has_key(geneID) and geneName_fpkm.has_key(final_geneID_dic[geneID]):
                tpUTRlength = tpUTRlength_dict[geneID]
                FileAll.write(geneID + '\t' +str(tpUTRlength_dict[geneID])  +'\t' + geneID_geneName[geneID] + "\t" +  geneName_fpkm[final_geneID_dic[geneID]] + '\n')
                if 800 <= tpUTRlength < 20000: File800nt.write(geneID + '\t' +str(tpUTRlength_dict[geneID]) +'\t' + geneID_geneName[geneID] + "\t" +  geneName_fpkm[final_geneID_dic[geneID]] + '\n')
                elif 500 <= tpUTRlength < 800: File500nt.write(geneID + '\t' +str(tpUTRlength_dict[geneID]) +'\t' + geneID_geneName[geneID] + "\t" +  geneName_fpkm[final_geneID_dic[geneID]] + '\n')
                elif 350 <= tpUTRlength < 500: File350nt.write(geneID + '\t' +str(tpUTRlength_dict[geneID]) +'\t' + geneID_geneName[geneID] + "\t" +  geneName_fpkm[final_geneID_dic[geneID]] + '\n')
                elif 50 <= tpUTRlength < 350: File50nt.write(geneID + '\t' +str(tpUTRlength_dict[geneID]) +'\t' + geneID_geneName[geneID] + "\t" +  geneName_fpkm[final_geneID_dic[geneID]] + '\n')
FileAll.close()
File800nt.close()
File500nt.close()
File350nt.close()
File50nt.close()


#/////////// off target file ////////////

noOffTargetgenelist = filter(lambda x: not (offTarget_dict.has_key(x)), final_geneID_dic.keys())

FinalgeneC_noOff = len(noOffTargetgenelist)

pipeLineStatFile.write("\n" + "--------------------------------------------------------------"  + "\n")
pipeLineStatFile.write("Filtered off target: " + str(len(noOffTargetgenelist))+ "\n")

all_noOff = 0
n50_noOff = 0
n350_noOff= 0
n500_noOff = 0
n800_noOff = 0

for geneID in noOffTargetgenelist:
	if tpUTRlength_dict.has_key(geneID) and geneName_fpkm.has_key(final_geneID_dic[geneID]):
		all_noOff += 1
		length = tpUTRlength_dict[geneID]
		if 50 <= length < 350: n50_noOff +=1
		elif 350 <= length < 500: n350_noOff +=1
		elif 500 <= length < 800: n500_noOff +=1
		elif 800 <= length < 20000: n800_noOff +=1

pipeLineStatFile.write("Total transcript with FPKM (no off target): " + "\t" + str(all_noOff)+ "\n")
pipeLineStatFile.write("50 <= length < 500  (no off target): " + "\t" + str(n50_noOff)+ "\n")
pipeLineStatFile.write("350 <= length < 500 (no off target): " + "\t" + str(n350_noOff)+ "\n")
pipeLineStatFile.write("500 <= length < 800 (no off target): " + "\t" + str(n500_noOff)+ "\n")
pipeLineStatFile.write("800 <= length < 20000 (no off target): " + "\t" + str(n800_noOff)+ "\n")

offFileNameAll =outputDir+ cellLine +'_onetpEx_noNMD_offtarget_all.txt'
offFileAll = open(offFileNameAll, 'w')

offFileName800nt =outputDir+ cellLine +'_onetpEx_noNMD_offtarget_800nt.txt'
offFile800nt = open(offFileName800nt, 'w')

offFileName500nt =outputDir+ cellLine +'_onetpEx_noNMD_offtarget_500nt.txt'
offFile500nt = open(offFileName500nt, 'w')

offFileName350nt =outputDir+ cellLine +'_onetpEx_noNMD_offtarget_350nt.txt'
offFile350nt = open(offFileName350nt, 'w')

offFileName50nt = outputDir+ cellLine +'_onetpEx_noNMD_offtarget_50nt.txt'
offFile50nt = open(offFileName50nt, 'w')

for geneID in noOffTargetgenelist:
	if tpUTRlength_dict.has_key(geneID) and geneName_fpkm.has_key(final_geneID_dic[geneID]):
		tpUTRlength = tpUTRlength_dict[geneID]
		offFileAll.write(geneID + '\t' +str(tpUTRlength_dict[geneID]) + '\t' + geneID_geneName[geneID] + "\t" +  geneName_fpkm[final_geneID_dic[geneID]] + '\n')
		if 800 <= tpUTRlength < 20000: offFile800nt.write(geneID  + '\t'+ str(tpUTRlength_dict[geneID]) + '\t' +   geneID_geneName[geneID] + "\t" + geneName_fpkm[final_geneID_dic[geneID]] +  '\n')
		elif 500 <= tpUTRlength < 800: offFile500nt.write(geneID  + '\t'+ str(tpUTRlength_dict[geneID]) + '\t' +   geneID_geneName[geneID] + "\t" + geneName_fpkm[final_geneID_dic[geneID]] + '\n')
		elif 350 <= tpUTRlength < 500: offFile350nt.write(geneID  + '\t'+ str(tpUTRlength_dict[geneID]) + '\t' +  geneID_geneName[geneID] + "\t" + geneName_fpkm[final_geneID_dic[geneID]] + '\n')
		elif 50 <= tpUTRlength < 350: offFile50nt.write(geneID + '\t'+ str(tpUTRlength_dict[geneID]) + '\t' +  geneID_geneName[geneID] + "\t" + geneName_fpkm[final_geneID_dic[geneID]] + '\n')

offFile800nt.close()
offFile500nt.close()
offFile350nt.close()
offFile50nt.close()


