


import sys, random, numpy, time, os, math
import annotationImporter as anno, utilityModule as util, UPF1module as Umodule, AGO2_UPF1_miRNA_7A1_effect_module as mainModule
from scipy import stats

startT = time.time() 		#check elapse time
# print "Start analysis: 00:00:00"

cellLine = sys.argv[1]
clipType = sys.argv[2] 	#HeLa_origin, HeLa_Homer, HeLa_PIPE
expressionFile = sys.argv[3]
outputDir = sys.argv[4]
miRNA_top = sys.argv[5]
mre = sys.argv[6]
if cellLine.split("_")[0] == "HCT116":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/Data_Set/Genome/human/hg19/blat/"
	geneAnno = anno.getRefFlat2("hg19")
	if miRNA_top == "top3": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HCT116/HCT116_miRNA_list_newCollapse_top3.txt"
	if miRNA_top == "top5": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HCT116/HCT116_miRNA_list_newCollapse_top5.txt"
	if miRNA_top == "top10": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HCT116/HCT116_miRNA_list_newCollapse_top10.txt"
	if miRNA_top == "top30": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HCT116/HCT116_miRNA_list_newCollapse_top30.txt"
	if miRNA_top == "top50": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HCT116/HCT116_miRNA_list_newCollapse_top50.txt"
	top50_miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top50.txt"

if cellLine.split("_")[0] == "HeLa":
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,23))) + ['chrX','chrY','chrM']
	nib = "/Data_Set/Genome/human/hg19/blat/"
	geneAnno = anno.getNewRefFlat("hg19", 'major', 'HeLa')
	if miRNA_top == "top3": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top3.txt"
	if miRNA_top == "top5": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top5.txt"
	if miRNA_top == "top10": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top10.txt"
	if miRNA_top == "top30": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top30.txt"
	if miRNA_top == "top50": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top50.txt"
	top50_miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/HeLa/HeLa_miRNA_list_newCollapse_top50.txt"

if cellLine.split("_")[0] == "mES": 
	chr_info = map(lambda x: 'chr'+x, map(str, range(1,20))) + ['chrX','chrY','chrM']
	nib ='/Data_Set/Genome/mouse/mm9/blat/'
	geneAnno = anno.getNewRefFlat("mm9", 'major', 'mESC')
	if miRNA_top == "top10": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top10.txt"
	if miRNA_top == "top30": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top30.txt"
	if miRNA_top == "top50": miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top50.txt"
	top50_miRNAfile = "/home/jwawon/Project/UPF1/03.miRNAtarget_UPF1KD_effect/mES/mES_miRNA_list_top50.txt"


############ HeLa CLIPseq type ############
if clipType == "HeLa_Homer":
	ago2CLIPseqfile = "/home/jwawon/Project/UPF1/Data_set/CLIP-seq/HeLa/GSE43666_AGO2/homer/Union/AGO2_Union_homerPeak.merge.bed"
	upf1CLIPseqfile = "/home/jwawon/Project/UPF1/Data_set/CLIP-seq/HeLa/GSE47976_UPF1/homer/Union/UPF1_all_homerPeak.merge.bed"

############ mES CLIPseq type ############
if clipType == "mES_origin":
	ago2CLIPseqfile = "/home/jwawon/Project/UPF1/Data_set/CLIP-seq/mES/GSE25310_AGO2/AGO2_all_3UTR_cluster_bedmerge40.bed"
	upf1CLIPseqfile = "/home/jwawon/Project/UPF1/Data_set/CLIP-seq/mES/GSE41785_UPF1/UPF1_all_CLIPseq_bedmerge20.bed"


## fpkm data

writeGeneID_log2Fold = open(outputDir + cellLine + "_geneID_sorted_log2Fold_upper0.txt", 'w')
geneID_fpkmLength = mainModule.get_geneID_fpkm_length(expressionFile)
for geneID in sorted(geneID_fpkmLength, key=geneID_fpkmLength.get, reverse=True):
	log2Fold = geneID_fpkmLength[geneID][0]
	# print geneID, log2Fold
	if log2Fold >=0:
		writeGeneID_log2Fold.write(geneID +"\t" + str(log2Fold) + "\n")
writeGeneID_log2Fold.close()

## peak data
AGO2_chr_peakObj = mainModule.get_peakObj(ago2CLIPseqfile)
UPF1_chr_peakObj = mainModule.get_peakObj(upf1CLIPseqfile)

#### miRNA preprocessing ####
## miRNA top data

seqToHitsToSites_list, miRNAseqDic =  mainModule.get_miRNAsites_dic(miRNAfile, "miRNA")
top50_seqToHitsToSites_list, top50_miRNAseqDic =  mainModule.get_miRNAsites_dic(top50_miRNAfile, "miRNA")


######################################################################################################
## main
######################################################################################################


group_all_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
group_50nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[], "noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
group_350nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
group_500nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
group_800nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}

mild_group_all_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
mild_group_50nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
mild_group_350nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
mild_group_500nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}
mild_group_800nt_fpkm_dict = {"random_noAGO2-noUPF1-noSites":[], "random_AGO2-noSites":[], "random_UPF1-noSites":[], "random_AGO2-UPF1-noSites":[],"noAGO2-noUPF1-noSites":[], "AGO2-noSites":[], "AGO2-sites":[], "AGO2-UPF1-noSites":[], "AGO2-UPF1-sites":[], "UPF1-sites":[],"UPF1-noSites":[]}

group_number_dict = {"AGO2-sites":[], "AGO2-noSites":[], "UPF1-sites":[], "UPF1-noSites":[], "AGO2-UPF1-sites":[], "AGO2-UPF1-noSites":[]}
relativeDis_sites = []
relativeDis_noSites = []
group_relativePos_dict = {"AGO2-sites":[], "AGO2-noSites":[], "UPF1-sites":[], "UPF1-noSites":[], "AGO2-UPF1-sites":[], "AGO2-UPF1-noSites":[]}
siteN_fpkm_dict = dict()
siteContext_fpkm_dict = {"8mer": [], "7m8": [], "7A1": [], "6mer": [], "noSites": []}
length_overlapSitesN_dict = {"50nt": [], "350nt": [], "500nt": [], "800nt": []}
length_sitesN_dict = {"50nt": [], "350nt": [], "500nt": [], "800nt": []}
overlapSitesN_fpkm_dict = dict()
ago2SitesN_fpkm_dict = dict()

all_candidate_fpkm = dict()
sites_candidate_fpkm = dict()

AGO2_UPF1_sites_candidate_fpkm = dict()
AGO2_UPF1_sites_candidate_miRNA = dict()
AGO2_UPF1_noSites_candidate = dict()
noAGO2_noUPF1_noSites_candidate = dict()

geneID_tpUTRseq = dict()
geneID_geneName = dict()

noSites_genes = dict()
noAGO2_noUPF1_noSites_genes = dict()
AGO2_noSites_genes = dict()
UPF1_noSites_genes = dict()
AGO2_UPF1_noSites_genes = dict()
noAGO2_noUPF1_noSites_mildGenes = dict()
AGO2_noSites_mildGenes = dict()
UPF1_noSites_mildGenes = dict()
AGO2_UPF1_noSites_mildGenes = dict()

miRNALocusBed = dict()
geneID_AGO2seq = dict()
geneID_UPF1seq = dict()

ago2upf1noSites_noExc = {"noExc":[], "8mer": [], "7m8":[],"7A1":[], "6mer":[]}

AGO2_sites_group_genes = dict()
AGO2_sites_mildGroup_genes = dict()
miRNAGroup_log2Fold = dict()

allGeneStatisticFile = cellLine +'_allGenes_statistic.txt'
writeAllGeneStatisticFile = open(outputDir+allGeneStatisticFile, 'w')

writeFASTA_tpUTR = open(outputDir + cellLine + "_tpUTRs.fa", 'w')

genelist = filter(lambda x: geneID_fpkmLength.has_key(x[0]), geneAnno.items())
geneCount = 0
for gene in genelist:
	geneCount +=1
	status = int((float(geneCount))/float(len(genelist)) *100)
	geneName = gene[1].name()
	geneID = gene[1].geneID()
	geneID_geneName[geneID] = geneName
	fpkm = geneID_fpkmLength[geneID][0]
	tpUTRlength = geneID_fpkmLength[geneID][1]
	# print "============ " + geneName + " " + geneID + " =============="
	writeAllGeneStatisticFile.write("============ " + geneName + " " + geneID + " ==============" +"\n")
	writeAllGeneStatisticFile.write("log2 fold change: " + "\t" + str(fpkm) + "\n" )
	chr = gene[1].chr()
	sense = gene[1].sense()
	tpUTR = gene[1].tpUtr()
	tpExons = gene[1].tpExons(sense)
	tpUTRseq = Umodule.getListSequence(tpExons, nib)
	geneID_tpUTRseq[geneID] = tpUTRseq
	tpUTRseqFasta_list = []
	for i in range(0, len(tpUTRseq), 50):
		if i+50 < len(tpUTRseq):
			tpUTRseqFasta_list.append(tpUTRseq[i:i+50])
		else: tpUTRseqFasta_list.append(tpUTRseq[i:len(tpUTRseq)])
	tpUTR_fa_line = ">" + geneID + "\n" + "\n".join(tpUTRseqFasta_list)
	# print tpUTR_fa_line
	writeFASTA_tpUTR.write(tpUTR_fa_line + "\n")
	geneID_AGO2seq[geneID] = []
	geneID_UPF1seq[geneID] = []
	if sense == "+": tpUTRstart = tpUTR.start()
	else: tpUTRstart = tpUTR.end()
	dict_8mer, dict_7m8, dict_7A1, dict_6mer, dict_off6mer, dict_sites = mainModule.searchMiRNAsite(chr, sense, tpUTRseq, tpUTRstart, seqToHitsToSites_list, mre)
	miRNAGroup = mainModule.getMiRNAGroup(dict_8mer, dict_7m8, dict_7A1, dict_6mer)
	# print "\n", geneID, miRNAGroup, len(dict_8mer), len(dict_7m8), len(dict_7A1), len(dict_6mer)
	if not miRNAGroup_log2Fold.has_key(miRNAGroup): miRNAGroup_log2Fold[miRNAGroup] = []; miRNAGroup_log2Fold[miRNAGroup].append(fpkm)
	else: miRNAGroup_log2Fold[miRNAGroup].append(fpkm)
	## dict_Xmer = {locusObj:[miRNAname, miRNAseq], ...}  
	# print "8mer: ", len(dict_8mer.keys()), " 7m8: ", len(dict_7m8.keys()), " 7A1: ", len(dict_7A1.keys()), " 6mer: ", len(dict_6mer.keys())
	writeAllGeneStatisticFile.write("8mer: " + str(len(dict_8mer.keys())) + "\t" + "7m8: " + str(len(dict_7m8.keys())) + "\t" + "7A1: " + str(len(dict_7A1.keys())) + "\t" + "6mer: " + str(len(dict_6mer.keys())) + "\n")
	if len(dict_6mer) ==0 and len(dict_sites) == 0: noSites_genes[gene] = []

	if not (AGO2_chr_peakObj.has_key(chr)): AGO2_chr_peakObj[chr] = []
	if not (UPF1_chr_peakObj.has_key(chr)): UPF1_chr_peakObj[chr] = []

	AGO2_peakObjList = AGO2_chr_peakObj[chr]
	UPF1_peakObjList = UPF1_chr_peakObj[chr]
	ago2Peak_sitesNosites, ago2PeakRelativeDis = mainModule.findPeakSites(tpUTR, tpExons, AGO2_peakObjList, dict_sites)
	UPF1Peak_sitesNosites, upf1PeakRelativeDis = mainModule.findPeakSites(tpUTR, tpExons, UPF1_peakObjList, dict_sites)
	## peak_sitesNosites: key = peakObj, value = list of miRNA locus dictionary
	## peak_sitesNosites = {peakObj: [{miRNALocusObj:[miRNAname,seq]}, {miRNALocusObj:[miRNAname,seq]}, {miRNALocusObj:[miRNAname,seq]}]}
	for ago2Peak in ago2Peak_sitesNosites.keys():
		ago2Seq = Umodule.getSequence(ago2Peak, nib)
		geneID_AGO2seq[geneID].append(ago2Seq)
	for UPF1Peak in UPF1Peak_sitesNosites.keys():
		UPF1seq = Umodule.getSequence(UPF1Peak, nib)
		geneID_UPF1seq[geneID].append(UPF1seq)

	upf1OverlapAgo2_dict, overlapAgo2Peak_dic, overlapUpf1Peak_dic, upf1_ago2_relativeDis, overlapRelativePos =  mainModule.findOverlapPeakSites(tpUTR, ago2Peak_sitesNosites, UPF1Peak_sitesNosites)
	## overlap_dict: key = UPF1peakObj, value = dictionary of AGOpeakObj, miRNAcontext
	## overlap_dict = {UPF1peakObj: [AGO2peakObj, [{miRNALocusObj:[miRNAname,seq]}]],}

	writeAllGeneStatisticFile.write("AGO2 peak: " +str(len(ago2Peak_sitesNosites.keys())) + "\t" + "UPF1 peak: " + str(len(UPF1Peak_sitesNosites.keys())) + "\t" + "AGO2-UPF1 peak: "+str(len(upf1OverlapAgo2_dict.keys())) + "\n")

	AGO2_sites_key = filter(lambda x: len(ago2Peak_sitesNosites[x]) > 0 ,ago2Peak_sitesNosites.keys())
	AGO2_noSites_key = filter(lambda x: len(ago2Peak_sitesNosites[x]) == 0 ,ago2Peak_sitesNosites.keys())
	UPF1_sites_key = filter(lambda x: len(UPF1Peak_sitesNosites[x]) > 0 ,UPF1Peak_sitesNosites.keys())
	UPF1_noSites_key = filter(lambda x: len(UPF1Peak_sitesNosites[x]) == 0 ,UPF1Peak_sitesNosites.keys())

	AGO2_UPF1_sites_key_dict = dict()
	UPF1_sites_AGO2_key_dict = dict()
	overlap_sitesN_list = []
	for upf1Peak in upf1OverlapAgo2_dict.keys():
		if len(UPF1Peak_sitesNosites[upf1Peak]) >0:
			UPF1_sites_AGO2_key_dict[upf1Peak] = []
		miRNA_number = 0
		for ago2Peak_Dic in upf1OverlapAgo2_dict[upf1Peak]:
			for peak in ago2Peak_Dic.keys(): 
				if len(ago2Peak_Dic[peak]) > 0: 
					miRNA_number += len(ago2Peak_Dic[peak])
		if miRNA_number > 0: 
			AGO2_UPF1_sites_key_dict[upf1Peak] = miRNA_number
			overlap_sitesN_list.append(miRNA_number)
	total_overlap_sitesN = sum(overlap_sitesN_list)

	AGO2_UPF1_noSites_key = filter(lambda x: not (AGO2_UPF1_sites_key_dict.has_key(x)), upf1OverlapAgo2_dict.keys())

	writeAllGeneStatisticFile.write("AGO2-sites: " + str(len(AGO2_sites_key)) + "\t" + "AGO2-noSites: " + str(len(AGO2_noSites_key))+"\n")
	writeAllGeneStatisticFile.write("UPF1-sites: " + str(len(UPF1_sites_key)) + "\t" + "UPF1-noSites: " + str(len(UPF1_noSites_key))+"\n")
	writeAllGeneStatisticFile.write("AGO2-UPF1-sites: " + str(len(AGO2_UPF1_sites_key_dict.keys())) + "\t" + "AGO2-UPF1-noSites: " + str(len(AGO2_UPF1_noSites_key))+"\n")

	group = mainModule.defineGroup(dict_sites, dict_6mer, AGO2_sites_key, AGO2_noSites_key, UPF1_sites_key, UPF1_noSites_key, AGO2_UPF1_noSites_key, overlapAgo2Peak_dic, overlapUpf1Peak_dic, total_overlap_sitesN)
	mild_group = mainModule.defineMildGroup(len(dict_sites.keys()), len(dict_6mer.keys()), len(AGO2_sites_key), len(AGO2_noSites_key), len(UPF1_sites_key), len(UPF1_noSites_key), len(AGO2_UPF1_sites_key_dict.keys()), len(AGO2_UPF1_noSites_key), len(UPF1_sites_AGO2_key_dict.keys()))
	if len(AGO2_UPF1_sites_key_dict.keys()) == 0 and len(AGO2_UPF1_noSites_key) > 0:
		ago2upf1noSites_noExc["noExc"].append(geneID)
		if len(dict_8mer.keys()) > 0: ago2upf1noSites_noExc["8mer"].append(geneID)
		if len(dict_7m8.keys()) > 0: ago2upf1noSites_noExc["7m8"].append(geneID)
		if len(dict_7A1.keys()) > 0: ago2upf1noSites_noExc["7A1"].append(geneID)
		if len(dict_6mer.keys()) > 0: ago2upf1noSites_noExc["6mer"].append(geneID)


	writeAllGeneStatisticFile.write("stringent class: " + "\t" + group+"\n")
	writeAllGeneStatisticFile.write("mild class: " + "\t" + mild_group+"\n")

	## for noSites randomsite target
	if group =="noAGO2-noUPF1-noSites": noAGO2_noUPF1_noSites_genes[gene] = []
	if group =="AGO2-noSites": AGO2_noSites_genes[gene] = []
	if group =="UPF1-noSites": UPF1_noSites_genes[gene] = []
	if group =="AGO2-UPF1-noSites": AGO2_UPF1_noSites_genes[gene] = []

	if mild_group =="noAGO2-noUPF1-noSites": noAGO2_noUPF1_noSites_mildGenes[gene] = []
	if mild_group =="AGO2-noSites": AGO2_noSites_mildGenes[gene] = []
	if mild_group =="UPF1-noSites": UPF1_noSites_mildGenes[gene] = []
	if mild_group =="AGO2-UPF1-noSites": AGO2_UPF1_noSites_mildGenes[gene] = []

	if group =="AGO2-sites": AGO2_sites_group_genes[geneID] = dict_sites
	if mild_group =="AGO2-sites": AGO2_sites_mildGroup_genes[geneID] = dict_sites

#################################
##### for statistic summary #####
#################################

	#### 1. get group event number 
	group_number_dict["AGO2-sites"].append(len(AGO2_sites_key))
	group_number_dict["AGO2-noSites"].append(len(AGO2_noSites_key))
	group_number_dict["UPF1-sites"].append(len(UPF1_sites_key))
	group_number_dict["UPF1-noSites"].append(len(UPF1_noSites_key))
	group_number_dict["AGO2-UPF1-sites"].append(len(AGO2_UPF1_sites_key_dict.keys()))
	group_number_dict["AGO2-UPF1-noSites"].append(len(AGO2_UPF1_noSites_key))

	#### 2. get relative distance between UPF1 and AGO2
	for upf1Peak in upf1_ago2_relativeDis.keys():
		if AGO2_UPF1_sites_key_dict.has_key(upf1Peak): relativeDis_sites.append(upf1_ago2_relativeDis[upf1Peak])
		else: relativeDis_noSites.append(upf1_ago2_relativeDis[upf1Peak])

	#### 3. get AGO2 and UPF1 relative position on 3'UTR 
	for ago2Peak in ago2PeakRelativeDis.keys():
		if ago2Peak in AGO2_sites_key: group_relativePos_dict["AGO2-sites"].append(ago2PeakRelativeDis[ago2Peak])
		else: group_relativePos_dict["AGO2-noSites"].append(ago2PeakRelativeDis[ago2Peak])
	for upf1Peak in upf1PeakRelativeDis.keys():
		if upf1Peak in UPF1_sites_key: group_relativePos_dict["UPF1-sites"].append(upf1PeakRelativeDis[upf1Peak])
		else: group_relativePos_dict["UPF1-noSites"].append(upf1PeakRelativeDis[upf1Peak])

	for upf1Peak in overlapRelativePos.keys():
		if AGO2_UPF1_sites_key_dict.has_key(upf1Peak): group_relativePos_dict["AGO2-UPF1-sites"].append(overlapRelativePos[upf1Peak])
		else: group_relativePos_dict["AGO2-UPF1-noSites"].append(overlapRelativePos[upf1Peak])

	#### 4. get group total gene fpkm ####
	if group in group_all_fpkm_dict.keys():
		group_all_fpkm_dict[group].append(fpkm)
		if 50 <= tpUTRlength < 350: group_50nt_fpkm_dict[group].append(fpkm)
		elif 350 <= tpUTRlength < 500: group_350nt_fpkm_dict[group].append(fpkm)
		elif 500 <= tpUTRlength < 800: group_500nt_fpkm_dict[group].append(fpkm)
		elif 800 <= tpUTRlength < 20000: group_800nt_fpkm_dict[group].append(fpkm)

	#### 4. get group total gene fpkm #### ** for mild group
	if mild_group in mild_group_all_fpkm_dict.keys():
		mild_group_all_fpkm_dict[mild_group].append(fpkm)
		if 50 <= tpUTRlength < 350: mild_group_50nt_fpkm_dict[mild_group].append(fpkm)
		elif 350 <= tpUTRlength < 500: mild_group_350nt_fpkm_dict[mild_group].append(fpkm)
		elif 500 <= tpUTRlength < 800: mild_group_500nt_fpkm_dict[mild_group].append(fpkm)
		elif 800 <= tpUTRlength < 20000: mild_group_800nt_fpkm_dict[mild_group].append(fpkm)

	#### 5. miRNA sites number effect ###
	siteN = len(dict_sites.keys())
	## sites count = 0: no endo miRNA target sites in 3'UTR (include 6mer)
	if siteN == 0 and len(dict_6mer.keys()) == 0:
		if siteN_fpkm_dict.has_key(siteN): siteN_fpkm_dict[siteN].append(fpkm)
		else: siteN_fpkm_dict[siteN] = [fpkm]
	if siteN == 1 or siteN == 2:
		if siteN_fpkm_dict.has_key(siteN): siteN_fpkm_dict[siteN].append(fpkm)
		else: siteN_fpkm_dict[siteN] = [fpkm]
	elif siteN >= 3:
		if siteN_fpkm_dict.has_key(">=3"): siteN_fpkm_dict[">=3"].append(fpkm)
		else: siteN_fpkm_dict[">=3"] = [fpkm]
	
	#### 5.1 mean number of miRNA sites
	if 50 <= tpUTRlength < 350: length_sitesN_dict["50nt"].append(siteN)
	elif 350 <= tpUTRlength < 500: length_sitesN_dict["350nt"].append(siteN)
	elif 500 <= tpUTRlength < 800: length_sitesN_dict["500nt"].append(siteN)
	elif 800 <= tpUTRlength < 20000: length_sitesN_dict["800nt"].append(siteN)

	#### 6. miRNA sites (8mer, 7m8, 7A1, 6mer) effect
	if len(dict_8mer.keys()) > 0: siteContext_fpkm_dict["8mer"].append([geneID,fpkm])
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) > 0 : siteContext_fpkm_dict["7m8"].append([geneID,fpkm])
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) > 0 : siteContext_fpkm_dict["7A1"].append([geneID,fpkm])
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) > 0 : siteContext_fpkm_dict["6mer"].append([geneID,fpkm])
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) == 0: siteContext_fpkm_dict["noSites"].append([geneID,fpkm])

	#### 6.1 miRNA unique sites (8mer, 7m8, 7A1, 6mer) effect
	if len(dict_8mer.keys()) > 0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) == 0: 
		if siteContext_fpkm_dict.has_key("8mer_unique"): siteContext_fpkm_dict["8mer_unique"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["8mer_unique"] = [[geneID,fpkm]]
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) > 0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys())== 0:
		if siteContext_fpkm_dict.has_key("7m8_unique"): siteContext_fpkm_dict["7m8_unique"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["7m8_unique"] = [[geneID,fpkm]]
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) > 0 and len(dict_6mer.keys()) == 0: 
		if siteContext_fpkm_dict.has_key("7A1_unique"): siteContext_fpkm_dict["7A1_unique"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["7A1_unique"] = [[geneID,fpkm]]
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) > 0 :
		if siteContext_fpkm_dict.has_key("6mer_unique"): siteContext_fpkm_dict["6mer_unique"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["6mer_unique"] = [[geneID,fpkm]]

	#### 6.2 miRNA unique sites (8mer, 7m8, 7A1, 6mer) effect
	if len(dict_8mer.keys()) == 1 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) == 0: 
		if siteContext_fpkm_dict.has_key("8mer_single"): siteContext_fpkm_dict["8mer_single"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["8mer_single"] = [[geneID,fpkm]]
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) == 1 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) == 0: 
		if siteContext_fpkm_dict.has_key("7m8_single"): siteContext_fpkm_dict["7m8_single"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["7m8_single"] = [[geneID,fpkm]]
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) == 1 and len(dict_6mer.keys()) == 0: 
		if siteContext_fpkm_dict.has_key("7A1_single"): siteContext_fpkm_dict["7A1_single"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["7A1_single"] = [[geneID,fpkm]]
	elif len(dict_8mer.keys())==0 and len(dict_7m8.keys()) ==0 and len(dict_7A1.keys()) ==0 and len(dict_6mer.keys()) == 1 : 
		if siteContext_fpkm_dict.has_key("6mer_single"): siteContext_fpkm_dict["6mer_single"].append([geneID,fpkm])
		else: siteContext_fpkm_dict["6mer_single"] = [[geneID,fpkm]]

	#### 7. get AGO2_UFP1_sites number by tpUTR_length
	ago2_upf1_sitesN = len(AGO2_UPF1_sites_key_dict.keys())
	if ago2_upf1_sitesN > 0:
		if 50 <= tpUTRlength < 350: length_overlapSitesN_dict["50nt"].append(ago2_upf1_sitesN)
		elif 350 <= tpUTRlength < 500: length_overlapSitesN_dict["350nt"].append(ago2_upf1_sitesN)
		elif 500 <= tpUTRlength < 800: length_overlapSitesN_dict["500nt"].append(ago2_upf1_sitesN)
		elif 800 <= tpUTRlength < 20000: length_overlapSitesN_dict["800nt"].append(ago2_upf1_sitesN)

	#### 8. AGO2_UFP1_sites number derepression effect
	ago2_sitesN = len(AGO2_sites_key)
	if ago2_sitesN >=2:
		if ago2SitesN_fpkm_dict.has_key(2): ago2SitesN_fpkm_dict[2].append(fpkm)
		else: ago2SitesN_fpkm_dict[2] = [fpkm]
	elif ago2_sitesN <2:
		if ago2SitesN_fpkm_dict.has_key(ago2_sitesN): ago2SitesN_fpkm_dict[ago2_sitesN].append(fpkm)
		else: ago2SitesN_fpkm_dict[ago2_sitesN] = [fpkm]

	if ago2_upf1_sitesN >=2:
		if overlapSitesN_fpkm_dict.has_key(2): overlapSitesN_fpkm_dict[2].append(fpkm)
		else: overlapSitesN_fpkm_dict[2] = [fpkm]
	elif ago2_upf1_sitesN <2:
		if overlapSitesN_fpkm_dict.has_key(ago2_upf1_sitesN): overlapSitesN_fpkm_dict[ago2_upf1_sitesN].append(fpkm)
		else: overlapSitesN_fpkm_dict[ago2_upf1_sitesN] = [fpkm]

	#### 9. for candidate gene select
	## for all genes
	miRNAname_8mer = ",".join(map(lambda x: x[0] + "(8mer)", dict_8mer.values()))
	miRNAname_7m8 = ",".join(map(lambda x: x[0] + "(7m8)", dict_7m8.values()))
	miRNAname_7A1 = ",".join(map(lambda x: x[0] + "(7A1)", dict_7A1.values()))
	for miLocus in dict_sites.keys():
		name = geneID + "_" + "_".join(dict_sites[miLocus])
		bedLine = map(str, [miLocus.chr(), miLocus.start(), miLocus.end(), name, fpkm, miLocus.sense()])
		miRNALocusBed[miLocus] = bedLine

	all_candidate_fpkm[geneID] = map(str,[geneName, fpkm, tpUTRlength, len(dict_8mer.keys()), len(dict_7m8.keys()), len(dict_7A1.keys()), len(dict_6mer.keys()), len(AGO2_sites_key), len(AGO2_noSites_key), len(UPF1_sites_key), len(UPF1_noSites_key), len(AGO2_UPF1_sites_key_dict.keys()), len(AGO2_UPF1_noSites_key), miRNAname_8mer, miRNAname_7m8, miRNAname_7A1])
	## for endo-sites genes
	if len(dict_sites.keys()) > 0:
		sites_candidate_fpkm[geneID] = map(str,[geneName, fpkm, tpUTRlength, len(dict_8mer.keys()), len(dict_7m8.keys()), len(dict_7A1.keys()), len(dict_6mer.keys()), len(AGO2_sites_key), len(AGO2_noSites_key), len(UPF1_sites_key), len(UPF1_noSites_key), len(AGO2_UPF1_sites_key_dict.keys()), len(AGO2_UPF1_noSites_key), miRNAname_8mer, miRNAname_7m8, miRNAname_7A1])

	if (mild_group == "AGO2-UPF1-sites") or (mild_group == "AGO2-UPF1-noSites"):
		AGO2_UPF1_sites_candidate_fpkm[geneID] = map(str,[geneName, fpkm, tpUTRlength, len(dict_8mer.keys()), len(dict_7m8.keys()), len(dict_7A1.keys()), len(dict_6mer.keys()), len(AGO2_sites_key), len(AGO2_noSites_key), len(UPF1_sites_key), len(UPF1_noSites_key), len(AGO2_UPF1_sites_key_dict.keys()), len(AGO2_UPF1_noSites_key), miRNAname_8mer, miRNAname_7m8, miRNAname_7A1])
		### 10. for candidate genes miRNA locus
		for miLocus in dict_sites.keys():
			name = geneID + "_" + "_".join(dict_sites[miLocus])
			bedLine = map(str, [miLocus.chr(), miLocus.start(), miLocus.end(), name, fpkm, miLocus.sense()])
			AGO2_UPF1_sites_candidate_miRNA[miLocus] = bedLine
	elif mild_group == "noAGO2-noUPF1-noSites":
		noAGO2_noUPF1_noSites_candidate[geneID] = map(str,[geneName, fpkm, tpUTRlength, len(dict_8mer.keys()), len(dict_7m8.keys()), len(dict_7A1.keys()), len(dict_6mer.keys()), len(AGO2_sites_key), len(AGO2_noSites_key), len(UPF1_sites_key), len(UPF1_noSites_key), len(AGO2_UPF1_sites_key_dict.keys()), len(AGO2_UPF1_noSites_key), miRNAname_8mer, miRNAname_7m8, miRNAname_7A1])
	sys.stdout.write("\r%s%d%%" % ("Analysis status: ", status))
	sys.stdout.flush()
writeAllGeneStatisticFile.close()
writeFASTA_tpUTR.close()

###################################
## random target normalize
###################################
## make hash tables of randomized miRNA list

random_miRNA_rep100_list = []
for i in range(0,100):
	miRNAseq_list = miRNAseqDic.keys()
	random.shuffle(miRNAseq_list)
	miRrandomSeq = miRNAseq_list[0]
	diNuList = []
	for j in range(0, len(miRrandomSeq), 2):
		diNuList.append(miRrandomSeq[j:j+2])
	random_miRNAseqList = []
	n = 0
	while n < int(miRNA_top.split("p")[1]):
		random.shuffle(diNuList)
		randomSeq = ''.join(diNuList)
		randomSeedSeq = util.reverseComp(util.UtoT(randomSeq[1:7]))
		if not top50_seqToHitsToSites_list[3].has_key(randomSeedSeq):
			if not randomSeq in random_miRNAseqList:
				random_miRNAseqList.append(randomSeq)
				n += 1
	random_seqToHitsToSites_list, random_miSeq_dic = mainModule.get_miRNAsites_dic(random_miRNAseqList, "random")
	random_miRNA_rep100_list.append(random_seqToHitsToSites_list)
noSites_random_fpkm = mainModule.getRandomSitesFPKM(noSites_genes, geneID_tpUTRseq, geneID_fpkmLength, random_miRNA_rep100_list, "count", mre)
noSites_randomMiRNA_fpkm = mainModule.getRandomSitesFPKM(noSites_genes, geneID_tpUTRseq, geneID_fpkmLength, random_miRNA_rep100_list, "all", mre)

#### miRNA sites number effect ###
miRNAsiteNfpkmFile = cellLine+'_miRNAsiteN_fpkmStatistic.txt'
writeMiRNASiteNfpkmFile = open(outputDir+miRNAsiteNfpkmFile, 'w')
writeMiRNASiteNfpkmFile.write("miRNA_sites" + "\t" + "miRNA site Number"+ "\t" + "Count" + "\t" +"Normalize"+ "\t" +"Mean_log2_fold_change"+ "\t" +"Median_log2_fold_change" + "\t" +"Standard_error" + "\n")

topX_sites_random_dict = {"allSites":[],"randomSites":[]}
randomSites_mean = dict()
all_randomFPKM = []
for siteCount in noSites_random_fpkm.keys():
	if not siteCount == "0":
		for fpkm in noSites_random_fpkm[siteCount]:
			topX_sites_random_dict["randomSites"].append(fpkm)
			all_randomFPKM.append(fpkm)
	count, meanFpkm, medianFpkm, stdFpkm, steFpkm = mainModule.getMeanSteFromList(noSites_random_fpkm[siteCount])
	randomSites_mean[siteCount] = meanFpkm
	writeMiRNASiteNfpkmFile.write("random_sites" + "\t" + siteCount + "\t" +str(count) + "\t" + str(meanFpkm-meanFpkm) + "\t" + str(meanFpkm) + "\t" + str(medianFpkm) + "\t" + str(steFpkm)  + "\n")

sorted(siteN_fpkm_dict)
for siteN in siteN_fpkm_dict.keys():
	if not siteN == 0:
		for fpkm in siteN_fpkm_dict[siteN]: topX_sites_random_dict["allSites"].append(fpkm)
	random_mean = randomSites_mean[str(siteN)]
	count, meanFpkm, medianFpkm, stdFpkm, steFpkm = mainModule.getMeanSteFromList(siteN_fpkm_dict[siteN])
	writeMiRNASiteNfpkmFile.write("miRNA_sites" + "\t" +str(siteN) + "\t" +str(count) + "\t" + str(meanFpkm-random_mean) + "\t" + str(meanFpkm) + "\t" + str(random_mean) + "\t" + str(steFpkm)  + "\n")
writeMiRNASiteNfpkmFile.close()

#### for miRNA topX group, negative control == random control
pValue_topX_dic = mainModule.getGroupRankSumPvalue(topX_sites_random_dict)
miRNAtopXfpkmFile = cellLine+'_miRNAtopX.txt'
writeMiRNAtopXfpkmFile = open(outputDir+miRNAtopXfpkmFile, 'w')
writeMiRNAtopXfpkmFile.write("miRNA_sites" + "\t" + "Count" + "\t" +"Mean_log2_fold_change"+ "\t"  +"Standard_error" + "\t" + "p-value(Rank-sum)" + "\n")

for key in topX_sites_random_dict.keys():
	count, meanFpkm, medianFpkm, stdFpkm, steFpkm = mainModule.getMeanSteFromList(topX_sites_random_dict[key])
	if key == "randomSites": randomCount = count; randomMean = meanFpkm; randomSte = steFpkm
	pValue = ",".join(pValue_topX_dic[key])
	if not pValue_topX_dic.has_key(key): pValue = "0" 
	writeMiRNAtopXfpkmFile.write(key + "\t" + str(count)  + "\t" + str(meanFpkm) + "\t" + str(steFpkm) + "\t" + pValue + "\n")
writeMiRNAtopXfpkmFile.write(mre + "\t"+ str(mainModule.getMeanSteFromList(miRNAGroup_log2Fold[mre])[0]) + "\t" + str(mainModule.getMeanSteFromList(miRNAGroup_log2Fold[mre])[1]) + "\t" + str(mainModule.getMeanSteFromList(miRNAGroup_log2Fold[mre])[2]) + "\t" + str(mainModule.getMeanSteFromList(miRNAGroup_log2Fold[mre])[3]) + "\t" +str(mainModule.getMeanSteFromList(miRNAGroup_log2Fold[mre])[4]) + "\t" + "None" + "\n")
writeMiRNAtopXfpkmFile.write(mre + "\t"+ str(mainModule.getMeanSteFromList(noSites_randomMiRNA_fpkm[mre])[0]) + "\t" + str(mainModule.getMeanSteFromList(noSites_randomMiRNA_fpkm[mre])[1]) + "\t" +str(mainModule.getMeanSteFromList(noSites_randomMiRNA_fpkm[mre])[4]) + "\t" + "None" + "\n")
writeMiRNAtopXfpkmFile.close()


miRNAtopXfpkmFile_forPvalue = cellLine+'_miRNAtopX_forPvalue.txt'
writeMiRNAtopXfpkmFile_forPvalue = open(outputDir+miRNAtopXfpkmFile_forPvalue, 'w')
for key in topX_sites_random_dict.keys():
	for fpkm in topX_sites_random_dict[key]:
		writeMiRNAtopXfpkmFile_forPvalue.write(miRNA_top+ "_"+ key+ "\t" + str(fpkm) + "\n")
writeMiRNAtopXfpkmFile_forPvalue.close()


miRNAsiteNpValueFile = cellLine+'_miRNAsiteN_fpkmForPvalue.txt'
writeMiRNAsiteNpValueFile = open(outputDir+miRNAsiteNpValueFile, 'w')
writeMiRNAsiteNpValueFile.write("miRNA_sites" + "\t" +"Mean_log2_fold_change"+ "\n")
for siteCount in noSites_random_fpkm.keys():
	for fpkm in noSites_random_fpkm[siteCount]:
		writeMiRNAsiteNpValueFile.write("random_" + siteCount + "\t" + str(fpkm) +"\n")
for siteN in siteN_fpkm_dict.keys():
	for fpkm in siteN_fpkm_dict[siteN]:
		writeMiRNAsiteNpValueFile.write("sites_" + str(siteN) + "\t" + str(fpkm) +"\n")
writeMiRNAsiteNpValueFile.close()


####  mean number of miRNA sites
MiSiteNbyTpUTRFile = cellLine+'_miSiteN_byTpUTR.txt'
writeMiSiteNbyTpUTRFile = open(outputDir+MiSiteNbyTpUTRFile, 'w')
writeMiSiteNbyTpUTRFile.write("tpUTR_length" + "\t" + "Count"  + "\t" + "Mean number of sites" + '\t' + "Standard_error" + "\n")
for length in length_sitesN_dict.keys():
	count, meanFpkm, medianFpkm, stdFpkm, steFpkm = mainModule.getMeanSteFromList(length_sitesN_dict[length])
	writeMiSiteNbyTpUTRFile.write(length + "\t" + str(len(length_sitesN_dict[length])) + "\t" + str(meanFpkm) + "\t" + str(steFpkm)  + "\n")
writeMiSiteNbyTpUTRFile.close()



